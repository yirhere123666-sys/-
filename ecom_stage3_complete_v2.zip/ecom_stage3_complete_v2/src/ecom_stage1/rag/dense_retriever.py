
from __future__ import annotations

import pickle
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

from .embeddings import DenseEmbedder
from .schemas import Chunk, RetrievedChunk

try:
    import faiss  # type: ignore
except Exception:  # pragma: no cover
    faiss = None


class DenseRetriever:
    def __init__(
        self,
        use_faiss: bool = False,
        embedding_backend: str = 'tfidf_svd',
        embedding_model_name: str = 'BAAI/bge-m3',
        embedding_device: str | None = None,
    ):
        self.use_faiss = bool(use_faiss and faiss is not None)
        self.embedder = DenseEmbedder(
            backend=embedding_backend,
            model_name=embedding_model_name,
            device=embedding_device,
        )
        self.chunks: List[Chunk] = []
        self.matrix: Optional[np.ndarray] = None
        self.index = None

    def fit(self, chunks: List[Chunk]) -> None:
        self.chunks = chunks
        texts = [c.text for c in chunks]
        self.matrix = self.embedder.encode_documents(texts)
        if self.use_faiss and self.matrix is not None and len(self.matrix):
            dim = self.matrix.shape[1]
            self.index = faiss.IndexFlatIP(dim)
            self.index.add(self.matrix.astype('float32'))

    def search(self, query: str, top_k: int = 5, filters: Optional[Dict[str, str]] = None) -> List[RetrievedChunk]:
        filters = filters or {}
        if self.matrix is None or len(self.chunks) == 0:
            return []
        q = self.embedder.encode_queries([query])[0].astype('float32')
        candidates = [(idx, c) for idx, c in enumerate(self.chunks) if self._match_filters(c, filters)]
        if not candidates:
            return []
        idxs = np.array([x[0] for x in candidates], dtype=np.int64)
        mat = self.matrix[idxs]
        scores = mat @ q
        order = np.argsort(scores)[::-1][:top_k]
        results: List[RetrievedChunk] = []
        for pos in order:
            chunk_idx = int(idxs[pos])
            c = self.chunks[chunk_idx]
            score = float(scores[pos])
            results.append(RetrievedChunk(
                chunk_id=c.chunk_id,
                doc_id=c.doc_id,
                title=c.title,
                text=c.text,
                source_type=c.source_type,
                score=score,
                dense_score=score,
                metadata=dict(c.metadata),
            ))
        return results

    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('wb') as f:
            pickle.dump(self, f)

    @staticmethod
    def load(path: str | Path) -> 'DenseRetriever':
        with Path(path).open('rb') as f:
            return pickle.load(f)

    def _match_filters(self, chunk: Chunk, filters: Dict[str, str]) -> bool:
        for k, v in filters.items():
            if chunk.metadata.get(k) != v:
                return False
        return True
