from __future__ import annotations

import re
from typing import Iterable, List

try:
    import jieba
except Exception:  # pragma: no cover
    jieba = None


def normalize_text(text: str) -> str:
    text = text or ""
    text = text.replace("\u3000", " ")
    text = re.sub(r"\s+", " ", text).strip()
    return text


def tokenize(text: str) -> List[str]:
    text = normalize_text(text).lower()
    if not text:
        return []
    if jieba is not None:
        tokens = [tok.strip() for tok in jieba.lcut(text) if tok.strip()]
        if tokens:
            return tokens
    return [tok for tok in re.split(r"[^\w\u4e00-\u9fff]+", text) if tok]


def split_sentences(text: str) -> List[str]:
    text = normalize_text(text)
    if not text:
        return []
    parts = re.split(r"(?<=[。！？!?；;])", text)
    return [p.strip() for p in parts if p.strip()]


def keyword_candidates(text: str, top_k: int = 8) -> List[str]:
    stop = {"的", "了", "是", "我", "你", "他", "她", "它", "and", "the", "to", "for", "a", "an", "of"}
    counts = {}
    for tok in tokenize(text):
        if tok in stop or len(tok) <= 1:
            continue
        counts[tok] = counts.get(tok, 0) + 1
    return [k for k, _ in sorted(counts.items(), key=lambda x: (-x[1], x[0]))[:top_k]]


def any_keyword_in_text(keywords: Iterable[str], text: str) -> bool:
    text = normalize_text(text).lower()
    return any(normalize_text(k).lower() in text for k in keywords)
