from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Optional

from ecom_stage1.io_utils import load_text

from .context_builder import ContextBuilder
from .dense_retriever import DenseRetriever
from .generator import RAGGenerator
from .hybrid_retriever import HybridRetriever
from .reranker import SimpleHeuristicReranker, TransformerCrossEncoderReranker
from .schemas import RAGPrediction
from .sparse_retriever import BM25Retriever


class RAGPipeline:
    def __init__(
        self,
        index_dir: str | Path,
        system_prompt_path: str | Path,
        generator_backend: str = 'extractive',
        base_model: str = 'Qwen/Qwen2-7B-Instruct',
        model_path: Optional[str] = None,
        dense_weight: float = 0.6,
        sparse_weight: float = 0.4,
        reranker_type: str | None = None,
        reranker_model_name: str | None = None,
        max_context_chars: int = 2200,
        max_chunks: int = 6,
        max_chunks_per_doc: int = 2,
    ):
        self.index_dir = Path(index_dir)
        self.system_prompt = load_text(system_prompt_path)
        self.sparse = BM25Retriever.load(self.index_dir / 'bm25.pkl')
        self.dense = DenseRetriever.load(self.index_dir / 'dense.pkl')
        manifest_path = self.index_dir / 'manifest.json'
        self.manifest = json.loads(manifest_path.read_text(encoding='utf-8')) if manifest_path.exists() else {}

        reranker_type = reranker_type or self.manifest.get('reranker', {}).get('type', 'heuristic')
        reranker_model_name = reranker_model_name or self.manifest.get('reranker', {}).get('model_name', 'BAAI/bge-reranker-v2-m3')
        if reranker_type in {'cross_encoder', 'bge_reranker'}:
            self.reranker = TransformerCrossEncoderReranker(model_name=reranker_model_name)
        else:
            self.reranker = SimpleHeuristicReranker()

        self.hybrid = HybridRetriever(self.sparse, self.dense, dense_weight=dense_weight, sparse_weight=sparse_weight, reranker=self.reranker)
        self.context_builder = ContextBuilder(max_context_chars=max_context_chars, max_chunks=max_chunks, max_chunks_per_doc=max_chunks_per_doc)
        self.generator = RAGGenerator(backend=generator_backend, base_model=base_model, model_path=model_path)

    def retrieve(self, query: str, top_k: int = 5, filters: Optional[Dict[str, str]] = None):
        return self.hybrid.search(query, top_k=top_k, retrieve_k=max(top_k * 3, 12), filters=filters, use_reranker=True)

    def answer(self, sample_id: str, query: str, history: Optional[List[Dict[str, str]]] = None, filters: Optional[Dict[str, str]] = None, top_k: int = 5) -> RAGPrediction:
        hits = self.retrieve(query, top_k=top_k, filters=filters)
        context, citations = self.context_builder.build(hits)
        if history:
            history_text = '\n'.join([f"{h['role']}: {h['content']}" for h in history])
            context = f"历史上下文:\n{history_text}\n\n检索知识:\n{context}" if context else f"历史上下文:\n{history_text}"
        answer = self.generator.generate(self.system_prompt, query, context)
        return RAGPrediction(
            id=sample_id,
            query=query,
            answer=answer,
            context=context,
            citations=citations,
            retrieved_chunks=[h.to_dict() for h in hits],
            metadata={'top_k': top_k, 'filters': filters or {}, 'manifest': self.manifest},
        )
