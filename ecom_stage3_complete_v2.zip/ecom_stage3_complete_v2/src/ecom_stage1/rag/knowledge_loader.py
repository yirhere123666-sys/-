from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Dict, Iterator, List, Optional

from .schemas import KnowledgeDocument
from .text_utils import normalize_text


class KnowledgeLoader:
    """加载 FAQ / SOP / 商品参数 / 规则文档，并统一成 KnowledgeDocument。"""

    SUPPORTED = {".txt", ".md", ".json", ".jsonl", ".csv", ".html", ".htm"}

    def __init__(self, root_dir: str | Path):
        self.root_dir = Path(root_dir)

    def iter_paths(self) -> Iterator[Path]:
        if self.root_dir.is_file():
            yield self.root_dir
            return
        for path in sorted(self.root_dir.rglob('*')):
            if path.is_file() and path.suffix.lower() in self.SUPPORTED:
                yield path

    def load(self) -> List[KnowledgeDocument]:
        docs: List[KnowledgeDocument] = []
        for idx, path in enumerate(self.iter_paths()):
            docs.extend(self._load_path(path, idx_prefix=idx))
        return docs

    def _load_path(self, path: Path, idx_prefix: int = 0) -> List[KnowledgeDocument]:
        suffix = path.suffix.lower()
        if suffix in {'.txt', '.md', '.html', '.htm'}:
            text = path.read_text(encoding='utf-8', errors='ignore')
            return [self._build_doc(path, f'{idx_prefix}_0', path.stem, text)]
        if suffix == '.json':
            data = json.loads(path.read_text(encoding='utf-8'))
            return self._load_json_like(path, data, idx_prefix)
        if suffix == '.jsonl':
            rows = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]
            return self._load_json_like(path, rows, idx_prefix)
        if suffix == '.csv':
            with path.open('r', encoding='utf-8-sig', newline='') as f:
                reader = csv.DictReader(f)
                docs: List[KnowledgeDocument] = []
                for j, row in enumerate(reader):
                    title = row.get('title') or row.get('name') or row.get('sku') or f'{path.stem}_{j}'
                    text_parts = []
                    for k, v in row.items():
                        if v is None or str(v).strip() == '':
                            continue
                        text_parts.append(f'{k}: {v}')
                    docs.append(self._build_doc(path, f'{idx_prefix}_{j}', str(title), '\n'.join(text_parts), metadata={'row_index': j}))
                return docs
        return []

    def _load_json_like(self, path: Path, data, idx_prefix: int) -> List[KnowledgeDocument]:
        docs: List[KnowledgeDocument] = []
        if isinstance(data, dict):
            data = [data]
        for j, row in enumerate(data):
            if isinstance(row, str):
                docs.append(self._build_doc(path, f'{idx_prefix}_{j}', path.stem, row, metadata={'row_index': j}))
                continue
            if not isinstance(row, dict):
                docs.append(self._build_doc(path, f'{idx_prefix}_{j}', path.stem, json.dumps(row, ensure_ascii=False), metadata={'row_index': j}))
                continue
            title = row.get('title') or row.get('question') or row.get('name') or row.get('sku') or f'{path.stem}_{j}'
            source_type = row.get('source_type') or self._infer_source_type(path)
            meta = {k: v for k, v in row.items() if k not in {'text', 'content', 'body', 'answer', 'question', 'title'}}
            if 'question' in row and 'answer' in row:
                text = f"问题: {row['question']}\n答案: {row['answer']}"
            else:
                text = row.get('text') or row.get('content') or row.get('body') or json.dumps(row, ensure_ascii=False)
            docs.append(self._build_doc(path, f'{idx_prefix}_{j}', str(title), text, source_type=source_type, metadata=meta))
        return docs

    def _build_doc(self, path: Path, suffix: str, title: str, text: str, source_type: Optional[str] = None, metadata: Optional[Dict] = None) -> KnowledgeDocument:
        source_type = source_type or self._infer_source_type(path)
        metadata = metadata or {}
        metadata.setdefault('file_name', path.name)
        relative_base = self.root_dir if self.root_dir.is_dir() else path.parent
        try:
            metadata.setdefault('relative_path', str(path.relative_to(relative_base)))
        except Exception:
            metadata.setdefault('relative_path', path.name)
        return KnowledgeDocument(
            id=f'{path.stem}_{suffix}',
            title=normalize_text(title)[:120] or path.stem,
            text=normalize_text(text),
            source_path=str(path),
            source_type=source_type,
            metadata=metadata,
        )

    def _infer_source_type(self, path: Path) -> str:
        name = path.name.lower()
        if any(k in name for k in ['faq', 'qa', 'question']):
            return 'faq'
        if any(k in name for k in ['sop', 'policy', 'rule', 'refund', 'shipping', 'invoice']):
            return 'rule'
        if any(k in name for k in ['product', 'spec', 'sku', 'catalog']):
            return 'product'
        return 'doc'
