from __future__ import annotations

import math
import pickle
from pathlib import Path
from typing import Dict, Iterable, List, Optional

from .schemas import Chunk, RetrievedChunk
from .text_utils import tokenize


class BM25Retriever:
    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1 = k1
        self.b = b
        self.chunks: List[Chunk] = []
        self.doc_freqs: List[Dict[str, int]] = []
        self.idf: Dict[str, float] = {}
        self.doc_len: List[int] = []
        self.avgdl: float = 0.0

    def fit(self, chunks: List[Chunk]) -> None:
        self.chunks = chunks
        self.doc_freqs = []
        self.doc_len = []
        df: Dict[str, int] = {}
        for chunk in chunks:
            freqs: Dict[str, int] = {}
            tokens = tokenize(chunk.text)
            self.doc_len.append(len(tokens))
            for tok in tokens:
                freqs[tok] = freqs.get(tok, 0) + 1
            self.doc_freqs.append(freqs)
            for tok in freqs.keys():
                df[tok] = df.get(tok, 0) + 1
        n_docs = max(len(chunks), 1)
        self.avgdl = sum(self.doc_len) / n_docs if n_docs else 0.0
        self.idf = {
            tok: math.log(1 + (n_docs - freq + 0.5) / (freq + 0.5))
            for tok, freq in df.items()
        }

    def search(self, query: str, top_k: int = 5, filters: Optional[Dict[str, str]] = None) -> List[RetrievedChunk]:
        filters = filters or {}
        q_tokens = tokenize(query)
        scores = []
        for idx, chunk in enumerate(self.chunks):
            if not self._match_filters(chunk, filters):
                continue
            score = 0.0
            freqs = self.doc_freqs[idx]
            dl = self.doc_len[idx] or 1
            for tok in q_tokens:
                if tok not in freqs:
                    continue
                idf = self.idf.get(tok, 0.0)
                tf = freqs[tok]
                denom = tf + self.k1 * (1 - self.b + self.b * dl / (self.avgdl or 1.0))
                score += idf * tf * (self.k1 + 1) / (denom + 1e-12)
            if score > 0:
                scores.append((idx, score))
        scores.sort(key=lambda x: x[1], reverse=True)
        results: List[RetrievedChunk] = []
        for idx, score in scores[:top_k]:
            c = self.chunks[idx]
            results.append(RetrievedChunk(
                chunk_id=c.chunk_id,
                doc_id=c.doc_id,
                title=c.title,
                text=c.text,
                source_type=c.source_type,
                score=float(score),
                sparse_score=float(score),
                metadata=dict(c.metadata),
            ))
        return results

    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('wb') as f:
            pickle.dump(self, f)

    @staticmethod
    def load(path: str | Path) -> 'BM25Retriever':
        with Path(path).open('rb') as f:
            return pickle.load(f)

    def _match_filters(self, chunk: Chunk, filters: Dict[str, str]) -> bool:
        for k, v in filters.items():
            if chunk.metadata.get(k) != v:
                return False
        return True
