
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List, Sequence

from .schemas import RetrievedChunk
from .text_utils import any_keyword_in_text, tokenize

try:  # pragma: no cover - optional dependency
    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer
except Exception:  # pragma: no cover
    torch = None
    AutoModelForSequenceClassification = None
    AutoTokenizer = None


class BaseReranker(ABC):
    @abstractmethod
    def rerank(self, query: str, candidates: List[RetrievedChunk], top_k: int = 5) -> List[RetrievedChunk]:
        raise NotImplementedError


class SimpleHeuristicReranker(BaseReranker):
    """轻量重排器：基于 query-token overlap + metadata 关键字提升。"""

    def rerank(self, query: str, candidates: List[RetrievedChunk], top_k: int = 5) -> List[RetrievedChunk]:
        q_tokens = set(tokenize(query))
        reranked: List[RetrievedChunk] = []
        for c in candidates:
            c_tokens = set(tokenize(c.text))
            overlap = len(q_tokens & c_tokens) / max(len(q_tokens), 1)
            keyword_boost = 0.0
            if any_keyword_in_text(c.metadata.get('keywords', []), query):
                keyword_boost += 0.2
            if c.source_type == 'rule' and any(tok in query for tok in ['退款', '退货', '发票', '保价', '赠品', 'refund', 'invoice']):
                keyword_boost += 0.15
            rerank_score = overlap + keyword_boost
            c.rerank_score = rerank_score
            c.score = 0.5 * c.score + 0.5 * rerank_score
            reranked.append(c)
        reranked.sort(key=lambda x: (x.rerank_score, x.score), reverse=True)
        return reranked[:top_k]


class TransformerCrossEncoderReranker(BaseReranker):
    """真实 Cross-Encoder 优先，环境不满足时自动回退到启发式重排。"""

    def __init__(self, model_name: str = 'BAAI/bge-reranker-v2-m3', device: str | None = None, batch_size: int = 8):
        self.model_name = model_name
        self.device = device or ('cuda' if torch is not None and torch.cuda.is_available() else 'cpu')
        self.batch_size = batch_size
        self._tokenizer = None
        self._model = None
        self._fallback = SimpleHeuristicReranker()
        self.runtime_backend = 'heuristic'

    def __getstate__(self):
        state = self.__dict__.copy()
        state['_tokenizer'] = None
        state['_model'] = None
        return state

    def __setstate__(self, state):
        self.__dict__.update(state)
        self._tokenizer = None
        self._model = None

    def _ensure_model(self) -> bool:
        if self._tokenizer is not None and self._model is not None:
            self.runtime_backend = 'cross_encoder'
            return True
        if AutoTokenizer is None or AutoModelForSequenceClassification is None or torch is None:
            self.runtime_backend = 'heuristic'
            return False
        try:  # pragma: no cover
            self._tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            self._model = AutoModelForSequenceClassification.from_pretrained(self.model_name)
            self._model.to(self.device)
            self._model.eval()
            self.runtime_backend = 'cross_encoder'
            return True
        except Exception:
            self._tokenizer = None
            self._model = None
            self.runtime_backend = 'heuristic'
            return False

    def _score_pairs(self, pairs: Sequence[tuple[str, str]]) -> List[float]:  # pragma: no cover
        scores: List[float] = []
        for i in range(0, len(pairs), self.batch_size):
            sub = pairs[i:i+self.batch_size]
            q = [x[0] for x in sub]
            d = [x[1] for x in sub]
            encoded = self._tokenizer(q, d, padding=True, truncation=True, max_length=512, return_tensors='pt')
            encoded = {k: v.to(self.device) for k, v in encoded.items()}
            with torch.no_grad():
                outputs = self._model(**encoded)
                logits = outputs.logits
                if logits.ndim == 2 and logits.shape[1] > 1:
                    batch_scores = logits[:, 1]
                else:
                    batch_scores = logits.view(-1)
            scores.extend(batch_scores.detach().cpu().tolist())
        return scores

    def rerank(self, query: str, candidates: List[RetrievedChunk], top_k: int = 5) -> List[RetrievedChunk]:
        if not candidates:
            return []
        if not self._ensure_model():
            return self._fallback.rerank(query, candidates, top_k=top_k)
        pairs = [(query, c.text) for c in candidates]
        scores = self._score_pairs(pairs)
        reranked: List[RetrievedChunk] = []
        for c, score in zip(candidates, scores):
            c.rerank_score = float(score)
            c.score = 0.35 * c.score + 0.65 * float(score)
            reranked.append(c)
        reranked.sort(key=lambda x: (x.rerank_score, x.score), reverse=True)
        return reranked[:top_k]
