from __future__ import annotations

from dataclasses import replace
from typing import List

from .schemas import Chunk, KnowledgeDocument
from .text_utils import keyword_candidates, normalize_text, split_sentences


class DocumentChunker:
    def __init__(self, chunk_size: int = 320, chunk_overlap: int = 60, min_chunk_size: int = 80):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.min_chunk_size = min_chunk_size

    def chunk_documents(self, docs: List[KnowledgeDocument]) -> List[Chunk]:
        chunks: List[Chunk] = []
        for doc in docs:
            chunks.extend(self._chunk_one(doc))
        return chunks

    def _chunk_one(self, doc: KnowledgeDocument) -> List[Chunk]:
        text = normalize_text(doc.text)
        if len(text) <= self.chunk_size:
            return [self._build_chunk(doc, 0, text)]
        pieces = split_sentences(text)
        if not pieces:
            pieces = [text]
        chunks: List[Chunk] = []
        current = ''
        chunk_idx = 0
        for piece in pieces:
            piece = normalize_text(piece)
            if not piece:
                continue
            if len(current) + len(piece) + 1 <= self.chunk_size:
                current = (current + ' ' + piece).strip()
                continue
            if current:
                chunks.append(self._build_chunk(doc, chunk_idx, current))
                chunk_idx += 1
                overlap = current[-self.chunk_overlap:] if self.chunk_overlap > 0 else ''
                current = (overlap + ' ' + piece).strip()
            else:
                chunks.append(self._build_chunk(doc, chunk_idx, piece[: self.chunk_size]))
                chunk_idx += 1
                current = piece[self.chunk_size - self.chunk_overlap :]
        if current and len(current) >= self.min_chunk_size:
            chunks.append(self._build_chunk(doc, chunk_idx, current))
        return chunks

    def _build_chunk(self, doc: KnowledgeDocument, idx: int, text: str) -> Chunk:
        meta = dict(doc.metadata)
        meta.update({
            'keywords': keyword_candidates(text, top_k=8),
            'chunk_index': idx,
            'title': doc.title,
        })
        return Chunk(
            chunk_id=f'{doc.id}_chunk_{idx}',
            doc_id=doc.id,
            title=doc.title,
            text=normalize_text(text),
            source_type=doc.source_type,
            metadata=meta,
        )
