from __future__ import annotations

from typing import Dict, List, Tuple

from .schemas import RetrievedChunk


class ContextBuilder:
    def __init__(self, max_context_chars: int = 2200, max_chunks: int = 6, max_chunks_per_doc: int = 2):
        self.max_context_chars = max_context_chars
        self.max_chunks = max_chunks
        self.max_chunks_per_doc = max_chunks_per_doc

    def build(self, hits: List[RetrievedChunk]) -> Tuple[str, List[Dict[str, str]]]:
        parts: List[str] = []
        citations: List[Dict[str, str]] = []
        per_doc: Dict[str, int] = {}
        total = 0
        for rank, hit in enumerate(hits, start=1):
            if len(citations) >= self.max_chunks:
                break
            if per_doc.get(hit.doc_id, 0) >= self.max_chunks_per_doc:
                continue
            sku = hit.metadata.get('sku') or hit.metadata.get('sku_id') or ''
            category = hit.metadata.get('category') or hit.metadata.get('product_category') or ''
            rel_path = hit.metadata.get('relative_path') or hit.metadata.get('file_name') or ''
            block = (
                f"[证据{rank}] 标题: {hit.title}\n"
                f"来源类型: {hit.source_type}\n"
                f"文档路径: {rel_path}\n"
                f"类目: {category}\n"
                f"SKU: {sku}\n"
                f"检索分数: {hit.score:.4f}\n"
                f"重排分数: {hit.rerank_score:.4f}\n"
                f"内容: {hit.text}"
            )
            if total + len(block) > self.max_context_chars and citations:
                break
            citations.append(
                {
                    'ref': f'证据{rank}',
                    'doc_id': hit.doc_id,
                    'chunk_id': hit.chunk_id,
                    'title': hit.title,
                    'source_type': hit.source_type,
                    'relative_path': rel_path,
                }
            )
            parts.append(block)
            per_doc[hit.doc_id] = per_doc.get(hit.doc_id, 0) + 1
            total += len(block)
        header = (
            '以下是与用户问题最相关的知识证据。回答时优先引用规则、FAQ、商品参数或SOP中的明确事实；'
            '若证据不足，必须明确说明需要核验，不能编造订单、物流、商品参数或售后结论。'
        )
        return header + '\n\n' + '\n\n'.join(parts) if parts else '', citations
