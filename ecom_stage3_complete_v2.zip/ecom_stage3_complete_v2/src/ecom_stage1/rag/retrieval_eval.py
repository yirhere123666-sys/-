
from __future__ import annotations

from typing import Dict, List, Sequence

from .schemas import RetrievedChunk
from .text_utils import normalize_text


def context_keyword_recall(context: str, must_mention: Sequence[str]) -> float:
    if not must_mention:
        return 1.0
    context = normalize_text(context)
    hits = sum(1 for kw in must_mention if normalize_text(kw) in context)
    return hits / len(must_mention)


def topk_hit_rate(chunks: Sequence[RetrievedChunk], must_mention: Sequence[str], k: int = 5) -> int:
    if not must_mention:
        return 1
    texts = ' '.join([c.text for c in chunks[:k]])
    texts = normalize_text(texts)
    return int(any(normalize_text(kw) in texts for kw in must_mention))


def mean_reciprocal_rank_by_keywords(chunks: Sequence[RetrievedChunk], must_mention: Sequence[str]) -> float:
    if not must_mention:
        return 1.0
    for idx, chunk in enumerate(chunks, start=1):
        text = normalize_text(chunk.text)
        if any(normalize_text(kw) in text for kw in must_mention):
            return 1.0 / idx
    return 0.0


def citation_precision(chunks: Sequence[RetrievedChunk], must_mention: Sequence[str], k: int = 5) -> float:
    if not chunks:
        return 0.0
    if not must_mention:
        return 1.0
    keep = chunks[:k]
    hits = 0
    for c in keep:
        text = normalize_text(c.text)
        if any(normalize_text(kw) in text for kw in must_mention):
            hits += 1
    return hits / max(len(keep), 1)


def source_diversity(chunks: Sequence[RetrievedChunk], k: int = 5) -> float:
    keep = chunks[:k]
    if not keep:
        return 0.0
    uniq = {c.source_type for c in keep}
    return len(uniq) / len(keep)


def retrieval_summary(rows: List[Dict]) -> Dict[str, float]:
    if not rows:
        return {
            'context_keyword_recall': 0.0,
            'hit@5': 0.0,
            'hit@10': 0.0,
            'mrr': 0.0,
            'citation_precision@5': 0.0,
            'source_diversity@5': 0.0,
            'num_samples': 0,
        }
    n = len(rows)
    return {
        'context_keyword_recall': sum(r['context_keyword_recall'] for r in rows) / n,
        'hit@5': sum(r['hit@5'] for r in rows) / n,
        'hit@10': sum(r['hit@10'] for r in rows) / n,
        'mrr': sum(r['mrr'] for r in rows) / n,
        'citation_precision@5': sum(r['citation_precision@5'] for r in rows) / n,
        'source_diversity@5': sum(r['source_diversity@5'] for r in rows) / n,
        'num_samples': n,
    }
