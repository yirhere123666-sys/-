
from __future__ import annotations

import pickle
from pathlib import Path
from typing import Sequence

import numpy as np
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import Normalizer

from .text_utils import normalize_text

try:  # pragma: no cover - optional dependency
    import torch
    from transformers import AutoModel, AutoTokenizer
except Exception:  # pragma: no cover
    torch = None
    AutoModel = None
    AutoTokenizer = None


class DenseEmbedder:
    """Dense embedding manager.

    backend='bge_m3' 时优先尝试使用 Hugging Face / Transformers 加载真实 embedding 模型。
    若环境缺少依赖或模型加载失败，则自动回退到可离线运行的 tfidf_svd 后端。
    """

    def __init__(
        self,
        backend: str = 'tfidf_svd',
        model_name: str = 'BAAI/bge-m3',
        device: str | None = None,
        max_features: int = 12000,
        n_components: int = 256,
        batch_size: int = 16,
    ):
        self.backend = backend
        self.model_name = model_name
        self.device = device or ('cuda' if torch is not None and torch.cuda.is_available() else 'cpu')
        self.max_features = max_features
        self.n_components = n_components
        self.batch_size = batch_size

        # Fallback backend state
        self.vectorizer = TfidfVectorizer(analyzer='char_wb', ngram_range=(2, 4), max_features=max_features)
        self.svd = None
        self.normalizer = Normalizer(copy=False)
        self.is_fitted = False

        # Runtime-only real model state
        self._tokenizer = None
        self._model = None
        self.runtime_backend = backend

    def __getstate__(self):
        state = self.__dict__.copy()
        state['_tokenizer'] = None
        state['_model'] = None
        return state

    def __setstate__(self, state):
        self.__dict__.update(state)
        self._tokenizer = None
        self._model = None

    def _ensure_real_backend(self) -> bool:
        if self.backend not in {'bge_m3', 'hf_encoder'}:
            self.runtime_backend = 'tfidf_svd'
            return False
        if self._tokenizer is not None and self._model is not None:
            self.runtime_backend = self.backend
            return True
        if AutoTokenizer is None or AutoModel is None or torch is None:
            self.runtime_backend = 'tfidf_svd'
            return False
        try:  # pragma: no cover - depends on environment/models
            self._tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            self._model = AutoModel.from_pretrained(self.model_name)
            self._model.to(self.device)
            self._model.eval()
            self.runtime_backend = self.backend
            return True
        except Exception:
            self.runtime_backend = 'tfidf_svd'
            self._tokenizer = None
            self._model = None
            return False

    @staticmethod
    def _mean_pool(last_hidden_state, attention_mask):  # pragma: no cover - torch path
        mask = attention_mask.unsqueeze(-1).expand(last_hidden_state.size()).float()
        masked = last_hidden_state * mask
        summed = masked.sum(dim=1)
        counts = mask.sum(dim=1).clamp(min=1e-9)
        return summed / counts

    def _encode_real(self, texts: Sequence[str]) -> np.ndarray:  # pragma: no cover - torch path
        texts = [normalize_text(t) for t in texts]
        batches = []
        for i in range(0, len(texts), self.batch_size):
            sub = texts[i : i + self.batch_size]
            encoded = self._tokenizer(
                list(sub),
                padding=True,
                truncation=True,
                max_length=512,
                return_tensors='pt',
            )
            encoded = {k: v.to(self.device) for k, v in encoded.items()}
            with torch.no_grad():
                outputs = self._model(**encoded)
                if hasattr(outputs, 'last_hidden_state'):
                    emb = self._mean_pool(outputs.last_hidden_state, encoded['attention_mask'])
                elif hasattr(outputs, 'pooler_output') and outputs.pooler_output is not None:
                    emb = outputs.pooler_output
                else:
                    emb = outputs[0][:, 0]
                emb = torch.nn.functional.normalize(emb, p=2, dim=1)
            batches.append(emb.detach().cpu().numpy().astype(np.float32))
        return np.concatenate(batches, axis=0) if batches else np.zeros((0, 1), dtype=np.float32)

    def fit(self, texts: Sequence[str]) -> None:
        if self._ensure_real_backend():
            self.is_fitted = True
            return
        texts = [normalize_text(t) for t in texts]
        tfidf = self.vectorizer.fit_transform(texts)
        n_comp = None
        if tfidf.shape[0] > 2 and tfidf.shape[1] > 2:
            n_comp = min(self.n_components, max(2, min(tfidf.shape[0] - 1, tfidf.shape[1] - 1)))
        if n_comp and n_comp >= 2:
            self.svd = TruncatedSVD(n_components=n_comp, random_state=42)
            dense = self.svd.fit_transform(tfidf)
            self.normalizer.fit(dense)
        self.runtime_backend = 'tfidf_svd'
        self.is_fitted = True

    def _encode_tfidf(self, texts: Sequence[str]) -> np.ndarray:
        texts = [normalize_text(t) for t in texts]
        tfidf = self.vectorizer.transform(texts)
        if self.svd is not None:
            dense = self.svd.transform(tfidf)
            dense = self.normalizer.transform(dense)
            return np.asarray(dense, dtype=np.float32)
        arr = tfidf.toarray().astype(np.float32)
        norms = np.linalg.norm(arr, axis=1, keepdims=True) + 1e-12
        return arr / norms

    def encode_documents(self, texts: Sequence[str]) -> np.ndarray:
        if not self.is_fitted:
            self.fit(texts)
        if self.runtime_backend in {'bge_m3', 'hf_encoder'} and self._tokenizer is not None and self._model is not None:
            return self._encode_real(texts)
        return self._encode_tfidf(texts)

    def encode_queries(self, texts: Sequence[str]) -> np.ndarray:
        if not self.is_fitted:
            raise RuntimeError('DenseEmbedder 需要先 fit 文档语料。')
        if self.runtime_backend in {'bge_m3', 'hf_encoder'} and self._tokenizer is not None and self._model is not None:
            return self._encode_real(texts)
        return self._encode_tfidf(texts)

    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('wb') as f:
            pickle.dump(self, f)

    @staticmethod
    def load(path: str | Path) -> 'DenseEmbedder':
        with Path(path).open('rb') as f:
            return pickle.load(f)
