from __future__ import annotations

from typing import Dict, List, Optional

from .dense_retriever import DenseRetriever
from .reranker import BaseReranker
from .schemas import RetrievedChunk
from .sparse_retriever import BM25Retriever


class HybridRetriever:
    def __init__(self, sparse: BM25Retriever, dense: DenseRetriever, dense_weight: float = 0.6, sparse_weight: float = 0.4, reranker: Optional[BaseReranker] = None):
        self.sparse = sparse
        self.dense = dense
        self.dense_weight = dense_weight
        self.sparse_weight = sparse_weight
        self.reranker = reranker

    def search(self, query: str, top_k: int = 5, retrieve_k: int = 12, filters: Optional[Dict[str, str]] = None, use_reranker: bool = True) -> List[RetrievedChunk]:
        sparse_hits = self.sparse.search(query, top_k=retrieve_k, filters=filters)
        dense_hits = self.dense.search(query, top_k=retrieve_k, filters=filters)
        sparse_norm = self._normalize([x.sparse_score for x in sparse_hits])
        dense_norm = self._normalize([x.dense_score for x in dense_hits])
        merged: Dict[str, RetrievedChunk] = {}
        for hit, score in zip(sparse_hits, sparse_norm):
            merged[hit.chunk_id] = RetrievedChunk(**{**hit.to_dict(), 'score': self.sparse_weight * score, 'sparse_score': hit.sparse_score})
        for hit, score in zip(dense_hits, dense_norm):
            if hit.chunk_id not in merged:
                merged[hit.chunk_id] = RetrievedChunk(**{**hit.to_dict(), 'score': self.dense_weight * score, 'dense_score': hit.dense_score})
            else:
                existing = merged[hit.chunk_id]
                existing.score += self.dense_weight * score
                existing.dense_score = hit.dense_score
        ranked = sorted(merged.values(), key=lambda x: x.score, reverse=True)
        if use_reranker and self.reranker is not None and ranked:
            ranked = self.reranker.rerank(query, ranked, top_k=min(retrieve_k, len(ranked)))
        return ranked[:top_k]

    @staticmethod
    def _normalize(scores: List[float]) -> List[float]:
        if not scores:
            return []
        lo, hi = min(scores), max(scores)
        if abs(hi - lo) < 1e-12:
            return [1.0 for _ in scores]
        return [(s - lo) / (hi - lo) for s in scores]
