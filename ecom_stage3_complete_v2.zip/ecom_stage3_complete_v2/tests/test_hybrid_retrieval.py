from ecom_stage1.rag.chunker import DocumentChunker
from ecom_stage1.rag.dense_retriever import DenseRetriever
from ecom_stage1.rag.hybrid_retriever import HybridRetriever
from ecom_stage1.rag.reranker import SimpleHeuristicReranker
from ecom_stage1.rag.schemas import KnowledgeDocument
from ecom_stage1.rag.sparse_retriever import BM25Retriever


def test_hybrid_returns_relevant_refund_chunk():
    docs = [
        KnowledgeDocument(id='d1', title='退款规则', text='质量问题在签收后7天内可申请售后，并上传故障图片。', source_path='x', source_type='rule'),
        KnowledgeDocument(id='d2', title='物流说明', text='物流状态需要依赖系统查询，不能凭空判断。', source_path='y', source_type='rule'),
    ]
    chunker = DocumentChunker(chunk_size=100, chunk_overlap=10, min_chunk_size=20)
    chunks = chunker.chunk_documents(docs)
    sparse = BM25Retriever(); sparse.fit(chunks)
    dense = DenseRetriever(); dense.fit(chunks)
    hybrid = HybridRetriever(sparse, dense, reranker=SimpleHeuristicReranker())
    hits = hybrid.search('商品有质量问题怎么退款', top_k=2)
    assert hits
    assert hits[0].doc_id == 'd1'
