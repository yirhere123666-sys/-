
from ecom_stage1.rag.embeddings import DenseEmbedder
from ecom_stage1.rag.reranker import TransformerCrossEncoderReranker
from ecom_stage1.rag.schemas import RetrievedChunk


def test_dense_embedder_bge_falls_back_without_runtime_model():
    emb = DenseEmbedder(backend='bge_m3', model_name='__missing_model__')
    vecs = emb.encode_documents(['退款规则', '物流规则'])
    assert vecs.shape[0] == 2
    assert emb.runtime_backend in {'tfidf_svd', 'bge_m3'}


def test_transformer_reranker_falls_back_to_heuristic():
    rr = TransformerCrossEncoderReranker(model_name='__missing_model__')
    hits = [
        RetrievedChunk(chunk_id='1', doc_id='d1', title='退款规则', text='质量问题支持退款', source_type='rule', score=0.5),
        RetrievedChunk(chunk_id='2', doc_id='d2', title='物流规则', text='物流状态需系统查询', source_type='rule', score=0.4),
    ]
    out = rr.rerank('质量问题怎么退款', hits, top_k=2)
    assert out
    assert out[0].doc_id == 'd1'
