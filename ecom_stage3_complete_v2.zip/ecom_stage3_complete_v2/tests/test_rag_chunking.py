from ecom_stage1.rag.chunker import DocumentChunker
from ecom_stage1.rag.schemas import KnowledgeDocument


def test_chunker_splits_long_doc():
    doc = KnowledgeDocument(
        id='doc1', title='退款规则', text='。'.join(['若确认质量问题可在7天内申请售后并上传图片'] * 20), source_path='x', source_type='rule'
    )
    chunker = DocumentChunker(chunk_size=80, chunk_overlap=10, min_chunk_size=20)
    chunks = chunker.chunk_documents([doc])
    assert len(chunks) >= 2
    assert all(c.doc_id == 'doc1' for c in chunks)
