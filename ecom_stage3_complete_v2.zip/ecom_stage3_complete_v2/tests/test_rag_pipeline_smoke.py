from pathlib import Path

from ecom_stage1.io_utils import dump_jsonl
from ecom_stage1.rag.chunker import DocumentChunker
from ecom_stage1.rag.dense_retriever import DenseRetriever
from ecom_stage1.rag.pipeline import RAGPipeline
from ecom_stage1.rag.schemas import Chunk, KnowledgeDocument
from ecom_stage1.rag.sparse_retriever import BM25Retriever


def test_pipeline_smoke(tmp_path: Path):
    docs = [KnowledgeDocument(id='d1', title='NFC说明', text='支持NFC，门禁兼容性需以具体设备和系统为准。', source_path='x', source_type='product')]
    chunks = DocumentChunker(chunk_size=100, chunk_overlap=10, min_chunk_size=20).chunk_documents(docs)
    index_dir = tmp_path / 'index'
    index_dir.mkdir()
    sparse = BM25Retriever(); sparse.fit(chunks); sparse.save(index_dir / 'bm25.pkl')
    dense = DenseRetriever(); dense.fit(chunks); dense.save(index_dir / 'dense.pkl')
    (index_dir / 'manifest.json').write_text('{"num_chunks": 1}', encoding='utf-8')
    prompt = tmp_path / 'rag_prompt.txt'
    prompt.write_text('你是电商客服。', encoding='utf-8')
    pipeline = RAGPipeline(index_dir=index_dir, system_prompt_path=prompt, generator_backend='extractive')
    pred = pipeline.answer(sample_id='e1', query='这款手机支持NFC吗？可以刷门禁吗？')
    assert 'NFC' in pred.answer or '兼容性' in pred.answer
