
#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from ecom_stage1.io_utils import load_records
from ecom_stage1.rag.dense_retriever import DenseRetriever
from ecom_stage1.rag.schemas import Chunk
from ecom_stage1.rag.sparse_retriever import BM25Retriever


def main() -> None:
    parser = argparse.ArgumentParser(description='构建第三阶段检索索引')
    parser.add_argument('--chunks', default=str(ROOT / 'data' / 'kb' / 'processed' / 'kb_chunks.jsonl'))
    parser.add_argument('--index-dir', default=str(ROOT / 'data' / 'indexes' / 'rag_stage3'))
    parser.add_argument('--use-faiss', action='store_true')
    parser.add_argument('--dense-backend', choices=['tfidf_svd', 'bge_m3', 'hf_encoder'], default='bge_m3')
    parser.add_argument('--dense-model-name', default='BAAI/bge-m3')
    parser.add_argument('--reranker-type', choices=['heuristic', 'cross_encoder', 'bge_reranker'], default='cross_encoder')
    parser.add_argument('--reranker-model-name', default='BAAI/bge-reranker-v2-m3')
    args = parser.parse_args()

    index_dir = Path(args.index_dir)
    index_dir.mkdir(parents=True, exist_ok=True)
    chunks = [Chunk(**row) for row in load_records(args.chunks)]

    sparse = BM25Retriever()
    sparse.fit(chunks)
    sparse.save(index_dir / 'bm25.pkl')

    dense = DenseRetriever(
        use_faiss=args.use_faiss,
        embedding_backend=args.dense_backend,
        embedding_model_name=args.dense_model_name,
    )
    dense.fit(chunks)
    dense.save(index_dir / 'dense.pkl')

    manifest = {
        'num_chunks': len(chunks),
        'use_faiss': bool(args.use_faiss),
        'chunk_source': str(args.chunks),
        'dense': {
            'backend': args.dense_backend,
            'model_name': args.dense_model_name,
            'runtime_backend': getattr(dense.embedder, 'runtime_backend', args.dense_backend),
        },
        'reranker': {
            'type': args.reranker_type,
            'model_name': args.reranker_model_name,
        },
    }
    (index_dir / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'检索索引构建完成 -> {index_dir}')


if __name__ == '__main__':
    main()
