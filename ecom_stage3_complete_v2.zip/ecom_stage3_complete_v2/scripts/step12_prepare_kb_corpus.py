#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from ecom_stage1.io_utils import dump_jsonl, iter_records
from ecom_stage1.rag.knowledge_loader import KnowledgeLoader


def infer_source_type_from_category(category: str) -> str:
    cat = (category or '').lower()
    if any(k in cat for k in ['refund', '退', '物流', '订单', '规则', 'invoice', '发票']):
        return 'rule'
    if any(k in cat for k in ['product', '商品', '参数', 'sku']):
        return 'product'
    return 'faq'


def main() -> None:
    parser = argparse.ArgumentParser(description='构建第三阶段知识库原始语料')
    parser.add_argument('--cleaned-records', default=str(ROOT / 'data' / 'processed' / 'cleaned.json'))
    parser.add_argument('--kb-dir', default=str(ROOT / 'data' / 'kb' / 'raw'))
    parser.add_argument('--output', default=str(ROOT / 'data' / 'kb' / 'processed' / 'kb_corpus.jsonl'))
    parser.add_argument('--include-cleaned', action='store_true')
    args = parser.parse_args()

    rows = []
    kb_loader = KnowledgeLoader(args.kb_dir)
    for doc in kb_loader.load():
        rows.append(doc.to_dict())

    cleaned_path = Path(args.cleaned_records)
    if args.include_cleaned and cleaned_path.exists():
        for idx, rec in enumerate(iter_records(cleaned_path)):
            category = rec.get('category', 'faq')
            text = f"问题: {rec.get('user_query', '')}\n答案: {rec.get('assistant_reply', '')}".strip()
            rows.append({
                'id': f'cleaned_{idx}',
                'title': f'cleaned_{category}_{idx}',
                'text': text,
                'source_path': str(cleaned_path),
                'source_type': infer_source_type_from_category(category),
                'metadata': {
                    'category': category,
                    'origin': 'stage1_cleaned',
                    **rec.get('metadata', {}),
                },
            })

    dump_jsonl(rows, args.output)
    print(f'知识库语料已输出 -> {args.output}，共 {len(rows)} 条')


if __name__ == '__main__':
    main()
