#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from ecom_stage1.io_utils import dump_jsonl, load_records
from ecom_stage1.rag.chunker import DocumentChunker
from ecom_stage1.rag.schemas import KnowledgeDocument


def main() -> None:
    parser = argparse.ArgumentParser(description='对知识库文档进行切块')
    parser.add_argument('--input', default=str(ROOT / 'data' / 'kb' / 'processed' / 'kb_corpus.jsonl'))
    parser.add_argument('--output', default=str(ROOT / 'data' / 'kb' / 'processed' / 'kb_chunks.jsonl'))
    parser.add_argument('--chunk-size', type=int, default=320)
    parser.add_argument('--chunk-overlap', type=int, default=60)
    parser.add_argument('--min-chunk-size', type=int, default=80)
    args = parser.parse_args()

    docs = [KnowledgeDocument(**row) for row in load_records(args.input)]
    chunker = DocumentChunker(args.chunk_size, args.chunk_overlap, args.min_chunk_size)
    chunks = chunker.chunk_documents(docs)
    dump_jsonl([c.to_dict() for c in chunks], args.output)
    print(f'知识块已输出 -> {args.output}，共 {len(chunks)} 条')


if __name__ == '__main__':
    main()
