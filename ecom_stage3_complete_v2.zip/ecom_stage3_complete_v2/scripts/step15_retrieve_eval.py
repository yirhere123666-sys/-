
#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from ecom_stage1.io_utils import dump_json, load_records
from ecom_stage1.rag.context_builder import ContextBuilder
from ecom_stage1.rag.dense_retriever import DenseRetriever
from ecom_stage1.rag.hybrid_retriever import HybridRetriever
from ecom_stage1.rag.reranker import SimpleHeuristicReranker, TransformerCrossEncoderReranker
from ecom_stage1.rag.retrieval_eval import citation_precision, context_keyword_recall, mean_reciprocal_rank_by_keywords, source_diversity, topk_hit_rate
from ecom_stage1.rag.sparse_retriever import BM25Retriever


def main() -> None:
    parser = argparse.ArgumentParser(description='在评测集上执行混合召回并导出结果')
    parser.add_argument('--eval-set', default=str(ROOT / 'data' / 'eval' / 'eval_set.json'))
    parser.add_argument('--index-dir', default=str(ROOT / 'data' / 'indexes' / 'rag_stage3'))
    parser.add_argument('--output', default=str(ROOT / 'data' / 'eval' / 'retrieved_eval.json'))
    parser.add_argument('--top-k', type=int, default=5)
    parser.add_argument('--retrieve-k', type=int, default=12)
    parser.add_argument('--dense-weight', type=float, default=0.6)
    parser.add_argument('--sparse-weight', type=float, default=0.4)
    parser.add_argument('--reranker-type', choices=['auto', 'heuristic', 'cross_encoder', 'bge_reranker'], default='auto')
    args = parser.parse_args()

    manifest_path = Path(args.index_dir) / 'manifest.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8')) if manifest_path.exists() else {}
    reranker_type = args.reranker_type
    if reranker_type == 'auto':
        reranker_type = manifest.get('reranker', {}).get('type', 'heuristic')
    reranker_model_name = manifest.get('reranker', {}).get('model_name', 'BAAI/bge-reranker-v2-m3')

    sparse = BM25Retriever.load(Path(args.index_dir) / 'bm25.pkl')
    dense = DenseRetriever.load(Path(args.index_dir) / 'dense.pkl')
    reranker = TransformerCrossEncoderReranker(model_name=reranker_model_name) if reranker_type in {'cross_encoder', 'bge_reranker'} else SimpleHeuristicReranker()
    hybrid = HybridRetriever(sparse, dense, dense_weight=args.dense_weight, sparse_weight=args.sparse_weight, reranker=reranker)
    builder = ContextBuilder()

    rows = []
    for sample in load_records(args.eval_set):
        hits = hybrid.search(sample['query'], top_k=args.top_k, retrieve_k=max(args.retrieve_k, args.top_k), use_reranker=True)
        context, citations = builder.build(hits)
        must_mention = sample.get('must_mention', [])
        rows.append({
            'id': sample['id'],
            'query': sample['query'],
            'category': sample.get('category', 'unknown'),
            'must_mention': must_mention,
            'retrieved_chunks': [h.to_dict() for h in hits],
            'context': context,
            'citations': citations,
            'context_keyword_recall': context_keyword_recall(context, must_mention),
            'hit@5': topk_hit_rate(hits, must_mention, k=min(5, len(hits))),
            'hit@10': topk_hit_rate(hits, must_mention, k=min(10, len(hits))),
            'mrr': mean_reciprocal_rank_by_keywords(hits, must_mention),
            'citation_precision@5': citation_precision(hits, must_mention, k=min(5, len(hits))),
            'source_diversity@5': source_diversity(hits, k=min(5, len(hits))),
        })
    dump_json(rows, args.output)
    print(f'评测集检索结果已输出 -> {args.output}')


if __name__ == '__main__':
    main()
