#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python scripts/step12_prepare_kb_corpus.py
python scripts/step13_chunk_kb.py
python scripts/step14_build_indexes.py --dense-backend bge_m3 --dense-model-name BAAI/bge-m3 --reranker-type cross_encoder --reranker-model-name BAAI/bge-reranker-v2-m3
python scripts/step15_retrieve_eval.py --reranker-type auto
python scripts/step16_generate_rag_predictions.py --backend extractive
python scripts/step17_eval_rag.py

echo "Stage3 pipeline complete."
