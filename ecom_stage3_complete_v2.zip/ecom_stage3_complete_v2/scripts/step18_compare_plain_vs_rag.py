#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from ecom_stage1.io_utils import dump_json, load_records
from ecom_stage1.metrics import binary_accuracy_from_rules, is_invalid_refusal, squad_like_f1


def score_answer(answer: str, ref: dict) -> float:
    acc = binary_accuracy_from_rules(answer, ref['reference_answer'], ref.get('must_mention', []), ref.get('forbidden_patterns', []))
    f1 = squad_like_f1(answer, ref['reference_answer'])
    invalid = int(is_invalid_refusal(answer, ref.get('can_answer_directly', True)))
    return 0.5 * acc + 0.4 * f1 - 0.1 * invalid


def main() -> None:
    parser = argparse.ArgumentParser(description='对比 plain model 与 RAG 输出')
    parser.add_argument('--eval-set', default=str(ROOT / 'data' / 'eval' / 'eval_set.json'))
    parser.add_argument('--plain-predictions', required=True)
    parser.add_argument('--rag-predictions', default=str(ROOT / 'data' / 'eval' / 'rag_predictions.json'))
    parser.add_argument('--output', default=str(ROOT / 'data' / 'eval' / 'plain_vs_rag_compare.json'))
    args = parser.parse_args()

    eval_rows = {r['id']: r for r in load_records(args.eval_set)}
    plain_rows = {r['id']: r for r in load_records(args.plain_predictions)}
    rag_rows = {r['id']: r for r in load_records(args.rag_predictions)}

    details = []
    wins = 0
    ties = 0
    total = 0
    for sample_id, ref in eval_rows.items():
        if sample_id not in plain_rows or sample_id not in rag_rows:
            continue
        plain_ans = plain_rows[sample_id].get('prediction') or plain_rows[sample_id].get('answer', '')
        rag_ans = rag_rows[sample_id].get('prediction') or rag_rows[sample_id].get('answer', '')
        plain_score = score_answer(plain_ans, ref)
        rag_score = score_answer(rag_ans, ref)
        if abs(rag_score - plain_score) < 1e-6:
            winner = 'tie'
            ties += 1
        elif rag_score > plain_score:
            winner = 'rag'
            wins += 1
        else:
            winner = 'plain'
        total += 1
        details.append({
            'id': sample_id,
            'winner': winner,
            'plain_score': plain_score,
            'rag_score': rag_score,
            'plain_answer': plain_ans,
            'rag_answer': rag_ans,
        })
    summary = {
        'rag_win_rate': wins / total if total else 0.0,
        'tie_rate': ties / total if total else 0.0,
        'num_samples': total,
    }
    dump_json({'summary': summary, 'details': details}, args.output)
    print(f'plain vs RAG 对比结果已输出 -> {args.output}')


if __name__ == '__main__':
    main()
