
#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from ecom_stage1.io_utils import dump_json, load_records
from ecom_stage1.rag.pipeline import RAGPipeline


def main() -> None:
    parser = argparse.ArgumentParser(description='基于第三阶段 RAG pipeline 生成离线预测')
    parser.add_argument('--eval-set', default=str(ROOT / 'data' / 'eval' / 'eval_set.json'))
    parser.add_argument('--index-dir', default=str(ROOT / 'data' / 'indexes' / 'rag_stage3'))
    parser.add_argument('--system-prompt', default=str(ROOT / 'prompts' / 'rag_system_prompt.txt'))
    parser.add_argument('--backend', choices=['extractive', 'hf', 'vllm'], default='extractive')
    parser.add_argument('--base-model', default='Qwen/Qwen2-7B-Instruct')
    parser.add_argument('--model-path', default='')
    parser.add_argument('--top-k', type=int, default=5)
    parser.add_argument('--reranker-type', choices=['auto', 'heuristic', 'cross_encoder', 'bge_reranker'], default='auto')
    parser.add_argument('--output', default=str(ROOT / 'data' / 'eval' / 'rag_predictions.json'))
    args = parser.parse_args()

    pipeline = RAGPipeline(
        index_dir=args.index_dir,
        system_prompt_path=args.system_prompt,
        generator_backend=args.backend,
        base_model=args.base_model,
        model_path=args.model_path or None,
        reranker_type=None if args.reranker_type == 'auto' else args.reranker_type,
    )

    rows = []
    for sample in load_records(args.eval_set):
        pred = pipeline.answer(
            sample_id=sample['id'],
            query=sample['query'],
            history=sample.get('history', []),
            top_k=args.top_k,
        )
        rows.append(pred.to_dict())
    dump_json(rows, args.output)
    print(f'RAG 预测结果已输出 -> {args.output}')


if __name__ == '__main__':
    main()
