
#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from ecom_stage1.io_utils import dump_json, load_records
from ecom_stage1.metrics import binary_accuracy_from_rules, heuristic_hallucination, is_invalid_refusal, keyword_coverage, squad_like_f1
from ecom_stage1.rag.retrieval_eval import retrieval_summary


def main() -> None:
    parser = argparse.ArgumentParser(description='评估第三阶段 RAG 输出')
    parser.add_argument('--eval-set', default=str(ROOT / 'data' / 'eval' / 'eval_set.json'))
    parser.add_argument('--predictions', default=str(ROOT / 'data' / 'eval' / 'rag_predictions.json'))
    parser.add_argument('--retrieval', default=str(ROOT / 'data' / 'eval' / 'retrieved_eval.json'))
    parser.add_argument('--output', default=str(ROOT / 'data' / 'eval' / 'rag_eval_summary.json'))
    args = parser.parse_args()

    eval_rows = {row['id']: row for row in load_records(args.eval_set)}
    pred_rows = load_records(args.predictions)
    retrieval_rows = load_records(args.retrieval) if Path(args.retrieval).exists() else []
    retrieval_map = {row['id']: row for row in retrieval_rows}

    details = []
    for pred in pred_rows:
        ref = eval_rows[pred['id']]
        prediction = pred['answer']
        retr = retrieval_map.get(pred['id'], {})
        detail = {
            'id': pred['id'],
            'category': ref.get('category', 'unknown'),
            'f1': squad_like_f1(prediction, ref['reference_answer']),
            'keyword_coverage': keyword_coverage(prediction, ref.get('must_mention', [])),
            'accuracy': binary_accuracy_from_rules(prediction, ref['reference_answer'], ref.get('must_mention', []), ref.get('forbidden_patterns', [])),
            'invalid_refusal': int(is_invalid_refusal(prediction, ref.get('can_answer_directly', True))),
            'hallucination': int(heuristic_hallucination(prediction, ref['reference_answer'], ref.get('forbidden_patterns', []))),
            'context_keyword_recall': retr.get('context_keyword_recall', 0.0),
            'hit@5': retr.get('hit@5', 0),
            'hit@10': retr.get('hit@10', 0),
            'mrr': retr.get('mrr', 0.0),
            'citation_precision@5': retr.get('citation_precision@5', 0.0),
            'source_diversity@5': retr.get('source_diversity@5', 0.0),
        }
        details.append(detail)

    n = len(details) or 1
    retr_summary = retrieval_summary(retrieval_rows)
    summary = {
        'accuracy': sum(d['accuracy'] for d in details) / n,
        'f1': sum(d['f1'] for d in details) / n,
        'keyword_coverage': sum(d['keyword_coverage'] for d in details) / n,
        'invalid_refusal_rate': sum(d['invalid_refusal'] for d in details) / n,
        'hallucination_rate': sum(d['hallucination'] for d in details) / n,
        'context_keyword_recall': retr_summary['context_keyword_recall'],
        'hit@5': retr_summary['hit@5'],
        'hit@10': retr_summary['hit@10'],
        'mrr': retr_summary['mrr'],
        'citation_precision@5': retr_summary['citation_precision@5'],
        'source_diversity@5': retr_summary['source_diversity@5'],
        'num_samples': len(details),
    }

    dump_json({'summary': summary, 'details': details}, args.output)
    print(f'RAG 评测结果已输出 -> {args.output}')


if __name__ == '__main__':
    main()
