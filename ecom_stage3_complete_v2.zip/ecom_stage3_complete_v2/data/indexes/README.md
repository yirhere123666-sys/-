第三阶段检索索引会生成在这里，例如 rag_stage3/bm25.pkl、dense.pkl、manifest.json。
