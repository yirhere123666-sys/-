第三阶段知识库处理中间产物将生成在这里，例如 kb_corpus.jsonl、kb_chunks.jsonl。
