将 FAQ、SOP、商品参数和规则文档放在这里。支持 txt / md / json / jsonl / csv。
