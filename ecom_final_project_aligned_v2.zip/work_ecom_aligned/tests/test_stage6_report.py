from ecom_stage1.stage6.report import build_markdown_report
from ecom_stage1.stage6.schemas import StageSummary, BadcaseRecord


def test_stage6_report_contains_sections():
    md = build_markdown_report(
        'Demo',
        [StageSummary(stage='stage3', metrics={'accuracy': 0.8}, available=True)],
        [BadcaseRecord(stage='stage3', case_id='x', category='物流', severity='high', failure_type='hallucination')],
    )
    assert '# Demo - Stage 6 系统级评测与复盘报告' in md
    assert '## 各阶段指标快照' in md
    assert '## 高优先级 badcase' in md
