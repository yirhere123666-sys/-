from __future__ import annotations

from pathlib import Path

from ecom_stage1.service.orchestrator import Stage5ServingOrchestrator
from ecom_stage1.service.schemas import ChatRequest


def test_stage5_health_and_modes(project_root: Path):
    orch = Stage5ServingOrchestrator(project_root)
    health = orch.health()
    assert health.status == 'ok'

    rag_resp = orch.handle(ChatRequest(mode='rag', query='7天内质量问题如何退款？', use_cache=False))
    assert rag_resp.answer

    agent_resp = orch.handle(ChatRequest(mode='agent', query='订单 A1001 现在物流到哪了？', use_cache=False))
    assert agent_resp.answer
    assert agent_resp.route is not None


def test_stage5_cache(project_root: Path):
    orch = Stage5ServingOrchestrator(project_root)
    req = ChatRequest(mode='plain', query='退货流程是什么？', use_cache=True)
    r1 = orch.handle(req)
    r2 = orch.handle(req)
    assert r2.latency.cache_hit is True
