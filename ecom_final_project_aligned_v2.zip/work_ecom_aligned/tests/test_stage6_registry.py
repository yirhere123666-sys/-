from pathlib import Path

from ecom_stage1.stage6.registry import collect_stage_artifacts, build_stage_summary_table


def test_stage6_registry_collects(project_root: Path):
    artifacts = collect_stage_artifacts(project_root / 'configs' / 'stage6_registry.yaml', project_root)
    assert any(a.stage == 'stage3' and a.exists for a in artifacts)
    summaries = build_stage_summary_table(artifacts)
    names = {s.stage for s in summaries}
    assert 'stage3' in names and 'stage4' in names and 'stage5' in names
