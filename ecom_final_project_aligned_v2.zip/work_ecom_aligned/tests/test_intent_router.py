
from pathlib import Path

from ecom_stage1.agent.intent_router import IntentRouter


def test_intent_router_order_and_handoff(project_root: Path):
    router = IntentRouter(project_root / 'configs/intent_router.yaml')
    r1 = router.route('我的订单12345678发货了吗')
    assert r1.route_name == 'order_or_logistics_query'
    assert any(tc.name == 'get_order_status' for tc in r1.tool_calls)
    assert any(tc.name == 'get_logistics_by_order' for tc in r1.tool_calls)
    r2 = router.route('我要投诉，给我转人工')
    assert r2.route_type == 'handoff'
