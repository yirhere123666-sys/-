from ecom_stage1.alignment.entity_replacer import DomainEntityReplacer


def test_entity_replacement_refund_window():
    r = DomainEntityReplacer()
    outs = r.apply('支持7天无理由退货', 'refund_request')
    assert any(o.reject_type == 'extend_return_window' for o in outs)
