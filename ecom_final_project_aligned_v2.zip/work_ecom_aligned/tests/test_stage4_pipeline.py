
from pathlib import Path

from ecom_stage1.agent.pipeline import Stage4AgentPipeline


def test_stage4_pipeline_routes_and_actions(project_root: Path):
    pipeline = Stage4AgentPipeline(
        rag_index_dir=project_root / 'data/indexes/rag_stage3',
        rag_system_prompt_path=project_root / 'prompts/rag_system_prompt.txt',
        stage4_system_prompt_path=project_root / 'prompts/agent_system_prompt.txt',
        api_data_dir=project_root / 'data/apis',
        generator_backend='extractive',
        intent_router_config=project_root / 'configs/intent_router.yaml',
        rules_engine_config=project_root / 'configs/rules_engine.yaml',
    )
    # logistics query -> api_only
    p1 = pipeline.answer('x1', '我的订单12345678现在发货了吗？')
    assert p1.route.route_name == 'order_or_logistics_query'
    assert p1.rule_decision.action == 'api_only'
    assert '待发货' in p1.answer
    # cancel shipped -> deny
    p2 = pipeline.answer('x2', '订单87654321还能取消吗？')
    assert p2.route.route_name == 'cancel_order'
    assert p2.rule_decision.action == 'deny'
    # angry -> handoff
    p3 = pipeline.answer('x3', '再不处理我就投诉，你们人工出来。')
    assert p3.rule_decision.action == 'handoff'
