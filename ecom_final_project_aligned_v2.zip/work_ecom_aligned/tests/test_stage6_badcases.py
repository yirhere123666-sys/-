import json
from pathlib import Path

from ecom_stage1.stage6.badcase import mine_badcases


def test_stage6_badcase_mining(project_root: Path):
    rag_eval = json.loads((project_root / 'data' / 'eval' / 'rag_eval_summary.json').read_text(encoding='utf-8'))
    stage4_eval = json.loads((project_root / 'data' / 'eval' / 'stage4_eval_summary.json').read_text(encoding='utf-8'))
    compare = json.loads((project_root / 'data' / 'eval' / 'rag_vs_agent_compare.json').read_text(encoding='utf-8'))
    badcases = mine_badcases(rag_eval=rag_eval, stage4_eval=stage4_eval, compare_rag_agent=compare, top_n=10)
    assert len(badcases) > 0
    assert any(b.failure_type in {'hallucination', 'low_f1', 'action_miss'} for b in badcases)
