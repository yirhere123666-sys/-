
from pathlib import Path

from ecom_stage1.agent.rules_engine import RulesEngine
from ecom_stage1.agent.schemas import RouteDecision, ToolResult


def test_rules_engine_cancel_and_refund(project_root: Path):
    rules = RulesEngine(project_root / 'configs/rules_engine.yaml')
    cancel_route = RouteDecision(route_name='cancel_order', route_type='api', confidence=0.9)
    shipped = ToolResult(name='get_order_status', success=True, payload={'found': True, 'status': 'shipped'})
    dec = rules.apply('订单87654321还能取消吗', cancel_route, [shipped])
    assert dec.action == 'deny'

    refund_route = RouteDecision(route_name='refund_or_aftersale', route_type='mixed', confidence=0.9, extracted_entities={'order_ids': []})
    dec2 = rules.apply('耳机有问题，直接全额退款', refund_route, [])
    assert dec2.action in {'rag_with_guardrails', 'tool_then_rag'}
