# 电商客服大模型问答系统 - Stage 6 系统级评测与复盘报告

生成时间：2026-04-15T11:03:14.064178+00:00Z

## 全链路架构

```mermaid
flowchart LR
A[Stage1 数据工程] --> B[Stage2 SFT/DPO 训练验证]
B --> C[Stage3 RAG 检索链]
C --> D[Stage4 Agent/规则/API]
D --> E[Stage5 服务层与性能优化]
E --> F[Stage6 评测/复盘/包装]
```

## 各阶段指标快照

### stage1
- 状态：缺少产物
- note: missing:stage1_eval_summary
- note: missing:stage1_compare

### stage3
- accuracy: 0.0000
- f1: 0.1478
- keyword_coverage: 0.8333
- invalid_refusal_rate: 0.0000
- hallucination_rate: 0.6667
- context_keyword_recall: 0.8333
- hit@5: 1.0000
- hit@10: 1.0000
- mrr: 1.0000
- citation_precision@5: 0.4000
- source_diversity@5: 0.6000
- num_samples: 3
- note: missing:plain_vs_rag_compare

### stage4
- num_samples: 7
- route_accuracy: 1.0000
- action_accuracy: 1.0000
- avg_f1: 0.0410
- avg_keyword_coverage: 0.7857
- forbidden_violation_rate: 0.0000
- hallucination_rate: 0.0000
- invalid_refusal_rate: 0.0000
- handoff_precision: 1.0000
- action_distribution: {'api_only': 1, 'deny': 1, 'tool_then_rag': 3, 'rag_with_guardrails': 1, 'handoff': 1}
- compare.num_samples: 7
- compare.agent_win_rate: 1.0000

### stage5
- service.requests_total: 4
- service.by_mode: {'plain': 1, 'rag': 1, 'agent': 2}
- service.avg_total_ms: 1.9800
- service.avg_first_chunk_ms: 0.0000
- service.cache_hits: 0
- service.error_count: 0
- service.handoff_count: 1

## 高优先级 badcase

### [CRITICAL] stage3 / eval_001 / hallucination
- category: 退换货
- recommendation: 优先检查 chunk 粒度、召回噪声和 context builder 规则。
- id: eval_001
- category: 退换货
- f1: 0.1935
- keyword_coverage: 1.0000
- accuracy: 0
- invalid_refusal: 0
- hallucination: 1
- context_keyword_recall: 1.0000
- hit@5: 1
- hit@10: 1
- mrr: 1.0000
- citation_precision@5: 0.4000
- source_diversity@5: 0.6000

### [CRITICAL] stage3 / eval_003 / hallucination
- category: 物流
- recommendation: 优先检查 chunk 粒度、召回噪声和 context builder 规则。
- id: eval_003
- category: 物流
- f1: 0.0000
- keyword_coverage: 0.5000
- accuracy: 0
- invalid_refusal: 0
- hallucination: 1
- context_keyword_recall: 0.5000
- hit@5: 1
- hit@10: 1
- mrr: 1.0000
- citation_precision@5: 0.2000
- source_diversity@5: 0.6000

### [MEDIUM] stage4 / stage4_002 / low_f1
- category: cancel_order
- recommendation: 检查 reference 是否过严，以及 response formatter 是否丢失关键信息。
- id: stage4_002
- route_name: cancel_order
- expected_route: cancel_order
- action: deny
- expected_action: deny
- f1: 0.0000
- keyword_coverage: 0.0000
- forbidden_violation: False
- hallucination: False
- invalid_refusal: False

### [MEDIUM] stage4 / stage4_003 / low_f1
- category: product_info
- recommendation: 检查 reference 是否过严，以及 response formatter 是否丢失关键信息。
- id: stage4_003
- route_name: product_info
- expected_route: product_info
- action: tool_then_rag
- expected_action: tool_then_rag
- f1: 0.1333
- keyword_coverage: 1.0000
- forbidden_violation: False
- hallucination: False
- invalid_refusal: False

### [MEDIUM] stage4 / stage4_004 / low_f1
- category: refund_or_aftersale
- recommendation: 检查 reference 是否过严，以及 response formatter 是否丢失关键信息。
- id: stage4_004
- route_name: refund_or_aftersale
- expected_route: refund_or_aftersale
- action: rag_with_guardrails
- expected_action: rag_with_guardrails
- f1: 0.0000
- keyword_coverage: 1.0000
- forbidden_violation: False
- hallucination: False
- invalid_refusal: False

### [MEDIUM] stage4 / stage4_005 / low_f1
- category: complaint_handoff
- recommendation: 检查 reference 是否过严，以及 response formatter 是否丢失关键信息。
- id: stage4_005
- route_name: complaint_handoff
- expected_route: complaint_handoff
- action: handoff
- expected_action: handoff
- f1: 0.0000
- keyword_coverage: 1.0000
- forbidden_violation: False
- hallucination: False
- invalid_refusal: False

### [MEDIUM] stage4 / stage4_006 / low_f1
- category: invoice_policy
- recommendation: 检查 reference 是否过严，以及 response formatter 是否丢失关键信息。
- id: stage4_006
- route_name: invoice_policy
- expected_route: invoice_policy
- action: tool_then_rag
- expected_action: tool_then_rag
- f1: 0.0000
- keyword_coverage: 0.5000
- forbidden_violation: False
- hallucination: False
- invalid_refusal: False

### [MEDIUM] stage4 / stage4_007 / low_f1
- category: account_help
- recommendation: 检查 reference 是否过严，以及 response formatter 是否丢失关键信息。
- id: stage4_007
- route_name: account_help
- expected_route: account_help
- action: tool_then_rag
- expected_action: tool_then_rag
- f1: 0.0000
- keyword_coverage: 1.0000
- forbidden_violation: False
- hallucination: False
- invalid_refusal: False

## 建议的下一轮优化

- Stage3：继续围绕 hallucination 和 retrieval_weak badcase 调 chunk、hybrid 权重和 reranker top-k。
- Stage4：继续围绕 route_miss / action_miss badcase 补强 intent router、rules engine 和 tool chaining。
- Stage5：继续围绕首块延迟、总延迟和 cache hit 做服务层性能优化。
