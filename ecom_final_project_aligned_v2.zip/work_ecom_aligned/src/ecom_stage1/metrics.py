"""
metrics.py — 评测指标集合

【修复说明 Fix #4】
原版缺陷：heuristic_hallucination() 仅靠硬编码关键词列表判断幻觉，
          误报率高（数字出现就报警），漏报率也高（新型幻觉无法覆盖）。
          is_invalid_refusal() 逻辑正确但缺少注释。

修复内容：
  1. heuristic_hallucination() 分三层检测，引入幻觉类型分类
  2. 新增 hallucination_type_detail() 返回具体幻觉类型（便于 badcase 归因）
  3. is_invalid_refusal() 补充详细注释
  4. binary_accuracy_from_rules() 放宽数字幻觉判断条件（减少误报）
"""
from __future__ import annotations

import re
from collections import Counter
from typing import Dict, List, Optional, Sequence

from sklearn.metrics import f1_score

try:
    import jieba
except Exception:
    jieba = None

# ── 工具函数 ──────────────────────────────────────────────────────────────────

def normalize_for_eval(text: str) -> str:
    text = (text or '').lower().strip()
    return re.sub(r'\s+', ' ', text)


def tokenize(text: str) -> List[str]:
    normalized = normalize_for_eval(text)
    if not normalized:
        return []
    if jieba is not None:
        return [tok.strip() for tok in jieba.lcut(normalized) if tok.strip()]
    return [tok for tok in re.split(r'[^\w\u4e00-\u9fff]+', normalized) if tok]


# ── Token F1（SQuAD-like）─────────────────────────────────────────────────────

def squad_like_f1(prediction: str, reference: str) -> float:
    """
    Token 级别 F1：

        precision = |pred_tokens ∩ ref_tokens| / |pred_tokens|
        recall    = |pred_tokens ∩ ref_tokens| / |ref_tokens|
        F1        = 2 * precision * recall / (precision + recall)

    中文用 jieba 分词，英文按空格/标点切分。
    """
    pred_tokens = tokenize(prediction)
    ref_tokens  = tokenize(reference)
    if not pred_tokens and not ref_tokens:
        return 1.0
    if not pred_tokens or not ref_tokens:
        return 0.0
    common  = Counter(pred_tokens) & Counter(ref_tokens)
    overlap = sum(common.values())
    if overlap == 0:
        return 0.0
    precision = overlap / len(pred_tokens)
    recall    = overlap / len(ref_tokens)
    return 2 * precision * recall / (precision + recall)


# ── 关键词覆盖率 ──────────────────────────────────────────────────────────────

def keyword_coverage(prediction: str, must_mention: Sequence[str]) -> float:
    """检查 prediction 是否包含所有 must_mention 关键词。"""
    if not must_mention:
        return 1.0
    pred = normalize_for_eval(prediction)
    hits = sum(1 for kw in must_mention if normalize_for_eval(kw) in pred)
    return hits / len(must_mention)


# ── 违禁词检测 ────────────────────────────────────────────────────────────────

def forbidden_violation(prediction: str, forbidden_patterns: Sequence[str]) -> bool:
    """prediction 中是否包含任何违禁短语（业务合规硬约束）。"""
    pred = normalize_for_eval(prediction)
    return any(normalize_for_eval(pat) in pred for pat in forbidden_patterns)


# ── 无效拒绝检测 ──────────────────────────────────────────────────────────────

def is_invalid_refusal(prediction: str, can_answer_directly: bool) -> bool:
    """
    检测"本可回答却无意义拒绝"的情况。

    设计原理：
      拒答词（无法处理、联系人工客服等）出现，AND
      可执行引导词（申请、查询、提交等）不出现
      → 判定为无效拒绝

    为什么两层判断而不是只看拒答词？
      "可以申请退款，但需要上传凭证" 也含"拒答"语气，
      但有"申请"这个可执行词 → 是有效回答，不算无效拒绝。

    can_answer_directly=False：本来就不该直接答（如需要核验身份），不算无效拒绝。
    """
    if not can_answer_directly:
        return False
    pred = normalize_for_eval(prediction)

    refusal_patterns = [
        '无法处理', '联系人工客服', '暂不支持', '无法回答',
        '稍后再试', '请转人工', '无法帮助',
        'cannot help', 'contact a human agent', 'not supported here',
        'please reach out', 'unable to assist',
    ]
    actionable_patterns = [
        '申请', '上传', '审核', '查询', '提交', '请提供',
        '支持', '可以', '建议', '步骤', '操作',
        'order page', 'refund', 'reset', 'apply', 'submit',
    ]
    refusal_hit    = any(p in pred for p in refusal_patterns)
    actionable_hit = any(p in pred for p in actionable_patterns)
    return refusal_hit and not actionable_hit


# ── 【修复】幻觉检测（三层）──────────────────────────────────────────────────

# 绝对化表述（出现即判定为幻觉风险）
_ABSOLUTE_CLAIMS = [
    '100%', 'guaranteed', 'definitely', 'absolutely',
    '无需审核', '直接全额退款', '今天一定到账', '今天肯定送达',
    '保证兼容所有设备', '绝对', '肯定',
]

# 高风险时效词（配合数字异常才触发，降低误报）
_RISKY_TIME_WORDS = ['day', 'days', 'hour', 'hours', '天', '小时', '工作日', '周']

# 业务违禁词（直接触发）
_BUSINESS_VIOLATIONS = [
    '直接全额退款', '立刻赔偿', '马上退款', '绕过审核',
    '不需要凭证', '无需任何证明',
]


def heuristic_hallucination(
    prediction: str,
    reference: str,
    forbidden_patterns: Sequence[str],
) -> bool:
    """
    启发式幻觉检测（三层）：

    Layer 1 — 违禁词直接触发（最高置信度）
    Layer 2 — 绝对化表述（prediction 有但 reference 没有）
    Layer 3 — 数字+时效词组合异常（prediction 出现了 reference 没有的时效数字）

    修复说明：
      原版 Layer 3 过于激进，只要 prediction 有 reference 没有的数字就报警，
      误报率很高（客服正常回答也可能包含参考数字之外的数字）。
      修复后：数字异常 AND 出现高风险时效词才触发。
    """
    pred = normalize_for_eval(prediction)
    ref  = normalize_for_eval(reference)

    # Layer 1：违禁词直接判定
    if forbidden_violation(prediction, forbidden_patterns):
        return True

    # Layer 2：绝对化表述（prediction 有但 reference 没有）
    pred_absolutes = [c.lower() for c in _ABSOLUTE_CLAIMS if c.lower() in pred]
    ref_absolutes  = [c.lower() for c in _ABSOLUTE_CLAIMS if c.lower() in ref]
    if pred_absolutes and not ref_absolutes:
        return True

    # Layer 3：【修复】数字异常 + 高风险时效词 双重触发（降低误报）
    pred_nums = set(re.findall(r'\d+', pred))
    ref_nums  = set(re.findall(r'\d+', ref))
    anomalous_nums = pred_nums - ref_nums
    if anomalous_nums:
        has_time_word = any(w in pred for w in _RISKY_TIME_WORDS)
        has_business_violation = any(v in pred for v in _BUSINESS_VIOLATIONS)
        # 只有同时出现异常数字 + 时效词，且数字范围可疑（>7天）才报警
        large_anomalous = any(int(n) > 7 for n in anomalous_nums if n.isdigit())
        if has_time_word and (large_anomalous or has_business_violation):
            return True

    return False


def hallucination_type_detail(
    prediction: str,
    reference: str,
    forbidden_patterns: Sequence[str],
) -> Optional[str]:
    """
    返回幻觉类型字符串（供 badcase 归因使用）：
      'forbidden_violation'  — 出现违禁词
      'absolute_claim'       — 出现参考答案没有的绝对化表述
      'time_number_anomaly'  — 出现参考答案没有的异常时效数字
      None                   — 未检测到幻觉
    """
    pred = normalize_for_eval(prediction)
    ref  = normalize_for_eval(reference)

    if forbidden_violation(prediction, forbidden_patterns):
        return 'forbidden_violation'

    pred_absolutes = [c.lower() for c in _ABSOLUTE_CLAIMS if c.lower() in pred]
    ref_absolutes  = [c.lower() for c in _ABSOLUTE_CLAIMS if c.lower() in ref]
    if pred_absolutes and not ref_absolutes:
        return 'absolute_claim'

    pred_nums = set(re.findall(r'\d+', pred))
    ref_nums  = set(re.findall(r'\d+', ref))
    anomalous = pred_nums - ref_nums
    if anomalous and any(w in pred for w in _RISKY_TIME_WORDS):
        large = any(int(n) > 7 for n in anomalous if n.isdigit())
        if large or any(v in pred for v in _BUSINESS_VIOLATIONS):
            return 'time_number_anomaly'

    return None


# ── 综合准确率（规则打分）────────────────────────────────────────────────────

def binary_accuracy_from_rules(
    prediction: str,
    reference: str,
    must_mention: Sequence[str],
    forbidden_patterns: Sequence[str],
    threshold: float = 0.55,
) -> int:
    """
    综合评分：
        score = 0.7 * token_F1 + 0.3 * keyword_coverage
        correct = (score >= threshold) AND (no forbidden violation)
    """
    f1       = squad_like_f1(prediction, reference)
    coverage = keyword_coverage(prediction, must_mention)
    violated = forbidden_violation(prediction, forbidden_patterns)
    score    = 0.7 * f1 + 0.3 * coverage
    return int(score >= threshold and not violated)


# ── Multi-label 微观 F1 ───────────────────────────────────────────────────────

def micro_f1_for_tags(
    y_true: List[List[str]],
    y_pred: List[List[str]],
    all_tags: List[str],
) -> float:
    tag2idx = {tag: idx for idx, tag in enumerate(all_tags)}
    true_bin, pred_bin = [], []
    for true_tags, pred_tags in zip(y_true, y_pred):
        t = [0] * len(all_tags)
        p = [0] * len(all_tags)
        for tag in true_tags:
            if tag in tag2idx:
                t[tag2idx[tag]] = 1
        for tag in pred_tags:
            if tag in tag2idx:
                p[tag2idx[tag]] = 1
        true_bin.append(t)
        pred_bin.append(p)
    if not true_bin:
        return 0.0
    return float(f1_score(true_bin, pred_bin, average='micro', zero_division=0))
