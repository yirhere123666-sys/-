from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass
class Stage2ExperimentSpec:
    stage: str
    config_path: Path
    dataset_name: str
    output_dir: Path
    adapter_input: Optional[Path] = None
