from __future__ import annotations

import os
from typing import Generator, List, Optional


class OpenAICompatibleClient:
    def __init__(self, base_url: Optional[str] = None, api_key: Optional[str] = None, model: str = 'Qwen/Qwen2-7B-Instruct', timeout: float = 30.0):
        self.base_url = base_url or os.getenv('OPENAI_BASE_URL')
        self.api_key = api_key or os.getenv('OPENAI_API_KEY', 'dummy')
        self.model = model
        self.timeout = timeout
        if not self.base_url:
            raise ValueError('OPENAI_BASE_URL is required for openai_compatible backend')
        try:
            from openai import OpenAI  # type: ignore
        except Exception as e:
            raise RuntimeError('openai package is required for openai_compatible backend') from e
        self.client = OpenAI(base_url=self.base_url, api_key=self.api_key, timeout=timeout)

    def generate(self, messages: List[dict], max_tokens: int = 256, temperature: float = 0.1) -> str:
        resp = self.client.chat.completions.create(model=self.model, messages=messages, max_tokens=max_tokens, temperature=temperature)
        return (resp.choices[0].message.content or '').strip()

    def stream_generate(self, messages: List[dict], max_tokens: int = 256, temperature: float = 0.1) -> Generator[str, None, None]:
        stream = self.client.chat.completions.create(model=self.model, messages=messages, max_tokens=max_tokens, temperature=temperature, stream=True)
        for chunk in stream:
            delta = None
            try:
                delta = chunk.choices[0].delta.content
            except Exception:
                delta = None
            if delta:
                yield delta


class VLLMOpenAIClient(OpenAICompatibleClient):
    """通过 OpenAI-compatible API 调用独立部署的 vLLM 服务。"""
    pass
