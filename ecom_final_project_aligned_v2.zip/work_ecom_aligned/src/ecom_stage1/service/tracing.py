from __future__ import annotations

import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Dict


@dataclass
class RequestTimer:
    started_at: float = field(default_factory=time.perf_counter)
    spans: Dict[str, float] = field(default_factory=dict)
    cache_hit: bool = False

    @contextmanager
    def span(self, name: str):
        start = time.perf_counter()
        try:
            yield
        finally:
            self.spans[name] = self.spans.get(name, 0.0) + (time.perf_counter() - start) * 1000.0

    def total_ms(self) -> float:
        return (time.perf_counter() - self.started_at) * 1000.0


class MetricsRegistry:
    def __init__(self):
        self.requests_total = 0
        self.by_mode = {"plain": 0, "rag": 0, "agent": 0}
        self.total_ms = 0.0
        self.first_chunk_ms = 0.0
        self.cache_hits = 0
        self.error_count = 0
        self.handoff_count = 0

    def observe(self, mode: str, total_ms: float, first_chunk_ms: float = 0.0, cache_hit: bool = False, error: bool = False, handoff: bool = False):
        self.requests_total += 1
        self.by_mode[mode] = self.by_mode.get(mode, 0) + 1
        self.total_ms += total_ms
        self.first_chunk_ms += first_chunk_ms
        self.cache_hits += int(cache_hit)
        self.error_count += int(error)
        self.handoff_count += int(handoff)

    def snapshot(self):
        avg_total = self.total_ms / self.requests_total if self.requests_total else 0.0
        avg_first = self.first_chunk_ms / self.requests_total if self.requests_total else 0.0
        return {
            "requests_total": self.requests_total,
            "by_mode": dict(self.by_mode),
            "avg_total_ms": round(avg_total, 2),
            "avg_first_chunk_ms": round(avg_first, 2),
            "cache_hits": self.cache_hits,
            "error_count": self.error_count,
            "handoff_count": self.handoff_count,
        }
