from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional

from ecom_stage1.rag.generator import RAGGenerator

from .openai_client import OpenAICompatibleClient, VLLMOpenAIClient


def load_yaml(path: str | Path) -> dict:
    import yaml
    return yaml.safe_load(Path(path).read_text(encoding='utf-8')) or {}


class PlainResponder:
    def __init__(
        self,
        backend: str = 'extractive',
        base_model: str = 'Qwen/Qwen2-7B-Instruct',
        model_path: Optional[str] = None,
        system_prompt: str = '你是一名电商客服助手。',
        backend_config: Optional[dict] = None,
    ):
        self.backend = backend
        self.base_model = base_model
        self.model_path = model_path
        self.system_prompt = system_prompt
        self.backend_config = backend_config or {}
        if backend in {'openai_compatible', 'vllm_openai'}:
            client_cls = VLLMOpenAIClient if backend == 'vllm_openai' else OpenAICompatibleClient
            self.client = client_cls(
                base_url=self.backend_config.get('base_url'),
                api_key=self.backend_config.get('api_key'),
                model=self.backend_config.get('model', model_path or base_model),
            )
            self.generator = None
        else:
            self.client = None
            local_backend = 'extractive' if backend == 'extractive' else backend
            self.generator = RAGGenerator(backend=local_backend, base_model=base_model, model_path=model_path)

    def answer(self, query: str, history: Optional[List[Dict[str, str]]] = None) -> str:
        history = history or []
        if self.client:
            history_text = '\n'.join(f"{h['role']}: {h['content']}" for h in history)
            user = f"历史上下文:\n{history_text}\n\n当前用户问题: {query}" if history_text else query
            return self.client.generate([
                {'role': 'system', 'content': self.system_prompt},
                {'role': 'user', 'content': user},
            ])
        context = '\n'.join(f"{h['role']}: {h['content']}" for h in history)
        return self.generator.generate(self.system_prompt, query, context)

    def stream_answer(self, query: str, history: Optional[List[Dict[str, str]]] = None):
        history = history or []
        if self.client:
            history_text = '\n'.join(f"{h['role']}: {h['content']}" for h in history)
            user = f"历史上下文:\n{history_text}\n\n当前用户问题: {query}" if history_text else query
            yield from self.client.stream_generate([
                {'role': 'system', 'content': self.system_prompt},
                {'role': 'user', 'content': user},
            ])
            return
        ans = self.answer(query, history)
        for token in ans:
            yield token
