from __future__ import annotations

import json
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import JSONResponse, StreamingResponse

from .orchestrator import Stage5ServingOrchestrator
from .schemas import ChatRequest

ROOT_DIR = Path(__file__).resolve().parents[3]
app = FastAPI(title='E-Commerce CS Stage5 Service', version='stage5-v1')
orch = Stage5ServingOrchestrator(ROOT_DIR)


@app.get('/health')
def health():
    return orch.health().model_dump()


@app.get('/metrics')
def metrics():
    return orch.metrics_snapshot()


@app.post('/chat')
def chat(req: ChatRequest):
    return JSONResponse(orch.handle(req).model_dump())


@app.post('/chat/stream')
def chat_stream(req: ChatRequest):
    def event_iter():
        for event in orch.stream(req):
            yield f"event: {event['event']}\ndata: {json.dumps(event['data'], ensure_ascii=False)}\n\n"
    return StreamingResponse(event_iter(), media_type='text/event-stream')
