from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, Field

Mode = Literal["plain", "rag", "agent"]

class ChatMessage(BaseModel):
    role: Literal["system", "user", "assistant"]
    content: str

class ChatRequest(BaseModel):
    request_id: Optional[str] = None
    mode: Mode = "agent"
    query: str
    history: List[ChatMessage] = Field(default_factory=list)
    stream: bool = False
    top_k: int = 5
    use_cache: bool = True
    metadata: Dict[str, Any] = Field(default_factory=dict)

class RetrievalCitation(BaseModel):
    index: int
    label: str
    source_type: Optional[str] = None
    source_path: Optional[str] = None
    category: Optional[str] = None
    sku: Optional[str] = None
    score: Optional[float] = None

class LatencyBreakdown(BaseModel):
    total_ms: float
    route_ms: float = 0.0
    rule_ms: float = 0.0
    tools_ms: float = 0.0
    rag_ms: float = 0.0
    generation_ms: float = 0.0
    cache_hit: bool = False

class ChatResponse(BaseModel):
    request_id: str
    mode: Mode
    answer: str
    route: Optional[str] = None
    action: Optional[str] = None
    citations: List[RetrievalCitation] = Field(default_factory=list)
    trace: List[str] = Field(default_factory=list)
    latency: LatencyBreakdown
    metadata: Dict[str, Any] = Field(default_factory=dict)

class ServiceHealth(BaseModel):
    status: Literal["ok", "degraded"]
    version: str
    plain_backend: str
    rag_backend: str
    cache_enabled: bool
    indexes_present: bool
    api_data_present: bool

class MetricsSnapshot(BaseModel):
    requests_total: int
    by_mode: Dict[str, int]
    avg_total_ms: float
    avg_first_chunk_ms: float
    cache_hits: int
    error_count: int
    handoff_count: int
