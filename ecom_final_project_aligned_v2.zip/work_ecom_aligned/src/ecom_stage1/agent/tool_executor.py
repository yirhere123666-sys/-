"""
tool_executor.py — 外部 API 工具执行器

【修复说明 Fix #5】
原版缺陷：execute() 串行执行所有 tool_calls，
          当 IntentRouter 同时触发订单查询 + 物流查询时，
          延迟 = T(订单) + T(物流)，高并发下成为瓶颈。

修复内容：
  1. 保留原有 execute() 串行接口（向后兼容）
  2. 新增 execute_parallel() 使用 ThreadPoolExecutor 并发执行
     （IO 密集型 API 调用，适合线程并发，不需要 asyncio）
  3. 并发超时保护：每个工具调用最多等 timeout_seconds

【面试必背】
为什么用 ThreadPoolExecutor 而不是 asyncio？
  API 调用是 IO 密集型（等待网络响应），不是 CPU 密集型。
  ThreadPoolExecutor 对同步函数更友好，无需改写 api_clients.py 的所有方法。
  若 API 客户端已经是 async 的，才使用 asyncio.gather()。

并发带来的延迟改进：
  串行：T_total = T_order + T_logistics ≈ 200ms + 200ms = 400ms
  并发：T_total = max(T_order, T_logistics) + overhead ≈ 200ms + 10ms = 210ms
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeout, as_completed
from pathlib import Path
from typing import Dict, Iterable, List

from .api_clients import LogisticsAPI, OrderAPI, PolicyAPI, ProductAPI
from .schemas import ToolCall, ToolResult

# 工具并发执行时单个工具的最大等待时间（秒）
_DEFAULT_TIMEOUT_SECONDS = 5.0


class ToolExecutor:
    """
    外部 API 工具执行器。

    提供两种执行模式：
      execute()          — 串行执行（简单稳定，延迟 = Σ各工具延迟）
      execute_parallel() — 并发执行（IO 密集型场景更快，延迟 ≈ max各工具延迟）
    """

    def __init__(self, data_dir: str | Path):
        data_dir = Path(data_dir)
        self.order_api    = OrderAPI(data_dir / 'orders.json')
        self.logistics_api = LogisticsAPI(data_dir / 'logistics.json')
        self.product_api  = ProductAPI(data_dir / 'products.json')
        self.policy_api   = PolicyAPI(data_dir / 'policies.json')

    # ── 串行执行（原有实现，向后兼容）────────────────────────────────────────
    def execute(self, tool_calls: Iterable[ToolCall]) -> List[ToolResult]:
        """串行执行 tool_calls，延迟 = Σ各工具延迟。"""
        results: List[ToolResult] = []
        for call in tool_calls:
            try:
                payload = self._dispatch(call.name, call.args)
                results.append(ToolResult(name=call.name, success=True, payload=payload))
            except Exception as e:
                results.append(ToolResult(name=call.name, success=False, error=str(e)))
        return results

    # ── 【新增】并发执行 ──────────────────────────────────────────────────────
    def execute_parallel(
        self,
        tool_calls: Iterable[ToolCall],
        timeout_seconds: float = _DEFAULT_TIMEOUT_SECONDS,
        max_workers: int = 4,
    ) -> List[ToolResult]:
        """
        并发执行 tool_calls，延迟 ≈ max(各工具延迟) + 调度开销。

        实现原理：
          1. 为每个 tool_call 提交一个线程任务
          2. as_completed() 收集结果（哪个先完成先处理）
          3. 超过 timeout_seconds 的任务标记为失败（避免卡死）
          4. 保持结果顺序与 tool_calls 输入顺序一致

        适用场景：
          IntentRouter 同时触发多个 API 调用时（如 get_order_status + get_logistics_status）
        """
        calls = list(tool_calls)
        if not calls:
            return []
        if len(calls) == 1:
            return self.execute(calls)   # 单个 tool 没必要开线程池

        results: Dict[str, ToolResult] = {}

        with ThreadPoolExecutor(max_workers=min(max_workers, len(calls))) as executor:
            future_to_call = {
                executor.submit(self._dispatch, call.name, call.args): call
                for call in calls
            }
            for future in as_completed(future_to_call, timeout=timeout_seconds * len(calls)):
                call = future_to_call[future]
                try:
                    payload = future.result(timeout=timeout_seconds)
                    results[call.name] = ToolResult(name=call.name, success=True, payload=payload)
                except FuturesTimeout:
                    results[call.name] = ToolResult(
                        name=call.name, success=False, error=f'工具调用超时（>{timeout_seconds}s）'
                    )
                except Exception as e:
                    results[call.name] = ToolResult(name=call.name, success=False, error=str(e))

        # 按输入顺序返回（保持确定性）
        return [results.get(call.name, ToolResult(name=call.name, success=False, error='未执行')) for call in calls]

    # ── 分发路由 ─────────────────────────────────────────────────────────────
    def _dispatch(self, name: str, args: Dict[str, str]):
        """将工具名映射到具体 API 方法。"""
        if name == 'get_order_status':
            return self.order_api.get_order_status(args['order_id'])
        if name == 'get_logistics_status':
            return self.logistics_api.get_logistics_status(args['tracking_id'])
        if name == 'get_logistics_by_order':
            return self.logistics_api.get_logistics_by_order(args['order_id'])
        if name == 'get_product_info':
            return self.product_api.get_product_info(args['sku'])
        if name == 'get_policy':
            return self.policy_api.get_policy(args['policy_key'])
        if name == 'get_account_policy':
            return self.policy_api.get_policy('account_help')
        raise ValueError(f'未知工具: {name}')
