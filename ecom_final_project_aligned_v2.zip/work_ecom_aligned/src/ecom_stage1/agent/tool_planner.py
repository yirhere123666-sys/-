from __future__ import annotations

from typing import Dict, List

from .schemas import ToolCall, ToolCallPlan


def build_tool_plan(route_name: str, entities: Dict[str, object]) -> ToolCallPlan:
    calls: List[ToolCall] = []
    reason = ''
    if route_name == 'order_or_logistics_query':
        order_ids = list(entities.get('order_ids') or [])
        tracking_ids = list(entities.get('tracking_ids') or [])
        if order_ids:
            calls.append(ToolCall(name='get_order_status', args={'order_id': order_ids[0]}))
            calls.append(ToolCall(name='get_logistics_by_order', args={'order_id': order_ids[0]}))
            reason = '订单/物流动态问题优先走订单→物流级联查询'
        elif tracking_ids:
            calls.append(ToolCall(name='get_logistics_status', args={'tracking_id': tracking_ids[0]}))
            reason = '已抽取物流单号，直接查询物流'
    elif route_name == 'cancel_order':
        order_ids = list(entities.get('order_ids') or [])
        if order_ids:
            calls.append(ToolCall(name='get_order_status', args={'order_id': order_ids[0]}))
            reason = '取消订单需先核验订单状态'
    elif route_name == 'refund_or_aftersale':
        order_ids = list(entities.get('order_ids') or [])
        if order_ids:
            calls.append(ToolCall(name='get_order_status', args={'order_id': order_ids[0]}))
            reason = '退款/售后需先核验订单状态后再结合规则说明'
    elif route_name == 'product_info':
        sku_ids = list(entities.get('sku_ids') or [])
        if sku_ids:
            calls.append(ToolCall(name='get_product_info', args={'sku': sku_ids[0]}))
            reason = '商品咨询抽取到 SKU，先查商品中心再回答'
    elif route_name == 'invoice_policy':
        calls.append(ToolCall(name='get_policy', args={'policy_key': 'invoice_policy'}))
        reason = '发票问题优先查发票规则'
    elif route_name == 'account_help':
        calls.append(ToolCall(name='get_account_policy', args={}))
        reason = '账号类问题需优先强调身份验证规则'
    return ToolCallPlan(route_name=route_name, calls=calls, reason=reason)
