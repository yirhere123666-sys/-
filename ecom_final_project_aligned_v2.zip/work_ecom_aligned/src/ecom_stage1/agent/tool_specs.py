from __future__ import annotations

from typing import Dict

from .schemas import ToolSpec


TOOL_SPECS: Dict[str, ToolSpec] = {
    'get_order_status': ToolSpec('get_order_status', '根据订单号查询订单状态、支付状态、发票状态。', ['order_id']),
    'get_logistics_status': ToolSpec('get_logistics_status', '根据物流单号查询物流状态与节点。', ['tracking_id']),
    'get_logistics_by_order': ToolSpec('get_logistics_by_order', '根据订单号联动查询物流状态。', ['order_id']),
    'get_product_info': ToolSpec('get_product_info', '根据 SKU 查询商品参数、库存和兼容信息。', ['sku']),
    'get_policy': ToolSpec('get_policy', '查询售后/发票/取消等业务规则。', ['policy_key']),
    'get_account_policy': ToolSpec('get_account_policy', '查询账号安全与身份验证规则。', []),
}
