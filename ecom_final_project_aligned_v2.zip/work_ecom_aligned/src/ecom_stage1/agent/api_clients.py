
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from ecom_stage1.io_utils import load_records


class _JSONStore:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.rows = load_records(self.path) if self.path.exists() else []

    def _find_first(self, key: str, value: Any) -> Optional[Dict[str, Any]]:
        for row in self.rows:
            if str(row.get(key)) == str(value):
                return row
        return None

    def _find_all(self, key: str, value: Any) -> List[Dict[str, Any]]:
        return [row for row in self.rows if str(row.get(key)) == str(value)]


class OrderAPI(_JSONStore):
    def get_order_status(self, order_id: str) -> Dict[str, Any]:
        row = self._find_first('order_id', order_id)
        if not row:
            return {'found': False, 'order_id': order_id}
        return {'found': True, **row}


class LogisticsAPI(_JSONStore):
    def get_logistics_status(self, tracking_id: str) -> Dict[str, Any]:
        row = self._find_first('tracking_id', tracking_id)
        if not row:
            return {'found': False, 'tracking_id': tracking_id}
        return {'found': True, **row}

    def get_logistics_by_order(self, order_id: str) -> Dict[str, Any]:
        row = self._find_first('order_id', order_id)
        if not row:
            return {'found': False, 'order_id': order_id}
        return {'found': True, **row}


class ProductAPI(_JSONStore):
    def get_product_info(self, sku: str) -> Dict[str, Any]:
        row = self._find_first('sku', sku)
        if not row:
            return {'found': False, 'sku': sku}
        return {'found': True, **row}


class PolicyAPI(_JSONStore):
    def get_policy(self, key: str) -> Dict[str, Any]:
        row = self._find_first('policy_key', key)
        if not row:
            return {'found': False, 'policy_key': key}
        return {'found': True, **row}

    def search_policies(self, keywords: List[str]) -> Dict[str, Any]:
        matched = []
        for row in self.rows:
            content = str(row.get('content', ''))
            if any(k and k in content for k in keywords):
                matched.append(row)
        return {'found': bool(matched), 'matches': matched[:5]}
