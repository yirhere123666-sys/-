from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional

import yaml

from .entity_extractor import EntityExtractor
from .schemas import RouteDecision
from .tool_planner import build_tool_plan

AMBIGUOUS_THRESHOLD = 0.72

DEFAULT_CONFIG = {
    'default_confidence_threshold': 0.6,
    'handoff_keywords': ['投诉', '人工', '差评', '怒'],
    'api_first_intents': ['order_or_logistics_query', 'cancel_order'],
    'mixed_intents': ['refund_or_aftersale', 'account_help', 'invoice_policy', 'product_info'],
    'rag_intents': ['policy_default'],
}


class IntentRouter:
    def __init__(self, config_path: str | Path | None = None):
        self.extractor = EntityExtractor()
        self.config = self._load_config(config_path)

    def _load_config(self, config_path: str | Path | None) -> Dict:
        if not config_path:
            return DEFAULT_CONFIG.copy()
        path = Path(config_path)
        if not path.exists():
            return DEFAULT_CONFIG.copy()
        data = yaml.safe_load(path.read_text(encoding='utf-8')) or {}
        cfg = DEFAULT_CONFIG.copy()
        cfg.update(data)
        return cfg

    def route(self, query: str, history: Optional[List[Dict[str, str]]] = None) -> RouteDecision:
        entities = self.extractor.extract(query or '')
        decision = self._match_rules(query or '', entities)
        meta = dict(decision.metadata or {})
        if decision.confidence < AMBIGUOUS_THRESHOLD:
            meta['ambiguous'] = True
        if decision.tool_plan and decision.tool_plan.reason:
            meta['tool_plan_reason'] = decision.tool_plan.reason
        decision.metadata = meta
        return decision

    def _decision(self, route_name: str, route_type: str, confidence: float, reasons: List[str], entities: Dict[str, object], rag_filters: Optional[Dict[str, object]] = None) -> RouteDecision:
        tool_plan = build_tool_plan(route_name, entities)
        return RouteDecision(
            route_name=route_name,
            route_type=route_type,
            confidence=confidence,
            reasons=reasons,
            extracted_entities=entities,
            tool_calls=tool_plan.calls,
            rag_filters=rag_filters or {},
            metadata={},
            tool_plan=tool_plan,
        )

    def _match_rules(self, query: str, entities: Dict[str, object]) -> RouteDecision:
        if entities.get('is_angry') or entities.get('wants_human'):
            return self._decision('complaint_handoff', 'handoff', 0.96, ['检测到投诉/强人工诉求'], entities)
        if entities.get('has_cancel_keyword'):
            return self._decision('cancel_order', 'mixed', 0.91, ['命中取消订单意图'], entities, {'category': '取消订单'})
        if entities.get('has_invoice_keyword'):
            return self._decision('invoice_policy', 'mixed', 0.88, ['命中发票/开票关键词'], entities, {'category': '发票'})
        if entities.get('has_refund_keyword'):
            return self._decision('refund_or_aftersale', 'mixed', 0.89, ['命中退款/售后意图'], entities, {'category': '退换货'})
        if entities.get('has_account_keyword'):
            return self._decision('account_help', 'mixed', 0.84, ['命中账号/登录关键词'], entities, {'category': '账号帮助'})
        if entities.get('has_product_keyword') or entities.get('sku_ids'):
            filters = {'category': '商品咨询'}
            sku_ids = list(entities.get('sku_ids') or [])
            if sku_ids:
                filters['sku'] = sku_ids[0]
            return self._decision('product_info', 'mixed' if sku_ids else 'rag', 0.86 if sku_ids else 0.82, ['命中商品咨询关键词'], entities, filters)
        if entities.get('has_logistics_keyword') or entities.get('order_ids') or entities.get('tracking_ids'):
            return self._decision('order_or_logistics_query', 'api', 0.92, ['命中订单/物流动态状态意图'], entities)
        return self._decision('policy_default', 'rag', 0.60, ['无明确动态意图，默认走政策知识检索'], entities)
