
from __future__ import annotations

from pathlib import Path
from typing import Dict, List

import yaml

from .schemas import RouteDecision, RuleDecision, ToolCall, ToolResult


class RulesEngine:
    def __init__(self, config_path: str | Path | None = None):
        self.config = self._load_config(config_path)

    def _load_config(self, config_path: str | Path | None) -> Dict:
        default = {
            'high_risk_keywords': ['全额退款', '马上退款', '直接赔偿', '无需审核'],
            'clarify_messages': {
                'need_order_id': '您好，麻烦您提供订单号后，我再帮您进一步核验。',
                'need_tracking_id': '您好，麻烦您提供物流单号后，我再帮您查询最新物流状态。',
                'need_sku': '您好，麻烦您提供商品 SKU 或商品链接，我再帮您核对参数。',
            },
            'handoff_message': '您好，这边已为您转接人工客服进一步处理。',
            'deny_cancel_message': '您好，当前订单已进入发货流程，无法直接取消。若商品送达后仍需处理，可按退换货规则申请售后。',
        }
        if not config_path:
            return default
        path = Path(config_path)
        if not path.exists():
            return default
        data = yaml.safe_load(path.read_text(encoding='utf-8')) or {}
        merged = {**default, **data}
        merged['clarify_messages'] = {**default['clarify_messages'], **(data.get('clarify_messages') or {})}
        return merged

    def apply(self, query: str, route: RouteDecision, tool_results: List[ToolResult]) -> RuleDecision:
        by_name = {t.name: t for t in tool_results}
        entities = route.extracted_entities or {}
        reasons: List[str] = []

        if route.route_type == 'handoff':
            return RuleDecision(action='handoff', compliant=True, reasons=route.reasons, response_override=self.config['handoff_message'])

        # 动态状态：没有订单号 / 物流单号时不允许模型猜
        if route.route_name == 'order_or_logistics_query':
            if not entities.get('order_ids') and not entities.get('tracking_ids'):
                return RuleDecision(action='clarify', compliant=True, reasons=['动态状态查询缺少订单号或物流单号'], response_override=self.config['clarify_messages']['need_order_id'])
            if any(t.success and t.payload.get('found') for t in tool_results):
                return RuleDecision(action='api_only', compliant=True, reasons=['动态状态已由 API 确认'])
            return RuleDecision(action='clarify', compliant=True, reasons=['API 未找到对应订单/物流信息'], response_override='您好，这边暂未查到对应订单或物流信息，麻烦您核对订单号/物流单号后再试一次。')

        if route.route_name == 'cancel_order':
            order = by_name.get('get_order_status')
            if not order or not order.success:
                return RuleDecision(action='clarify', compliant=True, reasons=['取消订单需要先核验订单信息'], response_override=self.config['clarify_messages']['need_order_id'])
            status = order.payload.get('status', '')
            if status in {'shipped', 'in_transit', 'delivered'}:
                return RuleDecision(action='deny', compliant=True, reasons=[f'订单状态为{status}，不能直接取消'], response_override=self.config['deny_cancel_message'])
            return RuleDecision(action='api_only', compliant=True, reasons=['订单尚未发货，可继续处理取消'])

        if route.route_name == 'refund_or_aftersale':
            if any(k in query for k in self.config['high_risk_keywords']) or entities.get('has_absolute_claim_keyword'):
                reasons.append('检测到高风险赔付/绝对承诺信号')
            if entities.get('order_ids') and by_name.get('get_order_status', ToolResult('', False)).success:
                return RuleDecision(action='tool_then_rag', compliant=True, reasons=reasons or ['已核验订单，可结合规则回复'])
            # 有 policy 但无订单时，也允许先解释规则，但禁止给结论
            return RuleDecision(action='rag_with_guardrails', compliant=True, reasons=reasons or ['售后规则可先解释，具体结论需结合订单核验'])

        if route.route_name == 'invoice_policy':
            return RuleDecision(action='tool_then_rag' if by_name.get('get_policy') else 'rag_with_guardrails', compliant=True, reasons=['发票问题优先参考规则与知识库'])

        if route.route_name == 'product_info':
            if entities.get('has_absolute_claim_keyword'):
                reasons.append('商品咨询中出现绝对化承诺风险')
            if entities.get('sku_ids') and by_name.get('get_product_info', ToolResult('', False)).success:
                return RuleDecision(action='tool_then_rag', compliant=True, reasons=reasons or ['已获取商品动态信息，可结合知识回复'])
            if entities.get('has_product_keyword') and not entities.get('sku_ids'):
                return RuleDecision(action='rag_with_guardrails', compliant=True, reasons=reasons or ['无 SKU 时先走知识库，避免硬猜具体型号'])
            return RuleDecision(action='rag_with_guardrails', compliant=True, reasons=reasons or ['商品咨询默认走知识库并禁止绝对承诺'])

        if route.route_name == 'account_help':
            return RuleDecision(action='tool_then_rag', compliant=True, reasons=['账号问题需强调身份验证，不得越权重置'])

        if route.route_type == 'rag':
            return RuleDecision(action='allow', compliant=True, reasons=['静态知识问题可直接走 RAG'])

        if route.route_type == 'mixed':
            return RuleDecision(action='tool_then_rag', compliant=True, reasons=['先用工具拿动态状态，再用规则/RAG组织答复'])

        return RuleDecision(action='allow', compliant=True, reasons=['默认允许'])
