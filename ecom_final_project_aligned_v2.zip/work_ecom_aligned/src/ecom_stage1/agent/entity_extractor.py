from __future__ import annotations

import re
from typing import Any, Dict, List


class EntityExtractor:
    ORDER_ID_PATTERNS = [
        r'订单(?:号|編號|编号)?[:：]?\s*([A-Za-z0-9_-]{6,24})',
        r'(\d{8,18})',
        r'([A-Z]\d{4,12})',
    ]
    TRACKING_PATTERNS = [
        r'(SF\d{9,15}CN)',
        r'(YT\d{10,16})',
        r'(ZTO\d{8,18})',
        r'物流(?:单号)?[:：]?\s*([A-Za-z0-9_-]{8,24})',
    ]
    SKU_PATTERNS = [
        r'(SKU[-_ ]?[A-Za-z0-9]{3,20})',
        r'([A-Z]{1,4}\d{2,5}[A-Z0-9]{0,8})',
    ]

    def extract(self, text: str) -> Dict[str, Any]:
        text = (text or '').strip()
        order_ids = self._find_patterns(text, self.ORDER_ID_PATTERNS)
        tracking_ids = self._find_patterns(text, self.TRACKING_PATTERNS)
        sku_ids = self._find_patterns(text, self.SKU_PATTERNS)
        refund_keywords = ['退款', '退货', '退掉', '退钱', '赔付', '赔偿', '售后', '换货', '补发']
        logistics_keywords = ['物流', '发货', '送达', '派送', '快递', '到哪', '到哪里', '查发货', '查物流', '订单状态', '签收', '发货了吗']
        cancel_keywords = ['取消订单', '取消购买', '取消', '拦截发货', '不想要了']
        invoice_keywords = ['发票', '开票', '补开', '开出来']
        product_keywords = ['参数', '型号', '支持', '兼容', 'NFC', '尺码', '颜色', '容量', '规格', '门禁']
        account_keywords = ['账号', '账户', '密码', '登录', '锁定', '找回', '验证码']
        complaint_keywords = ['投诉', '差评', '生气', '怒', '再不处理', '人工', '经理', '举报', '扯皮']
        absolute_claim_keywords = ['一定', '保证', '立刻', '马上', '所有', '全部', '绝对', '肯定', '都没问题']
        entities = {
            'order_ids': self._uniq(order_ids),
            'tracking_ids': self._uniq(tracking_ids),
            'sku_ids': self._uniq(sku_ids),
            'has_refund_keyword': any(k in text for k in refund_keywords),
            'has_logistics_keyword': any(k in text for k in logistics_keywords),
            'has_cancel_keyword': any(k in text for k in cancel_keywords),
            'has_invoice_keyword': any(k in text for k in invoice_keywords),
            'has_product_keyword': any(k in text for k in product_keywords) or bool(sku_ids),
            'has_account_keyword': any(k in text for k in account_keywords),
            'is_angry': any(k in text for k in complaint_keywords),
            'has_absolute_claim_keyword': any(k in text for k in absolute_claim_keywords),
            'wants_human': any(k in text for k in ['人工', '人工客服', '转人工', '客服出来', '找人处理']),
        }
        return entities

    def _find_patterns(self, text: str, patterns: List[str]) -> List[str]:
        found: List[str] = []
        for p in patterns:
            for m in re.finditer(p, text, re.IGNORECASE):
                g = m.group(1) if m.groups() else m.group(0)
                if g:
                    found.append(g.strip())
        return found

    def _uniq(self, values: List[str]) -> List[str]:
        seen = set()
        out = []
        for v in values:
            if v not in seen:
                seen.add(v)
                out.append(v)
        return out
