from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class ToolSpec:
    name: str
    description: str
    required_args: List[str] = field(default_factory=list)
    optional_args: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ToolCall:
    name: str
    args: Dict[str, Any] = field(default_factory=dict)
    source: str = 'rule_router'

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ToolCallPlan:
    route_name: str
    calls: List[ToolCall] = field(default_factory=list)
    planner: str = 'rule_router'
    reason: str = ''

    def to_dict(self) -> Dict[str, Any]:
        return {
            'route_name': self.route_name,
            'planner': self.planner,
            'reason': self.reason,
            'calls': [c.to_dict() for c in self.calls],
        }


@dataclass
class ToolResult:
    name: str
    success: bool
    payload: Dict[str, Any] = field(default_factory=dict)
    error: str = ''

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class RouteDecision:
    route_name: str
    route_type: str  # rag / api / mixed / handoff / clarify
    confidence: float
    reasons: List[str] = field(default_factory=list)
    extracted_entities: Dict[str, Any] = field(default_factory=dict)
    tool_calls: List[ToolCall] = field(default_factory=list)
    rag_filters: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    tool_plan: Optional[ToolCallPlan] = None

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d['tool_calls'] = [t.to_dict() for t in self.tool_calls]
        d['tool_plan'] = self.tool_plan.to_dict() if self.tool_plan else None
        return d


@dataclass
class RuleDecision:
    action: str  # allow / deny / handoff / clarify / tool_then_rag / rag_with_guardrails / api_only
    compliant: bool = True
    reasons: List[str] = field(default_factory=list)
    response_override: Optional[str] = None
    updated_tool_calls: List[ToolCall] = field(default_factory=list)
    updated_rag_filters: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d['updated_tool_calls'] = [t.to_dict() for t in self.updated_tool_calls]
        return d


@dataclass
class Stage4Response:
    id: str
    query: str
    answer: str
    route: RouteDecision
    rule_decision: RuleDecision
    tool_results: List[ToolResult] = field(default_factory=list)
    rag_answer: Optional[str] = None
    rag_context: Optional[str] = None
    citations: List[Dict[str, Any]] = field(default_factory=list)
    decision_trace: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'query': self.query,
            'answer': self.answer,
            'route': self.route.to_dict(),
            'rule_decision': self.rule_decision.to_dict(),
            'tool_results': [t.to_dict() for t in self.tool_results],
            'rag_answer': self.rag_answer,
            'rag_context': self.rag_context,
            'citations': self.citations,
            'decision_trace': self.decision_trace,
            'metadata': self.metadata,
        }
