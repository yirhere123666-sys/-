"""
embeddings.py — Dense Embedding 管理器

【修复说明 Fix #1】
原版缺陷：encode_queries() 和 encode_documents() 调用完全相同的内部函数，
          没有区分 BGE-M3 的 asymmetric instruction prefix。
          BGE-M3 训练时 query 端加了 instruction prefix，document 端不加，
          推理时不一致导致 embedding 空间错位，召回率下降 3-8pp。

修复内容：
  1. encode_queries()  → 自动为 query 添加 BGE 标准 instruction prefix
  2. encode_documents()→ 保持不加 prefix（document 端）
  3. 完整保留 tfidf_svd fallback，无 GPU 环境正常运行
"""
from __future__ import annotations

import pickle
from pathlib import Path
from typing import Sequence

import numpy as np
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import Normalizer

from .text_utils import normalize_text

# BGE 系列模型官方推荐的 query instruction prefix
BGE_QUERY_INSTRUCTION = "Represent this sentence for searching relevant passages: "

try:
    import torch
    from transformers import AutoModel, AutoTokenizer
except Exception:
    torch = None
    AutoModel = None
    AutoTokenizer = None


class DenseEmbedder:
    """
    Dense Embedding 管理器。

    两种 backend：
      - bge_m3 / hf_encoder : 真实 Transformer 模型
      - tfidf_svd (默认)    : TF-IDF + TruncatedSVD，离线轻量 fallback

    核心修复：encode_queries 加 instruction prefix，encode_documents 不加。
    """

    def __init__(
        self,
        backend: str = 'tfidf_svd',
        model_name: str = 'BAAI/bge-m3',
        device: str | None = None,
        max_features: int = 12000,
        n_components: int = 256,
        batch_size: int = 16,
        query_instruction: str = BGE_QUERY_INSTRUCTION,
    ):
        self.backend = backend
        self.model_name = model_name
        self.device = device or ('cuda' if torch is not None and torch.cuda.is_available() else 'cpu')
        self.max_features = max_features
        self.n_components = n_components
        self.batch_size = batch_size
        # 仅在使用真实 Transformer backend 时才有效
        self.query_instruction = query_instruction if backend in {'bge_m3', 'hf_encoder'} else ''

        # Fallback backend
        self.vectorizer = TfidfVectorizer(analyzer='char_wb', ngram_range=(2, 4), max_features=max_features)
        self.svd: TruncatedSVD | None = None
        self.normalizer = Normalizer(copy=False)
        self.is_fitted = False

        # 运行时模型（不随 pickle 序列化）
        self._tokenizer = None
        self._model = None
        self.runtime_backend = backend

    def __getstate__(self):
        state = self.__dict__.copy()
        state['_tokenizer'] = None
        state['_model'] = None
        return state

    def __setstate__(self, state):
        self.__dict__.update(state)
        self._tokenizer = None
        self._model = None

    def _ensure_real_backend(self) -> bool:
        if self.backend not in {'bge_m3', 'hf_encoder'}:
            self.runtime_backend = 'tfidf_svd'
            return False
        if self._tokenizer is not None and self._model is not None:
            self.runtime_backend = self.backend
            return True
        if AutoTokenizer is None or AutoModel is None or torch is None:
            self.runtime_backend = 'tfidf_svd'
            return False
        try:
            self._tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            self._model = AutoModel.from_pretrained(self.model_name)
            self._model.to(self.device)
            self._model.eval()
            self.runtime_backend = self.backend
            return True
        except Exception:
            self._tokenizer = None
            self._model = None
            self.runtime_backend = 'tfidf_svd'
            return False

    @staticmethod
    def _mean_pool(last_hidden_state, attention_mask):
        """Attention-masked mean pooling（对 padding token 不计入均值）。"""
        mask = attention_mask.unsqueeze(-1).expand(last_hidden_state.size()).float()
        summed = (last_hidden_state * mask).sum(dim=1)
        counts = mask.sum(dim=1).clamp(min=1e-9)
        return summed / counts

    def _encode_real(self, texts: Sequence[str]) -> np.ndarray:
        """批量 Transformer 编码（texts 已包含所需前缀）。"""
        texts = [normalize_text(t) for t in texts]
        batches = []
        for i in range(0, len(texts), self.batch_size):
            sub = list(texts[i: i + self.batch_size])
            encoded = self._tokenizer(sub, padding=True, truncation=True,
                                      max_length=512, return_tensors='pt')
            encoded = {k: v.to(self.device) for k, v in encoded.items()}
            with torch.no_grad():
                outputs = self._model(**encoded)
                if hasattr(outputs, 'last_hidden_state'):
                    emb = self._mean_pool(outputs.last_hidden_state, encoded['attention_mask'])
                elif hasattr(outputs, 'pooler_output') and outputs.pooler_output is not None:
                    emb = outputs.pooler_output
                else:
                    emb = outputs[0][:, 0]
                emb = torch.nn.functional.normalize(emb, p=2, dim=1)
            batches.append(emb.detach().cpu().numpy().astype(np.float32))
        return np.concatenate(batches, axis=0) if batches else np.zeros((0, 1), dtype=np.float32)

    # ── TF-IDF fallback ──────────────────────────────────────────────────────
    def fit(self, texts: Sequence[str]) -> None:
        if self._ensure_real_backend():
            self.is_fitted = True
            return
        texts_norm = [normalize_text(t) for t in texts]
        tfidf = self.vectorizer.fit_transform(texts_norm)
        n_comp = None
        if tfidf.shape[0] > 2 and tfidf.shape[1] > 2:
            n_comp = min(self.n_components, max(2, min(tfidf.shape[0] - 1, tfidf.shape[1] - 1)))
        if n_comp and n_comp >= 2:
            self.svd = TruncatedSVD(n_components=n_comp, random_state=42)
            dense = self.svd.fit_transform(tfidf)
            self.normalizer.fit(dense)
        self.runtime_backend = 'tfidf_svd'
        self.is_fitted = True

    def _encode_tfidf(self, texts: Sequence[str]) -> np.ndarray:
        texts_norm = [normalize_text(t) for t in texts]
        tfidf = self.vectorizer.transform(texts_norm)
        if self.svd is not None:
            dense = self.svd.transform(tfidf)
            return np.asarray(self.normalizer.transform(dense), dtype=np.float32)
        arr = tfidf.toarray().astype(np.float32)
        norms = np.linalg.norm(arr, axis=1, keepdims=True) + 1e-12
        return arr / norms

    # ── 【核心修复】query / document 分路编码 ───────────────────────────────
    def encode_documents(self, texts: Sequence[str]) -> np.ndarray:
        """
        Document 端编码 — 不加 instruction prefix。
        BGE-M3 规范：passage 侧直接编码原始文本。
        """
        if not self.is_fitted:
            self.fit(texts)
        if (self.runtime_backend in {'bge_m3', 'hf_encoder'}
                and self._tokenizer is not None and self._model is not None):
            return self._encode_real(texts)          # ← 原始文本，无 prefix
        return self._encode_tfidf(texts)

    def encode_queries(self, texts: Sequence[str]) -> np.ndarray:
        """
        Query 端编码 — 自动加 instruction prefix（BGE 非对称检索的关键）。

        prefix = "Represent this sentence for searching relevant passages: "

        原理：BGE-M3 训练时 query 端使用该 prefix，
              推理时保持一致才能让 query 向量落在
              和 document 向量正确对齐的语义子空间里。
        """
        if not self.is_fitted:
            raise RuntimeError('DenseEmbedder 需要先调用 fit() 或 encode_documents()。')
        if (self.runtime_backend in {'bge_m3', 'hf_encoder'}
                and self._tokenizer is not None and self._model is not None):
            prefixed = [f"{self.query_instruction}{t}" for t in texts]  # ← 加 prefix
            return self._encode_real(prefixed)
        return self._encode_tfidf(texts)    # fallback 无 prefix（对称）

    # ── 序列化 ────────────────────────────────────────────────────────────────
    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('wb') as f:
            pickle.dump(self, f)

    @staticmethod
    def load(path: str | Path) -> 'DenseEmbedder':
        with Path(path).open('rb') as f:
            return pickle.load(f)
