"""
hybrid_retriever.py — BM25 + Dense 双路混合检索

【修复说明 Fix #2】
原版缺陷：只支持 min-max score 加权融合，BM25 分数（0~20）和向量余弦（0~1）
          量纲不同，归一化后分布形状仍然不可比，
          且超参数 dense_weight/sparse_weight 在不同知识库上需重新调。

修复内容：
  1. 新增 fusion_strategy 参数，支持 'weighted'（原有）和 'rrf'（RRF）
  2. RRF（Reciprocal Rank Fusion）只依赖排名，对 score 量纲完全免疫
  3. 默认 rrf_k=60（Cormack 2009 论文经验值）
  4. 保持向后兼容，默认值仍为 'weighted'

【面试必背】
RRF score(d) = Σ_{r ∈ rankings} 1 / (k + rank_r(d))
  k=60：防止排名第 1 的文档分数过于支配（缓冲项）
  只依赖排名，不依赖分数绝对值 → 对异质检索鲁棒
"""
from __future__ import annotations

from typing import Dict, List, Optional

from .dense_retriever import DenseRetriever
from .reranker import BaseReranker
from .schemas import RetrievedChunk
from .sparse_retriever import BM25Retriever


class HybridRetriever:
    """
    双路混合检索器（BM25 稀疏 + Dense 向量）。

    fusion_strategy:
      - 'weighted' : min-max 归一化后加权求和（原有方案，需要调权重）
      - 'rrf'      : Reciprocal Rank Fusion（推荐，对量纲免疫）
    """

    def __init__(
        self,
        sparse: BM25Retriever,
        dense: DenseRetriever,
        dense_weight: float = 0.6,
        sparse_weight: float = 0.4,
        reranker: Optional[BaseReranker] = None,
        fusion_strategy: str = 'weighted',   # 新增：'weighted' | 'rrf'
        rrf_k: int = 60,                     # 新增：RRF 缓冲参数
    ):
        self.sparse = sparse
        self.dense = dense
        self.dense_weight = dense_weight
        self.sparse_weight = sparse_weight
        self.reranker = reranker
        self.fusion_strategy = fusion_strategy
        self.rrf_k = rrf_k

    # ── 主检索接口 ────────────────────────────────────────────────────────────
    def search(
        self,
        query: str,
        top_k: int = 5,
        retrieve_k: int = 12,
        filters: Optional[Dict[str, str]] = None,
        use_reranker: bool = True,
    ) -> List[RetrievedChunk]:
        """
        执行混合检索，流程：
          1. 两路各召回 retrieve_k 条
          2. 按 fusion_strategy 融合分数
          3. 可选：Cross-Encoder 重排
          4. 返回 top_k 条
        """
        sparse_hits = self.sparse.search(query, top_k=retrieve_k, filters=filters)
        dense_hits  = self.dense.search(query,  top_k=retrieve_k, filters=filters)

        if self.fusion_strategy == 'rrf':
            ranked = self._rrf_merge(sparse_hits, dense_hits)
        else:
            ranked = self._weighted_merge(sparse_hits, dense_hits)

        if use_reranker and self.reranker is not None and ranked:
            ranked = self.reranker.rerank(query, ranked, top_k=min(retrieve_k, len(ranked)))

        return ranked[:top_k]

    # ── 【新增】RRF 融合 ───────────────────────────────────────────────────────
    def _rrf_merge(
        self,
        sparse_hits: List[RetrievedChunk],
        dense_hits: List[RetrievedChunk],
    ) -> List[RetrievedChunk]:
        """
        Reciprocal Rank Fusion：

            RRF_score(d) = Σ  1 / (k + rank_i(d))

        其中 rank_i(d) 是文档 d 在第 i 路检索结果中的排名（从 1 开始）。

        优势：
          - 不依赖 BM25/向量分数的绝对值，对量纲完全免疫
          - 无需调 dense_weight/sparse_weight 超参数
          - 在 BEIR benchmark 上普遍优于 score 加权

        参数 k=60 来自 Cormack et al. 2009，是防止排名第 1 的文档
        分数过度主导（1/(60+1) ≈ 0.016）的缓冲项。
        """
        rrf_scores: Dict[str, float] = {}
        chunk_map:  Dict[str, RetrievedChunk] = {}

        # 稀疏路：排名 1, 2, 3, ...
        for rank, hit in enumerate(sparse_hits, start=1):
            rrf_scores[hit.chunk_id] = rrf_scores.get(hit.chunk_id, 0.0) + 1.0 / (self.rrf_k + rank)
            chunk_map[hit.chunk_id] = hit

        # 向量路：排名 1, 2, 3, ...
        for rank, hit in enumerate(dense_hits, start=1):
            rrf_scores[hit.chunk_id] = rrf_scores.get(hit.chunk_id, 0.0) + 1.0 / (self.rrf_k + rank)
            if hit.chunk_id not in chunk_map:
                chunk_map[hit.chunk_id] = hit

        # 用 RRF 分数覆盖原始 score 字段，便于后续重排器使用
        result = []
        for cid, rrf_s in rrf_scores.items():
            chunk = chunk_map[cid]
            chunk.score = rrf_s
            result.append(chunk)

        result.sort(key=lambda x: x.score, reverse=True)
        return result

    # ── 原有 weighted 融合 ────────────────────────────────────────────────────
    def _weighted_merge(
        self,
        sparse_hits: List[RetrievedChunk],
        dense_hits: List[RetrievedChunk],
    ) -> List[RetrievedChunk]:
        """
        Min-max 归一化后加权求和。

        适用场景：知识库语义密度高、BM25 得分分布集中时。
        局限：需要手动调 dense_weight / sparse_weight 超参数。
        """
        sparse_norm = self._normalize([x.sparse_score for x in sparse_hits])
        dense_norm  = self._normalize([x.dense_score  for x in dense_hits])

        merged: Dict[str, RetrievedChunk] = {}

        for hit, score in zip(sparse_hits, sparse_norm):
            merged[hit.chunk_id] = RetrievedChunk(
                **{**hit.to_dict(), 'score': self.sparse_weight * score,
                   'sparse_score': hit.sparse_score}
            )
        for hit, score in zip(dense_hits, dense_norm):
            if hit.chunk_id not in merged:
                merged[hit.chunk_id] = RetrievedChunk(
                    **{**hit.to_dict(), 'score': self.dense_weight * score,
                       'dense_score': hit.dense_score}
                )
            else:
                existing = merged[hit.chunk_id]
                existing.score += self.dense_weight * score
                existing.dense_score = hit.dense_score

        ranked = sorted(merged.values(), key=lambda x: x.score, reverse=True)
        return ranked

    @staticmethod
    def _normalize(scores: List[float]) -> List[float]:
        """Min-max 归一化到 [0, 1]。"""
        if not scores:
            return []
        lo, hi = min(scores), max(scores)
        if abs(hi - lo) < 1e-12:
            return [1.0] * len(scores)
        return [(s - lo) / (hi - lo) for s in scores]
