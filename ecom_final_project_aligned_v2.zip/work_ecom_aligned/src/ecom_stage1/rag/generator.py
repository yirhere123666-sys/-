from __future__ import annotations

from typing import Optional

from ecom_stage1.rag.text_utils import normalize_text


class RAGGenerator:
    def __init__(self, backend: str = 'extractive', base_model: str = 'Qwen/Qwen2-7B-Instruct', model_path: Optional[str] = None, max_new_tokens: int = 256):
        self.backend = backend
        self.model_path = model_path
        self.base_model = base_model
        self.max_new_tokens = max_new_tokens
        self._gen = None
        self._client = None
        if backend == 'hf':
            from ecom_stage1.inference import HFGenerator
            self._gen = HFGenerator(base_model, adapter_path=model_path, max_new_tokens=max_new_tokens)
        elif backend == 'vllm':
            from ecom_stage1.inference import VLLMGenerator
            self._gen = VLLMGenerator(model_path or base_model, max_new_tokens=max_new_tokens)
        elif backend in {'openai_compatible', 'vllm_openai'}:
            from ecom_stage1.service.openai_client import OpenAICompatibleClient
            self._client = OpenAICompatibleClient(model=model_path or base_model)

    def generate(self, system_prompt: str, query: str, context: str) -> str:
        if self.backend == 'extractive':
            return self._extractive_answer(query, context)
        if self.backend in {'openai_compatible', 'vllm_openai'}:
            user_prompt = f"检索上下文:\n{context}\n\n用户问题: {query}" if context else query
            return self._client.generate([
                {'role': 'system', 'content': system_prompt},
                {'role': 'user', 'content': user_prompt},
            ], max_tokens=self.max_new_tokens)
        return self._gen.generate(system_prompt, query, input_context=context)

    def _extractive_answer(self, query: str, context: str) -> str:
        if not context.strip():
            return '当前知识库中未检索到足够依据，建议先核验订单、物流、商品参数或售后规则后再答复。'
        blocks = [b for b in context.split('\n\n') if '内容:' in b]
        used = []
        for block in blocks[:2]:
            body = normalize_text(block.split('内容:', 1)[-1])
            if body:
                used.append(body[:140].rstrip('，,。;；') + '。')
        evidence_refs = []
        for line in context.splitlines():
            if line.startswith('[证据'):
                evidence_refs.append(line.split(']')[0] + ']')
        ref_text = '、'.join(evidence_refs[:2]) if evidence_refs else '检索证据'
        body_text = ''.join(used) if used else '未找到足够证据。'
        return f'基于{ref_text}，{body_text}如证据与订单实时状态不一致，需要进一步核验。'
