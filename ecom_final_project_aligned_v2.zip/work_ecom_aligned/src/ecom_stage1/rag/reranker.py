"""
reranker.py — 检索结果重排器

【修复说明 Fix #3】
原版缺陷：TransformerCrossEncoderReranker.rerank() 直接取 top_k，
          无 score threshold 过滤，低相关度 chunk 也会进入 context，
          导致 hallucination。

修复内容：
  1. 新增 score_threshold 参数（logit 空间，默认 -2.0）
  2. 分数低于 threshold 的 chunk 从结果中过滤
  3. 保底：至少返回 1 条（避免空结果导致无答复）
  4. SimpleHeuristicReranker 也同步添加 threshold 支持

【面试必背】
Bi-Encoder vs Cross-Encoder：
  Bi-Encoder (BGE-M3)：query 和 doc 分别编码，向量内积打分
    → 速度快（doc 可预计算），精度中等，用于粗召回
  Cross-Encoder (bge-reranker)：query+doc 拼接后联合编码，classifier head 打分
    → 速度慢（每对都要推理），精度高（全注意力 cross-attention），用于精排

threshold=-2.0 的含义：
  Cross-Encoder 输出 logit，-2.0 对应约 sigmoid(-2.0)≈12% 的相关概率，
  低于这个值的 chunk 基本是噪声，拦截后能降低幻觉率。
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List, Optional, Sequence

from .schemas import RetrievedChunk
from .text_utils import any_keyword_in_text, tokenize

try:
    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer
except Exception:
    torch = None
    AutoModelForSequenceClassification = None
    AutoTokenizer = None


# ────────────────────────────────────────────────────────────────────────────
# 抽象基类
# ────────────────────────────────────────────────────────────────────────────
class BaseReranker(ABC):
    @abstractmethod
    def rerank(
        self,
        query: str,
        candidates: List[RetrievedChunk],
        top_k: int = 5,
        score_threshold: Optional[float] = None,
    ) -> List[RetrievedChunk]:
        raise NotImplementedError


# ────────────────────────────────────────────────────────────────────────────
# 启发式轻量重排器（无需 GPU，作为 fallback）
# ────────────────────────────────────────────────────────────────────────────
class SimpleHeuristicReranker(BaseReranker):
    """
    基于 token overlap + metadata keyword boost 的轻量重排器。

    不依赖任何深度学习模型，可在 CPU-only 环境作为 Cross-Encoder 的 fallback。
    精度低于 Cross-Encoder，但延迟 <1ms。
    """

    def rerank(
        self,
        query: str,
        candidates: List[RetrievedChunk],
        top_k: int = 5,
        score_threshold: Optional[float] = None,
    ) -> List[RetrievedChunk]:
        q_tokens = set(tokenize(query))
        reranked: List[RetrievedChunk] = []

        for c in candidates:
            c_tokens = set(tokenize(c.text))
            overlap = len(q_tokens & c_tokens) / max(len(q_tokens), 1)

            keyword_boost = 0.0
            if any_keyword_in_text(c.metadata.get('keywords', []), query):
                keyword_boost += 0.2
            if c.source_type == 'rule' and any(
                tok in query for tok in ['退款', '退货', '发票', '保价', '赠品', 'refund', 'invoice']
            ):
                keyword_boost += 0.15

            rerank_score = overlap + keyword_boost
            c.rerank_score = rerank_score
            c.score = 0.5 * c.score + 0.5 * rerank_score
            reranked.append(c)

        reranked.sort(key=lambda x: (x.rerank_score, x.score), reverse=True)

        # 【修复】应用 threshold 过滤（启发式 rerank_score 范围 0~1.2）
        if score_threshold is not None:
            filtered = [c for c in reranked if c.rerank_score >= score_threshold]
            return (filtered or reranked[:1])[:top_k]

        return reranked[:top_k]


# ────────────────────────────────────────────────────────────────────────────
# Transformer Cross-Encoder 精排器
# ────────────────────────────────────────────────────────────────────────────
class TransformerCrossEncoderReranker(BaseReranker):
    """
    Cross-Encoder 重排器。

    工作原理：
      将 query 和每个 candidate document 拼接后送入序列分类模型，
      classifier head 输出相关性 logit。
      比 Bi-Encoder 精度高，但不可预计算 document 向量。

    模型格式：
      输入：[CLS] query [SEP] document [SEP]
      输出：logit（正类分数，越高越相关）

    降级策略：
      若 transformers/torch 不可用或模型加载失败，
      自动降级到 SimpleHeuristicReranker。
    """

    def __init__(
        self,
        model_name: str = 'BAAI/bge-reranker-v2-m3',
        device: str | None = None,
        batch_size: int = 8,
        default_threshold: float = -2.0,   # 【修复】新增：默认 logit threshold
    ):
        self.model_name = model_name
        self.device = device or ('cuda' if torch is not None and torch.cuda.is_available() else 'cpu')
        self.batch_size = batch_size
        self.default_threshold = default_threshold   # logit 阈值，-2.0 ≈ 12% 相关概率
        self._tokenizer = None
        self._model = None
        self._fallback = SimpleHeuristicReranker()
        self.runtime_backend = 'heuristic'

    def __getstate__(self):
        state = self.__dict__.copy()
        state['_tokenizer'] = None
        state['_model'] = None
        return state

    def __setstate__(self, state):
        self.__dict__.update(state)
        self._tokenizer = None
        self._model = None

    def _ensure_model(self) -> bool:
        if self._tokenizer is not None and self._model is not None:
            self.runtime_backend = 'cross_encoder'
            return True
        if AutoTokenizer is None or AutoModelForSequenceClassification is None or torch is None:
            self.runtime_backend = 'heuristic'
            return False
        try:
            self._tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            self._model = AutoModelForSequenceClassification.from_pretrained(self.model_name)
            self._model.to(self.device)
            self._model.eval()
            self.runtime_backend = 'cross_encoder'
            return True
        except Exception:
            self._tokenizer = None
            self._model = None
            self.runtime_backend = 'heuristic'
            return False

    def _score_pairs(self, pairs: Sequence[tuple]) -> List[float]:
        """批量对 (query, doc) 对打分，返回 logit 列表。"""
        scores: List[float] = []
        for i in range(0, len(pairs), self.batch_size):
            sub = pairs[i: i + self.batch_size]
            q = [x[0] for x in sub]
            d = [x[1] for x in sub]
            encoded = self._tokenizer(
                q, d, padding=True, truncation=True,
                max_length=512, return_tensors='pt'
            )
            encoded = {k: v.to(self.device) for k, v in encoded.items()}
            with torch.no_grad():
                outputs = self._model(**encoded)
                logits = outputs.logits
                if logits.ndim == 2 and logits.shape[1] > 1:
                    batch_scores = logits[:, 1]    # 二分类模型取 positive logit
                else:
                    batch_scores = logits.view(-1)
            scores.extend(batch_scores.detach().cpu().tolist())
        return scores

    def rerank(
        self,
        query: str,
        candidates: List[RetrievedChunk],
        top_k: int = 5,
        score_threshold: Optional[float] = None,
    ) -> List[RetrievedChunk]:
        """
        重排 candidates，返回 top_k 条。

        【修复】增加 score_threshold 过滤：
          低于 threshold 的 chunk 视为噪声丢弃，
          避免无关内容进入 context 造成幻觉。
          至少保留 1 条（避免空结果）。
        """
        if not candidates:
            return []

        # 没有 threshold 就用构造时的默认值
        threshold = score_threshold if score_threshold is not None else self.default_threshold

        if not self._ensure_model():
            return self._fallback.rerank(query, candidates, top_k=top_k,
                                         score_threshold=None)  # fallback 不用 logit threshold

        pairs = [(query, c.text) for c in candidates]
        scores = self._score_pairs(pairs)

        reranked: List[RetrievedChunk] = []
        for c, score in zip(candidates, scores):
            c.rerank_score = float(score)
            # 融合：35% 原始 hybrid 分数 + 65% cross-encoder 分数
            # 保留部分 hybrid 分数是为了保留 BM25 的关键词精确匹配信号
            c.score = 0.35 * c.score + 0.65 * float(score)
            reranked.append(c)

        reranked.sort(key=lambda x: (x.rerank_score, x.score), reverse=True)

        # 【修复】threshold 过滤
        filtered = [c for c in reranked if c.rerank_score >= threshold]
        if not filtered:
            filtered = reranked[:1]   # 至少保留最好的 1 条，避免无结果

        return filtered[:top_k]
