from __future__ import annotations

import re
from typing import Iterable, List, Optional

from .entity_schema import EntitySlot, ReplacementResult, ReplacementRule


class DomainEntityReplacer:
    """电商客服领域的槽位替换器。

    目标不是做通用 NER，而是把会影响业务结论的关键槽位
    （时效、责任、订单状态、物流状态、SKU/型号、发票状态）
    显式替换成高风险结论，以支撑 DPO rejected 构造。
    """

    def __init__(self) -> None:
        self.rules: List[ReplacementRule] = [
            ReplacementRule(
                slot_name="refund_window",
                category="refund_request",
                patterns=[r"7天", r"七天", r"1-3个工作日", r"2-3\s*days", r"5-7\s*days"],
                targets=["30天", "15个工作日", "30-45 days"],
                reject_type="extend_return_window",
                reason="放宽退款/退货时效",
            ),
            ReplacementRule(
                slot_name="shipping_responsibility",
                category="refund_request",
                patterns=[r"买家承担", r"customer pays", r"buyer pays", r"用户承担"],
                targets=["商家承担", "merchant covers all shipping fees"],
                reject_type="reverse_shipping_responsibility",
                reason="反转运费责任归属",
            ),
            ReplacementRule(
                slot_name="order_status",
                category="cancel_order",
                patterns=[r"未发货", r"待发货", r"processing", r"pending"],
                targets=["已发货", "派送中", "shipped"],
                reject_type="cancel_after_shipment_overcommit",
                reason="伪造订单状态后仍承诺可取消",
            ),
            ReplacementRule(
                slot_name="logistics_status",
                category="order_status",
                patterns=[r"待揽收", r"运输中", r"processing", r"in transit"],
                targets=["派送中", "今天必达", "out for delivery"],
                reject_type="fake_delivery_status",
                reason="伪造物流状态并绝对化承诺时效",
            ),
            ReplacementRule(
                slot_name="invoice_status",
                category="invoice_and_payment",
                patterns=[r"未开票", r"待开票", r"processing"],
                targets=["已开票", "当天补开并寄出"],
                reject_type="invoice_gift_overcommit",
                reason="越权承诺发票处理进度",
            ),
            ReplacementRule(
                slot_name="product_model",
                category="product_issue",
                patterns=[r"SKU[-_ ]?[A-Za-z0-9]{3,20}", r"[A-Z]{1,4}\d{2,5}[A-Z0-9]{0,8}"],
                targets=["SKU-ALL", "UNIVERSAL-100"],
                reject_type="parameter_absolute_claim",
                reason="将商品型号/参数替换为绝对兼容式表述",
            ),
        ]

    def apply(self, text: str, category: str) -> List[ReplacementResult]:
        text = text or ""
        category = (category or "").strip().lower()
        out: List[ReplacementResult] = []
        for rule in self.rules:
            if rule.category and rule.category != category:
                continue
            for pattern in rule.patterns:
                m = re.search(pattern, text, flags=re.IGNORECASE)
                if not m:
                    continue
                matched = m.group(0)
                for target in rule.targets:
                    replaced = re.sub(pattern, target, text, count=1, flags=re.IGNORECASE)
                    if replaced != text:
                        slot = EntitySlot(
                            slot_name=rule.slot_name,
                            slot_type=rule.slot_name,
                            source_value=matched,
                            target_value=target,
                            risk_level=rule.risk_level,
                            evidence=[pattern],
                        )
                        out.append(
                            ReplacementResult(
                                text=replaced,
                                reject_type=rule.reject_type,
                                reason=rule.reason,
                                slots=[slot],
                            )
                        )
                break
        return out
