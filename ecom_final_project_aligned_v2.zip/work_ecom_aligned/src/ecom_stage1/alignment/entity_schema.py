from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class EntitySlot:
    slot_name: str
    slot_type: str
    source_value: str
    target_value: str
    risk_level: str = "medium"
    evidence: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ReplacementRule:
    slot_name: str
    category: str
    patterns: List[str]
    targets: List[str]
    reject_type: str
    reason: str
    risk_level: str = "high"


@dataclass
class ReplacementResult:
    text: str
    reject_type: str
    reason: str
    slots: List[EntitySlot] = field(default_factory=list)
    strategy: str = "entity_slot_replacement"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "text": self.text,
            "reject_type": self.reject_type,
            "reason": self.reason,
            "slots": [s.to_dict() for s in self.slots],
            "strategy": self.strategy,
        }
