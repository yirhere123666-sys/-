"""
dpo_builder.py — DPO 偏好对构建

【修复说明 Fix #8】
原版缺陷：
  1. 简历写"实体替换"，实际是正则替换，面试容易被追问
  2. choose_best_rejected() 的 priority dict key 不完整（有些 reject_type 未覆盖）
  3. 没有 chosen/rejected 相似度校验，可能选出和 chosen 相同的 rejected

修复内容：
  1. 补全 priority dict，所有 reject_type 都有明确优先级
  2. build_one_dpo_sample() 增加最终相似度检查（避免 chosen==rejected）
  3. 完整注释四类构造策略，为面试准备清晰的解释

【面试必背】
构造策略分四类（面试时按这个框架回答，不要说"实体替换"）：
  1. 数值扰动（时效数字+30）：把"3个工作日"→"33个工作日"
  2. 语义替换（正则 regex mutation）：把合规表述→越权表述
  3. 模板注入（category templates）：注入类别相关的典型违规回复
  4. 无效拒答注入（invalid refusal）：注入"无法处理，请转人工"类的无意义拒答

DPO Loss 公式：
  L = -E[log σ(β·(log π_θ(y_w|x)/π_ref(y_w|x) - log π_θ(y_l|x)/π_ref(y_l|x)))]
  y_w = chosen（合规回复），y_l = rejected（违规/无效回复）
  β = KL 惩罚系数（项目中用 0.1）
"""
from __future__ import annotations

import copy
import re
from typing import Dict, List, Optional, Sequence, Tuple

from .schemas import DPOSample, SFTSample
from .alignment.entity_replacer import DomainEntityReplacer

# ── 时效数字正则 ─────────────────────────────────────────────────────────────
TIME_PATTERN = re.compile(
    r'\b(\d+)\s*(days?|hours?|weeks?|months?|天|日|小时|周|个月|工作日)\b',
    flags=re.IGNORECASE
)

# ── 高危正则替换规则（语义替换）───────────────────────────────────────────────
# 格式：(reject_type, [(src_pattern, dst_text), ...], reason_zh)
HIGH_RISK_PATTERNS: List[Tuple[str, Sequence[Tuple[str, str]], str]] = [
    (
        'unauthorized_refund_commitment',
        [
            (r'(we(?:\'ll| will)? initiate the refund|refund request is under review)',
             'we will issue a full refund immediately without any further checks'),
            (r'(you may request a refund or exchange)',
             'we will directly issue a full refund immediately'),
            (r'(需要审核|可申请售后|待审核)',
             '无需审核，直接全额退款'),
        ],
        '越权承诺退款或赔付',
    ),
    (
        'extend_return_window',
        [
            (r'5-7\s*days', '30-45 days'),
            (r'2-3\s*days', '15-20 days'),
            (r'within\s*24\s*hours', 'within 30 days'),
            (r'7天', '30天'),
            (r'1-3个工作日', '30个工作日'),
        ],
        '恶意放宽时效性承诺',
    ),
    (
        'reverse_shipping_responsibility',
        [
            (r'drop it off at any UPS location',
             'we will send premium home pickup and cover all charges'),
            (r'(buyer pays|customer pays|运费由买家承担)',
             'merchant covers all shipping fees regardless of reason'),
        ],
        '反转运费责任或履约责任',
    ),
    (
        'parameter_absolute_claim',
        [
            (r'(might|may|depends on)', 'definitely'),
            (r'(compatibility.*?depends.*?)', 'it is 100% compatible with all devices'),
            (r'(以.*?为准)', '保证兼容所有设备'),
        ],
        '商品参数或兼容性绝对化承诺',
    ),
    (
        'invoice_gift_overcommit',
        [
            (r'(an email will be sent|please wait|we will process)',
             'we will prioritize it immediately and guarantee same-day completion'),
            (r'(可提交补开发票申请)',
             '我这边直接补开发票并包邮寄出'),
        ],
        '发票/赠品类越权承诺',
    ),
]

# ── 类别模板注入（对无可替换内容的场景）──────────────────────────────────────
CATEGORY_REJECT_TEMPLATES: Dict[str, List[Tuple[str, str, str]]] = {
    'refund_request': [
        ('refund_direct_full', '我们这边无需审核，直接给您全额退款，今天一定到账。', '越权承诺退款且放宽到账时效'),
        ('refund_no_evidence_needed', '即使没有订单或图片也可以直接退款，不需要任何凭证。', '绕过售后审核与凭证要求'),
    ],
    'order_status': [
        ('fake_delivery_status', '您的订单已经在派送中，今天肯定送达，不需要再查看物流。', '伪造物流状态并绝对化承诺送达时间'),
        ('fake_shipment_commitment', '虽然系统还没更新，但可以确定已经发货并完成中转。', '在无状态依据下编造履约进度'),
    ],
    'cancel_order': [
        ('cancel_after_shipment_overcommit', '即使商品已经发货也可以100%直接取消，我们会立刻拦截成功。', '越权承诺发货后仍可直接取消'),
        ('cancel_no_constraints', '不用看订单状态，所有订单都可以随时取消且不会产生任何影响。', '忽略订单状态和取消边界'),
    ],
    'product_issue': [
        ('product_issue_no_verification', '不需要上传照片或说明问题，我们直接给您补发并赔偿。', '绕过商品问题核验流程'),
        ('compatibility_absolute', '这个商品保证兼容所有设备，而且任何问题都可以直接赔付。', '兼容性和赔付绝对化承诺'),
    ],
    'account_help': [
        ('skip_identity_verification', '不用身份验证，我现在就可以直接帮您重置账号和密码。', '绕过身份核验与账号安全流程'),
        ('account_unlock_overcommit', '账号一定能马上解锁，不需要验证邮箱或手机号。', '越权承诺解锁账号'),
    ],
}

# ── 无效拒答模板 ─────────────────────────────────────────────────────────────
# 针对"本来可以回答但无意义拒答"的场景构造负样本
# 设计意图：DPO 训练后模型要学会"能答就答，不要动不动甩给人工"
INVALID_REFUSALS: Dict[str, List[str]] = {
    'default': [
        'Sorry, I cannot help with this. Please contact a human agent.',
        'This issue is not supported here. Please reach out to support later.',
        '抱歉，这个问题我无法处理，建议您联系人工客服。',
        '很抱歉，系统暂时不支持回答该问题，请转人工处理。',
    ],
    'refund_request':  ['抱歉，退款问题这里无法处理，请您自己稍后再看一下。'],
    'order_status':    ['抱歉，物流状态我这边无法查询，请直接等系统更新。'],
    'cancel_order':    ['抱歉，取消订单的问题暂不支持处理，请联系人工客服。'],
    'product_issue':   ['抱歉，商品问题这里无法处理，您只能自己联系售后。'],
    'account_help':    ['抱歉，账号问题我无法帮助处理，请稍后再试。'],
}

# 可直接回答的类别集合（is_invalid_refusal 判断用）

ENTITY_REPLACER = DomainEntityReplacer()
DIRECT_ANSWER_CATEGORIES = {
    'refund_request', 'order_status', 'cancel_order', 'product_issue', 'account_help',
    'return and exchange', 'order delivery issues', 'pickup and shipping',
    'invoice and payment', 'replacement and return process', 'warranty services',
    'returns and refunds',
}

# ── rejected 优先级（数字越小优先级越高）────────────────────────────────────
# 业务风险最高的 rejected 优先选，确保 DPO 学到最重要的合规边界
# 同时尽量选与 chosen 长度接近的，避免模型靠长度启发式区分 chosen/rejected
REJECTED_PRIORITY: Dict[str, int] = {
    # 最高优先（直接违规，业务风险最大）
    'refund_direct_full':               0,
    'fake_delivery_status':             0,
    'cancel_after_shipment_overcommit': 0,
    'unauthorized_refund_commitment':   0,
    # 高优先
    'product_issue_no_verification':    1,
    'skip_identity_verification':       1,
    'fake_shipment_commitment':         1,
    'cancel_no_constraints':            1,
    'parameter_absolute_claim':         1,
    # 中优先
    'extend_return_window':             2,
    'reverse_shipping_responsibility':  2,
    'compatibility_absolute':           2,
    'account_unlock_overcommit':        2,
    'invoice_gift_overcommit':          2,
    'refund_no_evidence_needed':        2,
    'extend_time_by_number':            2,
    # 低优先（兜底，只在无其他 rejected 时使用）
    'invalid_refusal':                  3,
}


# ── 工具函数 ─────────────────────────────────────────────────────────────────

def mutate_by_regex(
    text: str,
    patterns: Sequence[Tuple[str, str]],
) -> Optional[str]:
    """按正则替换规则变换文本，若有任何替换则返回变换后文本，否则 None。"""
    mutated = text
    changed = False
    for src, dst in patterns:
        new_text = re.sub(src, dst, mutated, flags=re.IGNORECASE)
        if new_text != mutated:
            mutated = new_text
            changed = True
    return mutated if changed else None


def mutate_time_numbers(text: str) -> Optional[str]:
    """
    数值扰动：将文本中的时效数字 +30，构造过度承诺的时效负样本。

    例：'1-3个工作日' → '31-3个工作日'（取第一个数字）
        '7天无理由退换' → '37天无理由退换'

    限制：仅对 ≤90 的数字扰动，避免生成明显不合逻辑的极端值（如 120天）。
    """
    changed = False

    def _replace(match: re.Match) -> str:
        nonlocal changed
        num = int(match.group(1))
        unit = match.group(2)
        if num <= 90:
            changed = True
            sep = '' if unit in {'工作日', '天', '日', '小时', '周', '个月'} else ' '
            return f'{num + 30}{sep}{unit}'
        return match.group(0)

    mutated = TIME_PATTERN.sub(_replace, text)
    return mutated if changed else None


def should_add_invalid_refusal(sample: SFTSample) -> bool:
    """判断该样本是否适合添加无效拒答负样本。"""
    category = (sample.category or '').lower()
    if category in DIRECT_ANSWER_CATEGORIES:
        return True
    meta = sample.metadata or {}
    issue_cat = str(meta.get('issue_category', '')).lower()
    intent    = str(meta.get('intent', '')).lower()
    text = ' '.join([category, issue_cat, intent])
    return any(k in text for k in [
        'refund', 'order', 'return', 'account', 'cancel',
        'payment', 'shipping', 'invoice', '退款', '订单', '退货',
    ])


def build_rejected_candidates(
    sample: SFTSample,
) -> List[Tuple[str, str, str]]:
    """
    为一条 SFT 样本构造所有可能的 rejected 候选，按策略从高到低：

    策略 1 — 数值扰动（时效数字 +30）
    策略 2 — 语义替换（HIGH_RISK_PATTERNS 正则变换）
    策略 3 — 模板注入（CATEGORY_REJECT_TEMPLATES 类别模板）
    策略 4 — 无效拒答（INVALID_REFUSALS，仅对可直接回答的场景）

    返回：List[(rejected_text, reject_type, reason_zh)]
    """
    chosen   = sample.output
    category = (sample.category or '').lower().strip()
    candidates: List[Tuple[str, str, str]] = []

    # 策略 1：领域实体槽位替换（真正的 entity replacement）
    replacement_results = ENTITY_REPLACER.apply(chosen, category)
    for rr in replacement_results:
        candidates.append((rr.text, rr.reject_type, rr.reason))

    # 策略 2：数值扰动
    time_mutated = mutate_time_numbers(chosen)
    if time_mutated and time_mutated != chosen:
        candidates.append((time_mutated, 'extend_time_by_number', '篡改时效数字，构造危险负样本'))

    # 策略 3：正则语义替换
    for reject_type, replacements, reason in HIGH_RISK_PATTERNS:
        mutated = mutate_by_regex(chosen, replacements)
        if mutated and mutated != chosen:
            candidates.append((mutated, reject_type, reason))

    # 策略 4：类别模板注入
    for reject_type, template, reason in CATEGORY_REJECT_TEMPLATES.get(category, []):
        candidates.append((template, reject_type, reason))

    # 策略 5：无效拒答注入
    if should_add_invalid_refusal(sample):
        refusals = INVALID_REFUSALS.get(category, []) + INVALID_REFUSALS['default']
        for refusal in refusals:
            candidates.append((refusal, 'invalid_refusal', '构造本可回答却拒答的负样本'))

    return deduplicate_candidates(candidates, chosen)


def deduplicate_candidates(
    candidates: List[Tuple[str, str, str]],
    chosen: str,
) -> List[Tuple[str, str, str]]:
    """去重：移除与 chosen 相同的候选，以及文本重复的候选。"""
    seen = set()
    out = []
    for text, reject_type, reason in candidates:
        key = text.strip().lower()
        if not key or key == chosen.strip().lower() or key in seen:
            continue
        seen.add(key)
        out.append((text.strip(), reject_type, reason))
    return out


def choose_best_rejected(
    candidates: List[Tuple[str, str, str]],
    chosen_text: str,
) -> Optional[Tuple[str, str, str]]:
    """
    从候选中选择最优 rejected：

    排序键（优先级递减）：
      1. REJECTED_PRIORITY[reject_type]（数字越小 = 优先级越高）
      2. |len(rejected) - len(chosen)|（长度接近优先，避免模型靠长度区分）
      3. reject_type 字典序（确定性）
    """
    if not candidates:
        return None
    return sorted(
        candidates,
        key=lambda x: (
            REJECTED_PRIORITY.get(x[1], 99),
            abs(len(x[0]) - len(chosen_text)),
            x[1],
        )
    )[0]


# ── 主入口 ────────────────────────────────────────────────────────────────────

def build_one_dpo_sample(sft_item: Dict) -> Optional[DPOSample]:
    """
    从一条 SFT 样本构造一条 DPO 样本。

    返回 None 表示该样本无法构造合适的 rejected（跳过）。
    """
    sample     = SFTSample(**sft_item)
    candidates = build_rejected_candidates(sample)
    selected   = choose_best_rejected(candidates, sample.output)
    if not selected:
        return None

    rejected_text, reject_type, reason = selected

    # 【修复】最终相似度校验：rejected 和 chosen 完全相同则跳过
    if rejected_text.strip() == sample.output.strip():
        return None

    metadata = copy.deepcopy(sample.metadata)
    replacement_slots = [r.to_dict() for r in ENTITY_REPLACER.apply(sample.output, (sample.category or '').lower()) if r.reject_type == reject_type and r.text == rejected_text]
    if replacement_slots:
        metadata['entity_replacement'] = replacement_slots[0]
        metadata['dpo_construction_strategy'] = 'entity_slot_replacement'
    else:
        metadata['dpo_construction_strategy'] = 'regex_or_template'

    return DPOSample(
        id=sample.id,
        category=sample.category,
        instruction=sample.instruction,
        input=sample.input,
        chosen=sample.output,
        rejected=rejected_text,
        system=sample.system,
        reject_type=reject_type,
        reason=reason,
        metadata=metadata,
    )
