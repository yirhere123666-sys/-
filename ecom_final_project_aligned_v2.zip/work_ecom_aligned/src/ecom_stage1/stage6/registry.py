from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Iterable, List

import yaml

from ecom_stage1.io_utils import load_records
from .schemas import StageArtifact, StageSummary


def _safe_load(path: Path) -> Dict[str, Any] | List[Dict[str, Any]] | None:
    if not path.exists():
        return None
    try:
        rows = load_records(path)
        if path.suffix in {'.json', '.jsonl'}:
            return rows if path.suffix == '.jsonl' else rows
    except Exception:
        pass
    import json
    try:
        with path.open('r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None


def _extract_summary(payload: Any) -> Dict[str, Any]:
    if isinstance(payload, dict):
        if 'summary' in payload and isinstance(payload['summary'], dict):
            return payload['summary']
        return payload
    return {}


def load_stage6_registry(config_path: str | Path) -> Dict[str, Any]:
    with Path(config_path).open('r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def collect_stage_artifacts(config_path: str | Path, root_dir: str | Path = '.') -> List[StageArtifact]:
    cfg = load_stage6_registry(config_path)
    root = Path(root_dir)
    artifacts: List[StageArtifact] = []
    for stage_cfg in cfg.get('stages', []):
        stage = stage_cfg['stage']
        for item in stage_cfg.get('artifacts', []):
            rel = Path(item['path'])
            path = root / rel
            payload = _safe_load(path) if path.exists() else {}
            artifacts.append(StageArtifact(
                stage=stage,
                name=item['name'],
                path=str(rel),
                artifact_type=item.get('type', 'json'),
                exists=path.exists(),
                payload=payload if isinstance(payload, dict) else {'rows': payload or []},
            ))
    return artifacts


def build_stage_summary_table(artifacts: Iterable[StageArtifact]) -> List[StageSummary]:
    by_stage: Dict[str, StageSummary] = {}
    for artifact in artifacts:
        summary = by_stage.setdefault(artifact.stage, StageSummary(stage=artifact.stage, metrics={}, available=False, notes=[]))
        if artifact.exists:
            summary.available = True
            extracted = _extract_summary(artifact.payload)
            if artifact.name in {'service_metrics', 'metrics_snapshot'}:
                for k, v in extracted.items():
                    summary.metrics[f'service.{k}'] = v
            elif artifact.name.endswith('_compare'):
                for k, v in extracted.items():
                    summary.metrics[f'compare.{k}'] = v
            else:
                summary.metrics.update(extracted)
        else:
            summary.notes.append(f"missing:{artifact.name}")
    return sorted(by_stage.values(), key=lambda x: x.stage)
