from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List


@dataclass
class StageArtifact:
    stage: str
    name: str
    path: str
    artifact_type: str
    exists: bool
    payload: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class StageSummary:
    stage: str
    metrics: Dict[str, Any] = field(default_factory=dict)
    available: bool = True
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class BadcaseRecord:
    stage: str
    case_id: str
    category: str
    severity: str
    failure_type: str
    evidence: Dict[str, Any] = field(default_factory=dict)
    recommendation: str = ''

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
