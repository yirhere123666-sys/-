from __future__ import annotations

from datetime import datetime, UTC
from typing import Iterable, List

from .schemas import StageSummary, BadcaseRecord


def _fmt(v):
    if isinstance(v, float):
        return f"{v:.4f}"
    if isinstance(v, dict):
        return str(v)
    return str(v)


def build_markdown_report(project_name: str,
                          stage_summaries: Iterable[StageSummary],
                          badcases: Iterable[BadcaseRecord],
                          include_mermaid: bool = True) -> str:
    summaries = list(stage_summaries)
    bads = list(badcases)
    lines: List[str] = []
    lines.append(f"# {project_name} - Stage 6 系统级评测与复盘报告")
    lines.append('')
    lines.append(f"生成时间：{datetime.now(UTC).isoformat()}Z")
    lines.append('')
    if include_mermaid:
        lines.append('## 全链路架构')
        lines.append('')
        lines.append('```mermaid')
        lines.append('flowchart LR')
        lines.append('A[Stage1 数据工程] --> B[Stage2 SFT/DPO 训练验证]')
        lines.append('B --> C[Stage3 RAG 检索链]')
        lines.append('C --> D[Stage4 Agent/规则/API]')
        lines.append('D --> E[Stage5 服务层与性能优化]')
        lines.append('E --> F[Stage6 评测/复盘/包装]')
        lines.append('```')
        lines.append('')

    lines.append('## 各阶段指标快照')
    lines.append('')
    for s in summaries:
        lines.append(f"### {s.stage}")
        if not s.available:
            lines.append('- 状态：缺少产物')
            if s.notes:
                for n in s.notes:
                    lines.append(f'- note: {n}')
            lines.append('')
            continue
        if not s.metrics:
            lines.append('- 状态：有产物，但无可解析 summary')
            lines.append('')
            continue
        for k, v in s.metrics.items():
            lines.append(f'- {k}: {_fmt(v)}')
        if s.notes:
            for n in s.notes:
                lines.append(f'- note: {n}')
        lines.append('')

    lines.append('## 高优先级 badcase')
    lines.append('')
    if not bads:
        lines.append('- 暂无 badcase')
    else:
        for bc in bads:
            lines.append(f"### [{bc.severity.upper()}] {bc.stage} / {bc.case_id} / {bc.failure_type}")
            lines.append(f"- category: {bc.category}")
            lines.append(f"- recommendation: {bc.recommendation}")
            for k, v in bc.evidence.items():
                lines.append(f"- {k}: {_fmt(v)}")
            lines.append('')

    lines.append('## 建议的下一轮优化')
    lines.append('')
    lines.append('- Stage3：继续围绕 hallucination 和 retrieval_weak badcase 调 chunk、hybrid 权重和 reranker top-k。')
    lines.append('- Stage4：继续围绕 route_miss / action_miss badcase 补强 intent router、rules engine 和 tool chaining。')
    lines.append('- Stage5：继续围绕首块延迟、总延迟和 cache hit 做服务层性能优化。')
    return '\n'.join(lines) + '\n'
