from __future__ import annotations

from typing import Any, Dict, List

from .schemas import BadcaseRecord


def _severity(score: float) -> str:
    if score >= 0.85:
        return 'critical'
    if score >= 0.55:
        return 'high'
    if score >= 0.3:
        return 'medium'
    return 'low'


def _recommendation(failure_type: str) -> str:
    mapping = {
        'hallucination': '优先检查 chunk 粒度、召回噪声和 context builder 规则。',
        'invalid_refusal': '补强 system prompt 与对齐数据中的可答场景，压低无效拒答。',
        'route_miss': '补强 intent router 关键词、优先级和实体抽取规则。',
        'action_miss': '补强 rules engine 与 tool routing 逻辑。',
        'retrieval_weak': '调 chunk、dense/sparse 权重与 reranker top-k。',
        'low_f1': '检查 reference 是否过严，以及 response formatter 是否丢失关键信息。',
    }
    return mapping.get(failure_type, '需要结合 badcase 上下文继续人工复盘。')


def mine_badcases(rag_eval: Dict[str, Any] | None = None,
                  stage4_eval: Dict[str, Any] | None = None,
                  compare_rag_agent: Dict[str, Any] | None = None,
                  top_n: int = 20) -> List[BadcaseRecord]:
    cases: List[BadcaseRecord] = []

    if rag_eval:
        for row in rag_eval.get('details', []):
            score = 0.0
            failure = None
            if row.get('hallucination'):
                score += 0.9
                failure = 'hallucination'
            elif row.get('invalid_refusal'):
                score += 0.75
                failure = 'invalid_refusal'
            elif row.get('hit@5', 1) == 0 or row.get('context_keyword_recall', 1.0) < 0.5:
                score += 0.6
                failure = 'retrieval_weak'
            elif row.get('f1', 1.0) < 0.2:
                score += 0.35
                failure = 'low_f1'
            if failure:
                cases.append(BadcaseRecord(
                    stage='stage3',
                    case_id=row.get('id', ''),
                    category=row.get('category', 'unknown'),
                    severity=_severity(score),
                    failure_type=failure,
                    evidence=row,
                    recommendation=_recommendation(failure),
                ))

    if stage4_eval:
        for row in stage4_eval.get('details', []):
            score = 0.0
            failure = None
            if row.get('route_name') != row.get('expected_route'):
                score += 0.8
                failure = 'route_miss'
            elif row.get('action') != row.get('expected_action'):
                score += 0.7
                failure = 'action_miss'
            elif row.get('invalid_refusal'):
                score += 0.7
                failure = 'invalid_refusal'
            elif row.get('hallucination'):
                score += 0.8
                failure = 'hallucination'
            elif row.get('f1', 1.0) < 0.15:
                score += 0.3
                failure = 'low_f1'
            if failure:
                cases.append(BadcaseRecord(
                    stage='stage4',
                    case_id=row.get('id', ''),
                    category=row.get('route_name', 'unknown'),
                    severity=_severity(score),
                    failure_type=failure,
                    evidence=row,
                    recommendation=_recommendation(failure),
                ))

    if compare_rag_agent:
        for row in compare_rag_agent.get('details', []):
            if row.get('winner') == 'rag':
                cases.append(BadcaseRecord(
                    stage='stage4',
                    case_id=row.get('id', ''),
                    category='rag_beats_agent',
                    severity='medium',
                    failure_type='action_miss',
                    evidence=row,
                    recommendation='检查 agent 路由、工具调用或规则拦截是否过严。',
                ))

    severity_rank = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3}
    cases = sorted(cases, key=lambda x: (severity_rank.get(x.severity, 9), x.case_id))
    return cases[:top_n]
