from __future__ import annotations

from pathlib import Path
import shutil
from typing import Iterable


def export_showcase_bundle(output_dir: str | Path,
                          include_paths: Iterable[str | Path]) -> None:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    for p in include_paths:
        src = Path(p)
        if not src.exists():
            continue
        dst = out / src.name
        if src.is_dir():
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
        else:
            shutil.copy2(src, dst)
