# 电商客服大模型问答系统

这是一个按六个阶段组织的完整项目级实现：

1. **数据工程与对齐准备**：多源客服数据归一化、脱敏、近似去重、SFT 与 DPO 数据构造。  
2. **SFT / DPO 训练验证**：基于 LLaMA-Factory 的 QLoRA SFT 与 DPO 配置、离线预测与对比评测。  
3. **知识库与 RAG 检索链**：FAQ / SOP / 商品参数 / 规则文档加载、切块、BM25 + BGE-M3 混合召回、Cross-Encoder 重排。  
4. **意图路由、规则引擎、外部 API**：规则驱动的 function-style tool orchestration，订单 / 物流 / 商品 / 政策 API 联动。  
5. **推理服务与性能优化**：FastAPI 服务、SSE 流式输出、缓存、在线 benchmark，并支持对接独立部署的 vLLM OpenAI-compatible 服务。  
6. **系统级评测与项目包装**：指标注册、badcase 挖掘、Markdown 报告与展示包导出。  

## 与简历表述对齐的关键实现

- **实体替换构造 DPO 偏好对**：项目使用电商领域槽位替换（退款时效、运费责任、订单状态、物流状态、SKU/型号、发票状态）+ 正则替换 + 模板注入，生成高风险 rejected。  
- **Function Calling 接入订单 API**：工程上采用规则驱动的 function-style tool orchestration。`IntentRouter` 负责路由与生成 `ToolCallPlan`，`ToolExecutor` 按 schema 执行订单 / 物流 / 商品 / 政策工具；工具选择不由 LLM 自主决定。  
- **vLLM 与流式输出**：服务层支持 `vllm_openai` 后端，通过 OpenAI-compatible client 调用独立部署的 `vllm serve`，流式输出使用 SSE。  

## 目录结构

```text
src/ecom_stage1/
├── alignment/   # 实体槽位替换与偏好对构造增强
├── agent/       # 路由、规则、工具编排
├── rag/         # 知识库、检索、重排、RAG 生成
├── service/     # FastAPI 服务、远程模型客户端、指标
├── stage6/      # 系统级评测、badcase、报告导出
└── training/    # 阶段 2 实验规格封装
```

## 关键脚本

- Stage 1: `scripts/run_stage1_pipeline.sh`
- Stage 3: `scripts/run_stage3_pipeline.sh`
- Stage 4: `scripts/run_stage4_pipeline.sh`
- Stage 5: `scripts/run_stage5_pipeline.sh`
- Stage 6: `scripts/run_stage6_pipeline.sh`
- vLLM 服务：`scripts/run_vllm_server.sh`

## 当前定位

这是**完整的项目级实现**，主链已经闭环；如果继续往生产走，重点是接真实业务系统、分布式检索和更大规模线上评测，而不是补主流程。
