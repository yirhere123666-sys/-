from __future__ import annotations

import argparse
import statistics
import time
from pathlib import Path

import requests

from ecom_stage1.io_utils import load_json


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--service-url', type=str, default='http://127.0.0.1:8010')
    ap.add_argument('--eval-set', type=str, default='data/eval/stage4_eval_set.json')
    ap.add_argument('--mode', type=str, default='agent', choices=['plain', 'rag', 'agent'])
    ap.add_argument('--max-samples', type=int, default=20)
    ap.add_argument('--output', type=str, default='data/eval/stage5_benchmark_summary.json')
    args = ap.parse_args()

    items = load_json(args.eval_set)[: args.max_samples]
    latencies = []
    ok = 0
    for item in items:
        payload = {'request_id': item.get('id'), 'mode': args.mode, 'query': item['query'], 'history': item.get('history', [])}
        t0 = time.perf_counter()
        resp = requests.post(args.service_url.rstrip('/') + '/chat', json=payload, timeout=60)
        elapsed = (time.perf_counter() - t0) * 1000.0
        if resp.ok:
            ok += 1
            latencies.append(elapsed)
    summary = {
        'mode': args.mode,
        'num_samples': len(items),
        'ok_count': ok,
        'mean_latency_ms': round(statistics.mean(latencies), 2) if latencies else 0.0,
        'p95_latency_ms': round(sorted(latencies)[max(0, int(len(latencies)*0.95)-1)], 2) if latencies else 0.0,
    }
    Path(args.output).write_text(__import__('json').dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    print(summary)


if __name__ == '__main__':
    main()
