from __future__ import annotations

import argparse
import json
from pathlib import Path

import requests

from ecom_stage1.io_utils import load_json
from ecom_stage1.metrics import binary_accuracy_from_rules, squad_like_f1, keyword_coverage, forbidden_violation, is_invalid_refusal, heuristic_hallucination


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--service-url', type=str, default='http://127.0.0.1:8010')
    ap.add_argument('--eval-set', type=str, default='data/eval/stage4_eval_set.json')
    ap.add_argument('--mode', type=str, default='agent', choices=['plain', 'rag', 'agent'])
    ap.add_argument('--max-samples', type=int, default=50)
    ap.add_argument('--output', type=str, default='data/eval/stage5_online_eval_summary.json')
    args = ap.parse_args()

    items = load_json(args.eval_set)[: args.max_samples]
    rows = []
    for item in items:
        payload = {'request_id': item.get('id'), 'mode': args.mode, 'query': item['query'], 'history': item.get('history', [])}
        resp = requests.post(args.service_url.rstrip('/') + '/chat', json=payload, timeout=60)
        data = resp.json()
        pred = data.get('answer', '')
        ref = item.get('reference_answer', '')
        must = item.get('must_mention', [])
        forbidden = item.get('forbidden_patterns', [])
        rows.append({
            'id': item.get('id'),
            'prediction': pred,
            'acc': binary_accuracy_from_rules(pred, ref, must, forbidden),
            'f1': squad_like_f1(pred, ref),
            'keyword_coverage': keyword_coverage(pred, must),
            'forbidden_violation': forbidden_violation(pred, forbidden),
            'invalid_refusal': is_invalid_refusal(pred, can_answer_directly=item.get('can_answer_directly', True)),
            'hallucination': heuristic_hallucination(pred, ref, must, forbidden),
            'latency_ms': data.get('latency', {}).get('total_ms', 0.0),
        })
    def avg(key):
        return sum(float(r[key]) for r in rows) / len(rows) if rows else 0.0
    summary = {
        'mode': args.mode, 'num_samples': len(rows),
        'accuracy': round(avg('acc'), 4),
        'f1': round(avg('f1'), 4),
        'keyword_coverage': round(avg('keyword_coverage'), 4),
        'invalid_refusal_rate': round(avg('invalid_refusal'), 4),
        'hallucination_rate': round(avg('hallucination'), 4),
        'avg_latency_ms': round(avg('latency_ms'), 2),
    }
    Path(args.output).write_text(json.dumps({'summary': summary, 'details': rows}, ensure_ascii=False, indent=2), encoding='utf-8')
    print(summary)

if __name__ == '__main__':
    main()
