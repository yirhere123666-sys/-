
from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

import argparse
import yaml

from ecom_stage1.io_utils import dump_json, load_records
from ecom_stage1.agent.pipeline import Stage4AgentPipeline


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('--eval-set', default='data/eval/stage4_eval_set.json')
    ap.add_argument('--config', default='configs/stage4_pipeline.yaml')
    ap.add_argument('--output', default='data/eval/stage4_predictions.json')
    return ap.parse_args()


def main():
    args = parse_args()
    cfg = yaml.safe_load(Path(args.config).read_text(encoding='utf-8'))
    pipeline = Stage4AgentPipeline(
        rag_index_dir=cfg['rag_index_dir'],
        rag_system_prompt_path=cfg['rag_system_prompt'],
        stage4_system_prompt_path=cfg['agent_system_prompt'],
        api_data_dir=cfg['api_data_dir'],
        generator_backend=cfg.get('generator_backend', 'extractive'),
        reranker_type=cfg.get('reranker_type'),
        intent_router_config=cfg.get('intent_router_config'),
        rules_engine_config=cfg.get('rules_engine_config'),
    )
    rows = load_records(args.eval_set)
    outputs = []
    for row in rows:
        pred = pipeline.answer(sample_id=row['id'], query=row['query'], history=row.get('history', []))
        outputs.append(pred.to_dict())
    dump_json(outputs, args.output)
    print(f'已写入 {args.output}，共 {len(outputs)} 条')


if __name__ == '__main__':
    main()
