from __future__ import annotations

from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

import argparse
import yaml

from ecom_stage1.stage6.exporter import export_showcase_bundle


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('--report-config', default='configs/stage6_report.yaml')
    return ap.parse_args()


def main():
    args = parse_args()
    cfg = yaml.safe_load((ROOT / args.report_config).read_text(encoding='utf-8'))
    output = ROOT / cfg['bundle_output']
    include_paths = [ROOT / p for p in cfg.get('include_paths', [])]
    include_paths.extend([
        ROOT / cfg['report_output'],
        ROOT / cfg['metrics_output'],
        ROOT / cfg['badcases_output'],
    ])
    export_showcase_bundle(output, include_paths)
    print({'bundle_output': str(output)})


if __name__ == '__main__':
    main()
