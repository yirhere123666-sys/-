#!/usr/bin/env bash
set -euo pipefail
MODEL_PATH=${MODEL_PATH:-Qwen/Qwen2-7B-Instruct}
HOST=${HOST:-0.0.0.0}
PORT=${PORT:-8001}
TP=${TENSOR_PARALLEL_SIZE:-1}
MAX_MODEL_LEN=${MAX_MODEL_LEN:-4096}

python -m vllm.entrypoints.openai.api_server   --model "$MODEL_PATH"   --host "$HOST"   --port "$PORT"   --tensor-parallel-size "$TP"   --max-model-len "$MAX_MODEL_LEN"
