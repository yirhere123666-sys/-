from __future__ import annotations

from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

import argparse
import json
import yaml

from ecom_stage1.io_utils import ensure_parent
from ecom_stage1.stage6.report import build_markdown_report
from ecom_stage1.stage6.schemas import StageSummary, BadcaseRecord


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('--report-config', default='configs/stage6_report.yaml')
    ap.add_argument('--metrics-registry', default='data/reports/stage6_metrics_registry.json')
    ap.add_argument('--badcases', default='data/reports/stage6_badcases.json')
    return ap.parse_args()


def main():
    args = parse_args()
    cfg = yaml.safe_load((ROOT / args.report_config).read_text(encoding='utf-8'))
    metrics_payload = json.loads((ROOT / args.metrics_registry).read_text(encoding='utf-8'))
    badcases_payload = json.loads((ROOT / args.badcases).read_text(encoding='utf-8'))
    summaries = [StageSummary(**s) for s in metrics_payload.get('stage_summaries', [])]
    badcases = [BadcaseRecord(**b) for b in badcases_payload]
    md = build_markdown_report(cfg['project_name'], summaries, badcases)
    output = ROOT / cfg['report_output']
    ensure_parent(output)
    output.write_text(md, encoding='utf-8')
    print({'report': str(output)})


if __name__ == '__main__':
    main()
