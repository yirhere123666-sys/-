#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

echo "[Stage5] Service layer is code-complete. Run in two terminals:"
echo "  Terminal A: python scripts/step24_run_service.py"
echo "  Terminal B: python scripts/step25_benchmark_service.py --mode agent"
echo "Optional online eval: python scripts/step26_eval_online.py --mode agent"
