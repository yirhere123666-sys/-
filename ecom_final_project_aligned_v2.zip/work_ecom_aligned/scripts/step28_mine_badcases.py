from __future__ import annotations

from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

import argparse
import json

from ecom_stage1.io_utils import dump_json
from ecom_stage1.stage6.badcase import mine_badcases


def _load(path: str):
    p = ROOT / path
    if not p.exists():
        return None
    with p.open('r', encoding='utf-8') as f:
        return json.load(f)


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('--rag-eval', default='data/eval/rag_eval_summary.json')
    ap.add_argument('--stage4-eval', default='data/eval/stage4_eval_summary.json')
    ap.add_argument('--compare-rag-agent', default='data/eval/rag_vs_agent_compare.json')
    ap.add_argument('--top-n', type=int, default=20)
    ap.add_argument('--output', default='data/reports/stage6_badcases.json')
    return ap.parse_args()


def main():
    args = parse_args()
    badcases = mine_badcases(
        rag_eval=_load(args.rag_eval),
        stage4_eval=_load(args.stage4_eval),
        compare_rag_agent=_load(args.compare_rag_agent),
        top_n=args.top_n,
    )
    dump_json([b.to_dict() for b in badcases], args.output)
    print({'num_badcases': len(badcases)})


if __name__ == '__main__':
    main()
