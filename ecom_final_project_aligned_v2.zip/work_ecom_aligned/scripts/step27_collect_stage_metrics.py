from __future__ import annotations

from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

import argparse

from ecom_stage1.io_utils import dump_json
from ecom_stage1.stage6.registry import collect_stage_artifacts, build_stage_summary_table


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('--registry-config', default='configs/stage6_registry.yaml')
    ap.add_argument('--output', default='data/reports/stage6_metrics_registry.json')
    return ap.parse_args()


def main():
    args = parse_args()
    artifacts = collect_stage_artifacts(args.registry_config, ROOT)
    summaries = build_stage_summary_table(artifacts)
    payload = {
        'artifacts': [a.to_dict() for a in artifacts],
        'stage_summaries': [s.to_dict() for s in summaries],
    }
    dump_json(payload, args.output)
    print({s.stage: s.available for s in summaries})


if __name__ == '__main__':
    main()
