
#!/usr/bin/env bash
set -euo pipefail

python scripts/step19_prepare_mock_business_data.py
python scripts/step20_build_stage4_eval_set.py
python scripts/step21_run_stage4_predictions.py --config configs/stage4_pipeline.yaml
python scripts/step22_eval_stage4.py
python scripts/step23_compare_rag_vs_agent.py
