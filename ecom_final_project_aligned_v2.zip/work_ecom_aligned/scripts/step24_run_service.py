from __future__ import annotations

from pathlib import Path
import sys
import yaml
import uvicorn

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from ecom_stage1.service.app import app  # noqa: E402

config = yaml.safe_load((ROOT / 'configs' / 'service.yaml').read_text(encoding='utf-8')) or {}
svc = config.get('service', {})

if __name__ == '__main__':
    uvicorn.run(app, host=svc.get('host', '0.0.0.0'), port=int(svc.get('port', 8010)), reload=False)
