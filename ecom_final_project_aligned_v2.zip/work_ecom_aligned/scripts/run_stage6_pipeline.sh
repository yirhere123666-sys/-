#!/usr/bin/env bash
set -euo pipefail
python scripts/step27_collect_stage_metrics.py
python scripts/step28_mine_badcases.py
python scripts/step29_build_stage6_report.py
python scripts/step30_export_showcase_bundle.py
