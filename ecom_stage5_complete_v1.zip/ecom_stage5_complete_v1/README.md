# 电商客服大模型项目：第一阶段完整版代码（第二轮补强版）

这套代码只解决**第一阶段：数据工程与模型对齐**，目标是把你现在手头的真实数据打通成：

1. 原始多轮客服数据解析与归一化  
2. 脱敏、文本标准化、近似去重  
3. SFT 指令数据构造  
4. DPO 偏好对构造（含高风险错误与无效拒绝）  
5. 训练/验证切分与 LLaMA-Factory 注册  
6. 第一阶段离线评测（accuracy / F1 / 合规率 / 无效拒绝率 / 幻觉率 / DPO 胜率）  

---

## 一、第二轮补强的 4 个重点

### 1. 中文电商风格映射层
新增 `src/ecom_stage1/cn_style.py`，并把 `step2_build_sft_dataset.py` 增强为可选：

```bash
python scripts/step2_build_sft_dataset.py \
  --input data/processed/cleaned.json \
  --output data/processed/sft_full.json \
  --system-prompt prompts/system_prompt.txt \
  --style-locale zh_ecom
```

说明：
- 这不是通用机器翻译
- 是为第一阶段训练专门准备的**规则式中文电商客服风格映射层**
- 会把英文客服问答映射成更贴近中文售后语境的提问与回复，并保留原始文本到 metadata

### 2. 更细的 DPO 负样本规则库
DPO 不再只做简单时效改写，当前已经支持：
- 越权承诺退款 / 赔付
- 放宽时效
- 反转运费责任
- 商品兼容性绝对化承诺
- 发票 / 赠品类越权承诺
- 发货后仍保证可取消
- 商品问题不经核验直接补发赔付
- 跳过账号身份验证直接解锁 / 重置
- **无效拒绝型**负样本

### 3. 600 条评测集自动抽样策略
新增 `stratified_eval_sample()`，默认按：
- 类别优先均衡
- 再按 `source / customer_sentiment / issue_complexity` 做 round-robin

默认流程会生成：
- 总量 600 条
- 每类至少 80 条（如果样本足够）

### 4. 一键对接 LLaMA-Factory
`step5_split_register.py` 已增强：
- 既能把数据同步到现有 `LLaMA-Factory/data/`
- 也能直接输出一个 `llamafactory_bundle/`

另外新增：
- `scripts/step5b_prepare_llamafactory_bundle.py`

---

## 二、当前真实数据源定位

### 1. `0000.parquet`
优先级最高，作为第一阶段主数据源。

字段：
- `issue_area`
- `issue_category`
- `issue_sub_category`
- `customer_sentiment`
- `product_category`
- `issue_complexity`
- `agent_experience_level`
- `conversation`

特点：
- 多轮对话
- 带业务标签
- 适合切成 SFT / DPO / eval

### 2. `english_support_dataset.csv`
作为补充单轮 QA 数据源。为了避免一次性读取 100MB+ CSV 占满内存，归一化脚本已改成按需流式读取。

字段：
- `query_id`
- `user_query_en`
- `intent`
- `bot_response_en`
- `category`

特点：
- 单轮、结构规整
- 适合补 SFT 与意图类标签

### 3. `Chat_Team_CaseStudy FINAL.xlsx`
**不作为第一阶段核心训练数据**。领域更偏航空/出行客服，结构也更接近运营日志，而不是标准对话训练集。

---

## 三、统一折叠到五个一阶段类别

归一化时会把多源原始标签统一折叠到五个一阶段类别：
- `refund_request`
- `order_status`
- `cancel_order`
- `product_issue`
- `account_help`

这样 SFT、DPO、eval 和后续面试叙事都保持一致。

---

## 四、目录说明

```text
.
├── configs/
│   ├── qwen2_7b_qlora_sft.yaml
│   └── qwen2_7b_qlora_dpo.yaml
├── prompts/
│   ├── system_prompt.txt
│   ├── eval_judge_prompt.txt
│   └── dpo_compare_judge_prompt.txt
├── scripts/
│   ├── step0a_inspect_sources.py
│   ├── step0b_normalize_parquet.py
│   ├── step0c_normalize_csv.py
│   ├── step0d_merge_normalized.py
│   ├── step1_clean_dedup.py
│   ├── step2_build_sft_dataset.py
│   ├── step3_build_dpo_pairs.py
│   ├── step4_build_eval_set.py
│   ├── step5_split_register.py
│   ├── step5b_prepare_llamafactory_bundle.py
│   ├── step6_quality_report.py
│   ├── step7_run_sft.sh
│   ├── step8_run_dpo.sh
│   ├── step9_generate_predictions.py
│   ├── step10_eval_stage1.py
│   ├── step11_compare_sft_vs_dpo.py
│   └── run_stage1_pipeline.sh
├── src/ecom_stage1/
│   ├── cn_style.py
│   ├── io_utils.py
│   ├── schemas.py
│   ├── normalization.py
│   ├── masking.py
│   ├── dedup.py
│   ├── prompts.py
│   ├── dpo_builder.py
│   ├── eval_builder.py
│   ├── metrics.py
│   ├── judge.py
│   ├── quality.py
│   └── inference.py
└── tests/
    ├── conftest.py
    ├── test_masking_and_normalization.py
    ├── test_dpo_builder.py
    ├── test_parquet_parser.py
    ├── test_cn_style_and_eval.py
    └── test_pipeline_smoke.py
```

---

## 五、推荐实际流程

### 方式 A：一键跑完整第一阶段数据工程（推荐）

```bash
STYLE_LOCALE=zh_ecom \
EVAL_TARGET_SIZE=600 \
bash scripts/run_stage1_pipeline.sh
```

默认会读取：
- `/mnt/data/0000.parquet`
- `/mnt/data/english_support_dataset.csv`

默认输出到 `data/`。

可选环境变量：
- `STYLE_LOCALE=origin|zh_ecom`
- `CSV_MAX=50000`
- `PARQUET_MAX=1000`
- `EVAL_TARGET_SIZE=600`
- `EVAL_MIN_PER_CATEGORY=80`
- `LF_DATA_DIR=/path/to/LLaMA-Factory/data`
- `LF_ROOT=/path/to/LLaMA-Factory`

### 方式 B：手动分步跑

```bash
python scripts/step0b_normalize_parquet.py \
  --input /mnt/data/0000.parquet \
  --output data/intermediate/parquet_normalized.jsonl \
  --ecom-only \
  --max-samples 1000

python scripts/step0c_normalize_csv.py \
  --input /mnt/data/english_support_dataset.csv \
  --output data/intermediate/csv_normalized.jsonl \
  --max-samples 50000

python scripts/step0d_merge_normalized.py \
  --inputs data/intermediate/parquet_normalized.jsonl data/intermediate/csv_normalized.jsonl \
  --output data/intermediate/merged_normalized.jsonl

python scripts/step1_clean_dedup.py \
  --input data/intermediate/merged_normalized.jsonl \
  --output data/processed/cleaned.json \
  --threshold 0.88

python scripts/step2_build_sft_dataset.py \
  --input data/processed/cleaned.json \
  --output data/processed/sft_full.json \
  --system-prompt prompts/system_prompt.txt \
  --style-locale zh_ecom

python scripts/step3_build_dpo_pairs.py \
  --input data/processed/sft_full.json \
  --output data/processed/dpo_full.json

python scripts/step4_build_eval_set.py \
  --input data/processed/cleaned.json \
  --output data/eval/eval_stage1.json \
  --mode stratified \
  --target-size 600 \
  --min-per-category 80

python scripts/step5_split_register.py \
  --sft-input data/processed/sft_full.json \
  --dpo-input data/processed/dpo_full.json \
  --eval-input data/eval/eval_stage1.json \
  --out-dir data/lf_ready \
  --llamafactory-data-dir /path/to/LLaMA-Factory/data \
  --llamafactory-root /path/to/LLaMA-Factory

python scripts/step6_quality_report.py \
  --input data/processed/sft_full.json \
  --query-key instruction \
  --answer-key output \
  --output data/processed/stage1_quality_report.json
```

---

## 六、训练与评测

把 `data/lf_ready/*.json` 和 `data/lf_ready/dataset_info.ecom_stage1.json` 复制到 LLaMA-Factory 的 `data/` 目录，再执行：

```bash
bash scripts/step7_run_sft.sh
bash scripts/step8_run_dpo.sh
```

或者直接基于 bundle 启动：

```bash
python scripts/step5b_prepare_llamafactory_bundle.py \
  --lf-ready-dir data/lf_ready \
  --output-dir data/lf_ready/lf_bundle
```

离线预测与评测：

```bash
python scripts/step9_generate_predictions.py \
  --model-path saves/Qwen2-7B/sft_stage1 \
  --backend hf \
  --eval-set data/lf_ready/eval_stage1.json \
  --output outputs/sft_predictions.json

python scripts/step10_eval_stage1.py \
  --eval-set data/lf_ready/eval_stage1.json \
  --predictions outputs/sft_predictions.json \
  --output outputs/sft_eval.json

python scripts/step11_compare_sft_vs_dpo.py \
  --eval-set data/lf_ready/eval_stage1.json \
  --pred-sft outputs/sft_predictions.json \
  --pred-dpo outputs/dpo_predictions.json \
  --output outputs/compare_sft_dpo.json
```

---

## 七、这套代码已经补齐的关键点

### 1. parquet 多轮解析
支持从 `conversation` 长字符串解析出真正的 `user / assistant` 多轮消息流。

### 2. 多源标签统一
parquet 和 CSV 的原始标签会统一折叠到五个一阶段类别，避免训练、评测和面试叙事不一致。

### 3. 流式读取大文件
CSV 归一化不会再先把 100MB+ 全读进内存再截断。

### 4. 中文电商风格映射
你可以在第一阶段就把英文客服数据映射成更像中文电商售后项目的客服风格，但会保留原始文本到 metadata，方便回溯。

### 5. DPO 负样本不是随机造的
目前支持：
- 越权退款 / 过度赔付
- 时效性数字放宽
- 责任归属反转
- 商品兼容性绝对化承诺
- 发票 / 补偿类越权承诺
- 发货后仍保证可取消
- 商品问题不经核验直接补发赔付
- 无效拒绝型负样本
- 跳过身份核验直接重置账号

### 6. 第一阶段评测闭环
支持：
- `accuracy`
- `token F1`
- `policy_compliance_rate`
- `invalid_refusal_rate`
- `hallucination_rate`
- `dpo_win_rate`

---

## 八、测试

```bash
pytest -q
```

当前测试覆盖：
- 脱敏逻辑
- 多轮对话归一化
- parquet 类别归一化
- DPO 构造
- 中文电商风格映射
- 600 条评测集抽样策略
- pipeline smoke test


---

# 第三阶段：知识库与 RAG 检索链（完整版）

第三阶段在第一阶段和第二阶段基础上，新增：

1. 知识库原始语料构建（`step12_prepare_kb_corpus.py`）
2. 语义切块与 metadata 增强（`step13_chunk_kb.py`）
3. 稀疏 / 稠密索引构建（`step14_build_indexes.py`）
4. 评测集混合召回与上下文构建（`step15_retrieve_eval.py`）
5. 基于 RAG 的离线预测（`step16_generate_rag_predictions.py`）
6. RAG 评测与 plain vs RAG 对比（`step17_eval_rag.py`、`step18_compare_plain_vs_rag.py`）

第三阶段的新增源码位于：

```text
src/ecom_stage1/rag/
├── schemas.py
├── text_utils.py
├── knowledge_loader.py
├── chunker.py
├── embeddings.py
├── sparse_retriever.py
├── dense_retriever.py
├── hybrid_retriever.py
├── reranker.py
├── context_builder.py
├── generator.py
├── pipeline.py
└── retrieval_eval.py
```

### 一键运行第三阶段

```bash
bash scripts/run_stage3_pipeline.sh
```

可选环境变量：
- `INCLUDE_CLEANED=1`：把第一阶段 `data/processed/cleaned.json` 也蒸馏进知识库
- `TOP_K=5`
- `RAG_BACKEND=extractive|hf|vllm`
- `BASE_MODEL=Qwen/Qwen2-7B-Instruct`
- `MODEL_PATH=/path/to/adapter-or-model`

### 第三阶段默认目录

```text
data/kb/raw/                # FAQ / SOP / 商品参数 / 规则原始文档
data/kb/processed/          # kb_corpus.jsonl / kb_chunks.jsonl
data/indexes/rag_stage3/    # bm25.pkl / dense.pkl / manifest.json
data/eval/retrieved_eval.json
data/eval/rag_predictions.json
data/eval/rag_eval_summary.json
```


## Stage 3 补强说明（v2）

本版第三阶段做了 4 个关键补强：

1. **真实 embedding 优先**：`DenseEmbedder` 支持 `backend=bge_m3`，优先尝试用 Hugging Face / Transformers 加载真实向量模型；环境或模型不可用时自动回退到 `tfidf_svd`，保证工程可离线运行。
2. **真实 reranker 优先**：`TransformerCrossEncoderReranker` 支持加载 `BAAI/bge-reranker-v2-m3` 这类 Cross-Encoder / Reranker 模型；不可用时自动回退到启发式重排。
3. **更完整的检索评测**：新增 `hit@10`、`citation_precision@5`、`source_diversity@5`，让检索链评估不只停留在简单 recall。
4. **更稳的 RAG prompt 与上下文构建**：context 中保留证据编号、来源类型、相对路径、类目、SKU、检索/重排分数；系统提示明确要求“不足证据时先核验，禁止编造或越权承诺”。


## Stage 4：业务规则与外部 API 编排

Stage 4 在 Stage 3 的 RAG 之上补齐了完整客服系统所需的：
- 意图路由（policy / order / logistics / product / complaint）
- 业务规则引擎（高风险拦截、需核验、转人工）
- 外部工具调用（订单、物流、商品、政策 API）
- Route-aware 响应编排（RAG / API / Mixed / Handoff）
- Stage4 评测与 `RAG vs Agent` 对比

新增目录：
- `src/ecom_stage1/agent/`
- `data/apis/`
- `scripts/step19_*` 到 `step23_*`

一键运行：
```bash
bash scripts/run_stage4_pipeline.sh
```


## Stage 5 - Serving & Performance

This stage wraps Stage 4 into a deployable service layer:
- FastAPI service (`src/ecom_stage1/service/app.py`)
- `/chat` and `/chat/stream` unified endpoints
- plain / rag / agent modes
- OpenAI-compatible backend support for decoupled vLLM serving
- in-memory TTL cache
- latency tracing and `/metrics`
- benchmark and online eval scripts (`step25`, `step26`)

Quick start:
```bash
python scripts/step24_run_service.py
```
Then benchmark:
```bash
python scripts/step25_benchmark_service.py --mode agent
```
