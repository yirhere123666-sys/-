
from __future__ import annotations

from pathlib import Path
from typing import Dict, List

import yaml

from .entity_extractor import EntityExtractor
from .schemas import RouteDecision, ToolCall


class IntentRouter:
    def __init__(self, config_path: str | Path | None = None):
        self.extractor = EntityExtractor()
        self.config = self._load_config(config_path)

    def _load_config(self, config_path: str | Path | None) -> Dict:
        default = {
            'default_confidence_threshold': 0.6,
            'handoff_keywords': ['投诉', '人工', '差评', '怒'],
            'api_first_intents': ['order_or_logistics_query', 'cancel_order'],
            'mixed_intents': ['refund_or_aftersale', 'account_help', 'invoice_policy', 'product_info'],
            'rag_intents': ['policy_default'],
        }
        if not config_path:
            return default
        path = Path(config_path)
        if not path.exists():
            return default
        data = yaml.safe_load(path.read_text(encoding='utf-8')) or {}
        return {**default, **data}

    def route(self, query: str, history: List[Dict[str, str]] | None = None) -> RouteDecision:
        history = history or []
        entities = self.extractor.extract(query)
        reasons: List[str] = []

        if entities['is_angry'] or entities['wants_human']:
            return RouteDecision('complaint_handoff', 'handoff', 0.97, ['检测到强投诉或明确转人工诉求'], entities)

        if entities['has_cancel_keyword']:
            tool_calls: List[ToolCall] = []
            if entities['order_ids']:
                oid = entities['order_ids'][0]
                tool_calls.append(ToolCall(name='get_order_status', args={'order_id': oid}))
                tool_calls.append(ToolCall(name='get_logistics_by_order', args={'order_id': oid}))
            return RouteDecision('cancel_order', 'api', 0.94, ['命中取消订单意图'], entities, tool_calls, {'category': '取消订单'})

        if entities['has_invoice_keyword']:
            tool_calls = [ToolCall(name='get_policy', args={'policy_key': 'invoice_policy'})]
            if entities['order_ids']:
                tool_calls.append(ToolCall(name='get_order_status', args={'order_id': entities['order_ids'][0]}))
            return RouteDecision('invoice_policy', 'mixed', 0.9, ['命中发票/开票关键词'], entities, tool_calls, {'category': '发票'})

        if entities['has_refund_keyword']:
            reasons.append('命中退款/售后意图')
            tool_calls = [ToolCall(name='get_policy', args={'policy_key': 'refund_policy'})]
            if entities['order_ids']:
                tool_calls.append(ToolCall(name='get_order_status', args={'order_id': entities['order_ids'][0]}))
            return RouteDecision('refund_or_aftersale', 'mixed', 0.9, reasons, entities, tool_calls, {'category': '退换货'})

        if entities['has_account_keyword']:
            return RouteDecision('account_help', 'mixed', 0.84, ['命中账号/登录关键词'], entities, [ToolCall(name='get_account_policy', args={})], {'category': '账号帮助'})

        if entities['has_product_keyword'] or entities['sku_ids']:
            filters = {'category': '商品咨询'}
            tool_calls: List[ToolCall] = []
            if entities['sku_ids']:
                filters['sku'] = entities['sku_ids'][0]
                tool_calls.append(ToolCall(name='get_product_info', args={'sku': entities['sku_ids'][0]}))
                return RouteDecision('product_info', 'mixed', 0.88, ['命中商品咨询关键词且抽取到SKU'], entities, tool_calls, filters)
            return RouteDecision('product_info', 'rag', 0.82, ['命中商品咨询关键词'], entities, [], filters)

        # 订单/物流属于动态状态，优先走 API；放在 invoice/refund/product 之后，避免有订单号时误分流
        if entities['has_logistics_keyword'] or entities['tracking_ids'] or entities['order_ids']:
            tool_calls: List[ToolCall] = []
            reasons.append('命中订单/物流动态查询信号')
            if entities['order_ids']:
                oid = entities['order_ids'][0]
                tool_calls.append(ToolCall(name='get_order_status', args={'order_id': oid}))
                tool_calls.append(ToolCall(name='get_logistics_by_order', args={'order_id': oid}))
            if entities['tracking_ids']:
                tool_calls.append(ToolCall(name='get_logistics_status', args={'tracking_id': entities['tracking_ids'][0]}))
            return RouteDecision('order_or_logistics_query', 'api', 0.93, reasons, entities, tool_calls, {'category': '订单状态'})

        return RouteDecision('policy_default', 'rag', 0.65, ['默认回退到知识检索'], entities, [], {})
