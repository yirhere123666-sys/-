from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Dict, List, Optional

from ecom_stage1.agent.pipeline import Stage4AgentPipeline
from ecom_stage1.agent.schemas import Stage4Response
from ecom_stage1.io_utils import load_text
from ecom_stage1.rag.pipeline import RAGPipeline

from .adapters import PlainResponder, load_yaml
from .cache import TTLCache
from .schemas import ChatRequest, ChatResponse, LatencyBreakdown, RetrievalCitation, ServiceHealth
from .tracing import MetricsRegistry, RequestTimer


class Stage5ServingOrchestrator:
    def __init__(self, root_dir: str | Path):
        self.root_dir = Path(root_dir)
        self.config = load_yaml(self.root_dir / 'configs' / 'service.yaml')
        svc = self.config.get('service', {})
        pipe = self.config.get('pipelines', {})

        self.metrics = MetricsRegistry()
        self.cache = TTLCache(ttl_seconds=svc.get('cache_ttl_seconds', 300), max_items=svc.get('cache_max_items', 1024)) if svc.get('enable_cache', True) else None
        plain_backend = pipe.get('plain_backend', 'extractive')
        plain_model = pipe.get('plain_model', 'Qwen/Qwen2-7B-Instruct')
        plain_model_path = pipe.get('plain_model_path')
        plain_prompt = load_text(self.root_dir / 'prompts' / 'system_prompt.txt')
        self.plain = PlainResponder(backend=plain_backend, base_model=plain_model, model_path=plain_model_path, system_prompt=plain_prompt)

        rag_backend = pipe.get('rag_backend', 'extractive')
        rag_model = pipe.get('rag_base_model', 'Qwen/Qwen2-7B-Instruct')
        rag_model_path = pipe.get('rag_model_path')
        self.rag = RAGPipeline(
            index_dir=self.root_dir / pipe.get('rag_index_dir', 'data/indexes/rag_stage3'),
            system_prompt_path=self.root_dir / 'prompts' / 'rag_system_prompt.txt',
            generator_backend=rag_backend,
            base_model=rag_model,
            model_path=rag_model_path,
            reranker_type=pipe.get('reranker_type'),
            reranker_model_name=pipe.get('reranker_model_name'),
        )

        self.agent = Stage4AgentPipeline(
            rag_index_dir=self.root_dir / pipe.get('rag_index_dir', 'data/indexes/rag_stage3'),
            rag_system_prompt_path=self.root_dir / 'prompts' / 'rag_system_prompt.txt',
            stage4_system_prompt_path=self.root_dir / 'prompts' / 'agent_system_prompt.txt',
            api_data_dir=self.root_dir / pipe.get('api_data_dir', 'data/apis'),
            generator_backend=pipe.get('agent_generator_backend', rag_backend),
            base_model=pipe.get('agent_base_model', rag_model),
            model_path=pipe.get('agent_model_path', rag_model_path),
            reranker_type=pipe.get('reranker_type'),
            reranker_model_name=pipe.get('reranker_model_name'),
            intent_router_config=self.root_dir / 'configs' / 'intent_router.yaml',
            rules_engine_config=self.root_dir / 'configs' / 'rules_engine.yaml',
        )

    def _cache_key(self, req: ChatRequest) -> str:
        raw = json.dumps({
            'mode': req.mode, 'query': req.query, 'history': [m.model_dump() for m in req.history], 'top_k': req.top_k, 'metadata': req.metadata
        }, ensure_ascii=False, sort_keys=True)
        return hashlib.sha256(raw.encode('utf-8')).hexdigest()

    def _citations(self, cits):
        out = []
        for idx, c in enumerate(cits or [], start=1):
            out.append(RetrievalCitation(
                index=idx,
                label=c.get('label', f'证据{idx}'),
                source_type=c.get('source_type'),
                source_path=c.get('source_path'),
                category=c.get('category'),
                sku=c.get('sku'),
                score=c.get('score'),
            ))
        return out

    def health(self) -> ServiceHealth:
        idx_dir = self.root_dir / self.config['pipelines'].get('rag_index_dir', 'data/indexes/rag_stage3')
        api_dir = self.root_dir / self.config['pipelines'].get('api_data_dir', 'data/apis')
        return ServiceHealth(
            status='ok',
            version='stage5-v1',
            plain_backend=self.config['pipelines'].get('plain_backend', 'extractive'),
            rag_backend=self.config['pipelines'].get('rag_backend', 'extractive'),
            cache_enabled=self.cache is not None,
            indexes_present=idx_dir.exists(),
            api_data_present=api_dir.exists(),
        )

    def metrics_snapshot(self):
        return self.metrics.snapshot()

    def handle(self, req: ChatRequest) -> ChatResponse:
        timer = RequestTimer()
        request_id = req.request_id or self._cache_key(req)[:12]
        key = self._cache_key(req)
        if self.cache is not None and req.use_cache:
            cached = self.cache.get(key)
            if cached is not None:
                timer.cache_hit = True
                lat = LatencyBreakdown(total_ms=0.0, cache_hit=True)
                resp = ChatResponse(**cached)
                resp.latency = lat
                self.metrics.observe(req.mode, 0.0, 0.0, cache_hit=True, handoff=(resp.action == 'handoff'))
                return resp

        try:
            if req.mode == 'plain':
                with timer.span('generation'):
                    answer = self.plain.answer(req.query, [m.model_dump() for m in req.history])
                resp = ChatResponse(
                    request_id=request_id, mode='plain', answer=answer, route='plain', action='answer', citations=[], trace=['mode=plain'],
                    latency=LatencyBreakdown(total_ms=0.0), metadata={'pipeline_stage': 'stage5'}
                )
            elif req.mode == 'rag':
                with timer.span('rag'):
                    pred = self.rag.answer(sample_id=request_id, query=req.query, history=[m.model_dump() for m in req.history], top_k=req.top_k)
                resp = ChatResponse(
                    request_id=request_id, mode='rag', answer=pred.answer, route='rag', action='rag_answer', citations=self._citations(pred.citations), trace=[f"rag_hits={len(pred.retrieved_chunks)}"],
                    latency=LatencyBreakdown(total_ms=0.0), metadata=pred.metadata or {}
                )
            else:
                with timer.span('route'):
                    # route timing happens inside agent, but we reserve span for parity
                    pass
                with timer.span('generation'):
                    pred: Stage4Response = self.agent.answer(sample_id=request_id, query=req.query, history=[m.model_dump() for m in req.history])
                resp = ChatResponse(
                    request_id=request_id, mode='agent', answer=pred.answer, route=pred.route.route_name if pred.route else None, action=pred.rule_decision.action if pred.rule_decision else None,
                    citations=self._citations(pred.citations), trace=list(pred.decision_trace or []), latency=LatencyBreakdown(total_ms=0.0), metadata=pred.metadata or {}
                )
            total_ms = timer.total_ms()
            resp.latency = LatencyBreakdown(
                total_ms=round(total_ms, 2),
                route_ms=round(timer.spans.get('route', 0.0), 2),
                rule_ms=round(timer.spans.get('rule', 0.0), 2),
                tools_ms=round(timer.spans.get('tools', 0.0), 2),
                rag_ms=round(timer.spans.get('rag', 0.0), 2),
                generation_ms=round(timer.spans.get('generation', 0.0), 2),
                cache_hit=timer.cache_hit,
            )
            self.metrics.observe(req.mode, total_ms, 0.0, cache_hit=timer.cache_hit, handoff=(resp.action == 'handoff'))
            payload = resp.model_dump()
            if self.cache is not None and req.use_cache:
                self.cache.set(key, payload)
            return resp
        except Exception:
            self.metrics.observe(req.mode, timer.total_ms(), 0.0, error=True)
            raise

    def stream(self, req: ChatRequest):
        # simple SSE-friendly generator with first-chunk timing support
        import time
        started = time.perf_counter()
        if req.mode == 'plain':
            gen = self.plain.stream_answer(req.query, [m.model_dump() for m in req.history])
            yield {'event': 'meta', 'data': {'mode': 'plain'}}
            first = None
            answer_parts = []
            for piece in gen:
                if first is None:
                    first = (time.perf_counter() - started) * 1000.0
                answer_parts.append(piece)
                yield {'event': 'delta', 'data': piece}
            total = (time.perf_counter() - started) * 1000.0
            self.metrics.observe('plain', total, first or total)
            yield {'event': 'done', 'data': {'answer': ''.join(answer_parts), 'latency_ms': round(total, 2)}}
            return
        # agent/rag fallback to full response and chunk locally
        resp = self.handle(req)
        first = None
        accum = []
        yield {'event': 'meta', 'data': {'mode': req.mode, 'route': resp.route, 'action': resp.action}}
        for piece in resp.answer:
            if first is None:
                first = (time.perf_counter() - started) * 1000.0
            accum.append(piece)
            yield {'event': 'delta', 'data': piece}
        total = (time.perf_counter() - started) * 1000.0
        self.metrics.observe(req.mode, total, first or total, handoff=(resp.action == 'handoff'))
        yield {'event': 'done', 'data': {'answer': ''.join(accum), 'latency_ms': round(total, 2), 'citations': [c.model_dump() for c in resp.citations], 'trace': resp.trace}}
