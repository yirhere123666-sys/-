from pathlib import Path

from ecom_stage1.agent.pipeline import Stage4AgentPipeline


def test_stage4_pipeline_runs():
    root = Path(__file__).resolve().parents[1]
    p = Stage4AgentPipeline(
        rag_index_dir=root / 'data/indexes/rag_stage3',
        rag_system_prompt_path=root / 'prompts/rag_system_prompt.txt',
        stage4_system_prompt_path=root / 'prompts/agent_system_prompt.txt',
        api_data_dir=root / 'data/apis',
        generator_backend='extractive',
    )
    out = p.answer('x1', '订单87654321还能取消吗？')
    assert out.route.route_name == 'cancel_order'
    assert out.answer
