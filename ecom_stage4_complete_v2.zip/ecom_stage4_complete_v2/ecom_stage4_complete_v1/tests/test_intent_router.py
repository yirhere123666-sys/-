from ecom_stage1.agent.intent_router import IntentRouter


def test_route_order_query():
    router = IntentRouter()
    d = router.route('我的订单12345678现在到哪了？')
    assert d.route_name == 'order_or_logistics_query'
    assert d.route_type == 'api'


def test_route_complaint_handoff():
    router = IntentRouter()
    d = router.route('我要投诉，人工出来')
    assert d.route_type == 'handoff'
