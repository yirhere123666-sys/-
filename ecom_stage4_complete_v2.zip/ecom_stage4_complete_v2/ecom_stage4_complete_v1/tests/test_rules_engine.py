from ecom_stage1.agent.rules_engine import RulesEngine
from ecom_stage1.agent.schemas import RouteDecision, ToolResult


def test_cancel_shipped_order_denied():
    engine = RulesEngine()
    route = RouteDecision(route_name='cancel_order', route_type='mixed', confidence=0.9)
    results = [ToolResult(name='get_order_status', success=True, payload={'found': True, 'status': 'shipped'})]
    decision = engine.apply('订单87654321还能取消吗？', route, results)
    assert decision.action == 'deny'
