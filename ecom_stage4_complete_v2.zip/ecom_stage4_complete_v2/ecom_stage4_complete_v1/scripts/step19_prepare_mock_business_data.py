from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from pathlib import Path

from ecom_stage1.io_utils import dump_json


def main():
    base = Path('data/apis')
    base.mkdir(parents=True, exist_ok=True)
    dump_json([
        {'order_id': '12345678', 'status': 'processing', 'status_cn': '待发货', 'can_cancel': True, 'sku': 'SKU-A15P256', 'paid': True},
        {'order_id': '87654321', 'status': 'shipped', 'status_cn': '已发货', 'can_cancel': False, 'sku': 'SKU-A15P256', 'paid': True},
        {'order_id': '99887766', 'status': 'delivered', 'status_cn': '已签收', 'can_cancel': False, 'sku': 'SKU-Buds3', 'paid': True},
    ], base / 'orders.json')
    dump_json([
        {'tracking_id': 'SF123456789CN', 'status': 'in_transit', 'status_cn': '运输中', 'last_event': '已到达上海转运中心'},
        {'tracking_id': 'YT9876543210', 'status': 'out_for_delivery', 'status_cn': '派送中', 'last_event': '派件员正在派送'},
    ], base / 'logistics.json')
    dump_json([
        {'sku': 'SKU-A15P256', 'title': 'A15 Pro 256G 手机', 'features': ['支持NFC', '支持双卡双待', '门禁兼容性取决于设备与系统']},
        {'sku': 'SKU-Buds3', 'title': 'Buds 3 蓝牙耳机', 'features': ['支持主动降噪', '7天质量问题可走售后', '不支持无条件以旧换新']},
    ], base / 'products.json')
    dump_json([
        {'policy_key': 'account_help', 'content': '账号问题需先完成身份验证，不能直接重置密码。'},
        {'policy_key': 'refund_policy', 'content': '退款、退货需依据订单状态和售后规则处理，不能越权直接承诺。'},
    ], base / 'policies.json')
    print(f'已写入模拟业务数据到 {base}')


if __name__ == '__main__':
    main()
