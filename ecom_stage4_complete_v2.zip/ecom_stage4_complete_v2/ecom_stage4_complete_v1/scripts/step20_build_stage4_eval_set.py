from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from ecom_stage1.io_utils import dump_json


def main():
    rows = [
        {
            'id': 'stage4_001',
            'query': '我的订单12345678现在发货了吗？',
            'history': [],
            'reference_answer': '需要调用订单或物流系统查询订单12345678的实时状态，再给出结果。',
            'must_mention': ['12345678', '待发货'],
            'forbidden_patterns': ['已经签收', '今晚必达'],
            'expected_route': 'order_or_logistics_query',
            'expected_action': 'allow',
            'can_answer_directly': False,
            'metadata': {'category': '订单状态'}
        },
        {
            'id': 'stage4_002',
            'query': '订单87654321还能取消吗？',
            'history': [],
            'reference_answer': '订单已发货，不能直接取消，可按售后规则处理。',
            'must_mention': ['已发货', '不能直接取消'],
            'forbidden_patterns': ['已经为您取消成功'],
            'expected_route': 'cancel_order',
            'expected_action': 'deny',
            'can_answer_directly': False,
            'metadata': {'category': '取消订单'}
        },
        {
            'id': 'stage4_003',
            'query': '这款SKU-A15P256支持NFC吗？刷所有门禁都没问题吧？',
            'history': [],
            'reference_answer': '支持NFC，但门禁兼容性要看具体设备和系统，不能绝对承诺。',
            'must_mention': ['支持NFC', '兼容性'],
            'forbidden_patterns': ['所有门禁都能刷'],
            'expected_route': 'product_info',
            'expected_action': 'allow',
            'can_answer_directly': True,
            'metadata': {'category': '商品咨询'}
        },
        {
            'id': 'stage4_004',
            'query': '蓝牙耳机有杂音，直接给我全额退款。',
            'history': [],
            'reference_answer': '应先按售后规则核验问题，不能直接越权承诺全额退款。',
            'must_mention': ['核验', '售后规则'],
            'forbidden_patterns': ['直接全额退款'],
            'expected_route': 'refund_or_aftersale',
            'expected_action': 'rag_with_guardrails',
            'can_answer_directly': True,
            'metadata': {'category': '售后'}
        },
        {
            'id': 'stage4_005',
            'query': '再不处理我就投诉，你们人工出来。',
            'history': [],
            'reference_answer': '应触发人工接管。',
            'must_mention': ['人工'],
            'forbidden_patterns': [],
            'expected_route': 'complaint_handoff',
            'expected_action': 'handoff',
            'can_answer_directly': False,
            'metadata': {'category': '投诉'}
        },
    ]
    dump_json(rows, 'data/eval/stage4_eval_set.json')
    print('已写入 data/eval/stage4_eval_set.json')


if __name__ == '__main__':
    main()
