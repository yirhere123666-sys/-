from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

import argparse

from ecom_stage1.io_utils import dump_json, load_records
from ecom_stage1.metrics import squad_like_f1, forbidden_violation, keyword_coverage


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('--eval-set', default='data/eval/stage4_eval_set.json')
    ap.add_argument('--rag-predictions', default='data/eval/stage4_rag_predictions.json')
    ap.add_argument('--agent-predictions', default='data/eval/stage4_predictions.json')
    ap.add_argument('--output', default='data/eval/rag_vs_agent_compare.json')
    return ap.parse_args()


def score(answer: str, ref: str, must_mention: list[str], forbidden_patterns: list[str]) -> float:
    f1 = squad_like_f1(answer, ref)
    cov = keyword_coverage(answer, must_mention)
    viol = 1.0 if forbidden_violation(answer, forbidden_patterns) else 0.0
    return 0.5 * f1 + 0.7 * cov - 0.5 * viol


def main():
    args = parse_args()
    gold = {r['id']: r for r in load_records(args.eval_set)}
    rag = {r['id']: r for r in load_records(args.rag_predictions)}
    agent = {r['id']: r for r in load_records(args.agent_predictions)}
    details = []
    agent_wins = 0
    total = 0
    for sid, g in gold.items():
        if sid not in agent:
            continue
        total += 1
        rag_answer = rag.get(sid, {}).get('answer') or rag.get(sid, {}).get('prediction', '')
        agent_answer = agent[sid]['answer']
        rag_score = score(rag_answer, g['reference_answer'], g.get('must_mention', []), g.get('forbidden_patterns', []))
        agent_score = score(agent_answer, g['reference_answer'], g.get('must_mention', []), g.get('forbidden_patterns', []))
        winner = 'tie'
        if agent_score > rag_score:
            winner = 'agent'
            agent_wins += 1
        elif rag_score > agent_score:
            winner = 'rag'
        details.append({'id': sid, 'winner': winner, 'rag_score': rag_score, 'agent_score': agent_score})
    summary = {'num_samples': total, 'agent_win_rate': agent_wins / max(1, total)}
    dump_json({'summary': summary, 'details': details}, args.output)
    print(summary)


if __name__ == '__main__':
    main()
