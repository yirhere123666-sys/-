from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

import argparse
from collections import Counter

from ecom_stage1.io_utils import dump_json, load_records
from ecom_stage1.metrics import squad_like_f1, keyword_coverage, forbidden_violation, heuristic_hallucination


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('--eval-set', default='data/eval/stage4_eval_set.json')
    ap.add_argument('--predictions', default='data/eval/stage4_predictions.json')
    ap.add_argument('--output', default='data/eval/stage4_eval_summary.json')
    return ap.parse_args()


def main():
    args = parse_args()
    gold = {r['id']: r for r in load_records(args.eval_set)}
    preds = load_records(args.predictions)
    route_correct = 0
    action_correct = 0
    f1s = []
    coverage = []
    forbidden = []
    halluc = []
    counts = Counter()
    details = []
    for row in preds:
        g = gold[row['id']]
        answer = row['answer']
        route_name = row['route']['route_name']
        action = row['rule_decision']['action']
        route_correct += int(route_name == g.get('expected_route'))
        action_correct += int(action == g.get('expected_action'))
        f1 = squad_like_f1(answer, g['reference_answer'])
        cov = keyword_coverage(answer, g.get('must_mention', []))
        fb = forbidden_violation(answer, g.get('forbidden_patterns', []))
        hl = heuristic_hallucination(answer, g['reference_answer'], g.get('forbidden_patterns', []))
        f1s.append(f1)
        coverage.append(cov)
        forbidden.append(int(fb))
        halluc.append(int(hl))
        counts[action] += 1
        details.append({
            'id': row['id'],
            'route_name': route_name,
            'expected_route': g.get('expected_route'),
            'action': action,
            'expected_action': g.get('expected_action'),
            'f1': f1,
            'keyword_coverage': cov,
            'forbidden_violation': fb,
            'hallucination': hl,
        })
    n = max(1, len(preds))
    summary = {
        'num_samples': len(preds),
        'route_accuracy': route_correct / n,
        'action_accuracy': action_correct / n,
        'avg_f1': sum(f1s) / n,
        'avg_keyword_coverage': sum(coverage) / n,
        'forbidden_violation_rate': sum(forbidden) / n,
        'hallucination_rate': sum(halluc) / n,
        'action_distribution': dict(counts),
    }
    dump_json({'summary': summary, 'details': details}, args.output)
    print(summary)


if __name__ == '__main__':
    main()
