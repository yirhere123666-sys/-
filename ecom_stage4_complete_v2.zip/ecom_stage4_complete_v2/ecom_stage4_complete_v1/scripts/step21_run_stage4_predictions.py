from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

import argparse
import json
from pathlib import Path

from ecom_stage1.io_utils import dump_json, load_records
from ecom_stage1.agent.pipeline import Stage4AgentPipeline


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('--eval-set', default='data/eval/stage4_eval_set.json')
    ap.add_argument('--index-dir', default='data/indexes/rag_stage3')
    ap.add_argument('--rag-system-prompt', default='prompts/rag_system_prompt.txt')
    ap.add_argument('--agent-system-prompt', default='prompts/agent_system_prompt.txt')
    ap.add_argument('--api-data-dir', default='data/apis')
    ap.add_argument('--backend', default='extractive', choices=['extractive', 'hf', 'vllm'])
    ap.add_argument('--output', default='data/eval/stage4_predictions.json')
    return ap.parse_args()


def main():
    args = parse_args()
    pipeline = Stage4AgentPipeline(
        rag_index_dir=args.index_dir,
        rag_system_prompt_path=args.rag_system_prompt,
        stage4_system_prompt_path=args.agent_system_prompt,
        api_data_dir=args.api_data_dir,
        generator_backend=args.backend,
    )
    rows = load_records(args.eval_set)
    outputs = []
    for row in rows:
        pred = pipeline.answer(sample_id=row['id'], query=row['query'], history=row.get('history', []))
        outputs.append(pred.to_dict())
    dump_json(outputs, args.output)
    print(f'已写入 {args.output}，共 {len(outputs)} 条')


if __name__ == '__main__':
    main()
