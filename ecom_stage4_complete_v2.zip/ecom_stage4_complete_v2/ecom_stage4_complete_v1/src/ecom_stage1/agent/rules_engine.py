from __future__ import annotations

from typing import Dict, List

from .schemas import RouteDecision, RuleDecision, ToolResult


class RulesEngine:
    def apply(self, query: str, route: RouteDecision, tool_results: List[ToolResult]) -> RuleDecision:
        lowered = query.lower()
        reasons: List[str] = []
        by_name = {t.name: t for t in tool_results}

        if route.route_type == 'handoff':
            return RuleDecision(action='handoff', compliant=True, reasons=route.reasons, response_override='您好，这边为避免影响处理效率，已为您转接人工客服进一步跟进。')

        if route.route_name == 'cancel_order':
            order = by_name.get('get_order_status')
            if not order or not order.success or not order.payload.get('found'):
                return RuleDecision(action='clarify', compliant=True, reasons=['取消订单需要先核验订单信息'], response_override='您好，麻烦您提供订单号，这边先帮您核验当前订单状态后再判断是否还能取消。')
            status = order.payload.get('status', '')
            if status in {'shipped', 'in_transit', 'delivered'}:
                return RuleDecision(action='deny', compliant=True, reasons=[f'订单状态为{status}，不能直接取消'], response_override='您好，当前订单已进入发货流程，无法直接取消。若商品送达后仍需处理，可按退换货规则申请售后。')
            return RuleDecision(action='allow', compliant=True, reasons=['订单尚未发货，可继续处理取消'])

        if route.route_name == 'order_or_logistics_query':
            if not tool_results:
                return RuleDecision(action='clarify', compliant=True, reasons=['动态状态查询缺少订单号或物流单号'], response_override='您好，这类问题需要先核验订单号或物流单号，麻烦您补充后我再帮您查询。')
            if any(t.success and t.payload.get('found') for t in tool_results):
                return RuleDecision(action='allow', compliant=True, reasons=['动态状态可通过API确认'])
            return RuleDecision(action='clarify', compliant=True, reasons=['API 未找到对应订单/物流信息'], response_override='您好，这边暂未查到对应订单或物流信息，麻烦您核对订单号/物流单号后再试一次。')

        if route.route_name == 'refund_or_aftersale':
            risky_words = ['直接退款', '全额赔付', '马上退款', '立刻赔偿']
            if any(w in query for w in risky_words):
                reasons.append('检测到高风险赔付诉求')
            if route.extracted_entities.get('order_ids'):
                order = by_name.get('get_order_status')
                if order and order.success and order.payload.get('found'):
                    return RuleDecision(action='tool_then_rag', compliant=True, reasons=['已核验订单，可结合规则回复'])
            return RuleDecision(action='rag_with_guardrails', compliant=True, reasons=reasons or ['售后规则可先通过知识库解释，涉及退款结论需核验'])

        if route.route_name == 'account_help':
            return RuleDecision(action='rag_with_guardrails', compliant=True, reasons=['账号问题需强调身份验证，不得越权重置'])

        if route.route_type == 'rag':
            return RuleDecision(action='allow', compliant=True, reasons=['静态知识问题可直接走RAG'])

        if route.route_type == 'mixed':
            return RuleDecision(action='tool_then_rag', compliant=True, reasons=['先用工具拿动态状态，再用规则/RAG组织答复'])

        return RuleDecision(action='allow', compliant=True, reasons=['默认允许'])
