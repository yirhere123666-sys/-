from __future__ import annotations

from typing import Dict, List

from .entity_extractor import EntityExtractor
from .schemas import RouteDecision, ToolCall


class IntentRouter:
    def __init__(self):
        self.extractor = EntityExtractor()

    def route(self, query: str, history: List[Dict[str, str]] | None = None) -> RouteDecision:
        history = history or []
        entities = self.extractor.extract(query)
        reasons: List[str] = []

        if entities['is_angry']:
            return RouteDecision(
                route_name='complaint_handoff',
                route_type='handoff',
                confidence=0.95,
                reasons=['检测到强投诉/人工诉求'],
                extracted_entities=entities,
            )

        if entities['has_logistics_keyword'] or entities['tracking_ids']:
            reasons.append('命中物流/发货关键词')
            tool_calls = []
            if entities['order_ids']:
                tool_calls.append(ToolCall(name='get_order_status', args={'order_id': entities['order_ids'][0]}))
            if entities['tracking_ids']:
                tool_calls.append(ToolCall(name='get_logistics_status', args={'tracking_id': entities['tracking_ids'][0]}))
            return RouteDecision('order_or_logistics_query', 'api', 0.92, reasons, entities, tool_calls)

        if entities['has_cancel_keyword']:
            reasons.append('命中取消订单意图')
            tool_calls = []
            if entities['order_ids']:
                tool_calls.append(ToolCall(name='get_order_status', args={'order_id': entities['order_ids'][0]}))
            return RouteDecision('cancel_order', 'mixed', 0.9, reasons, entities, tool_calls, {'category': '取消订单'})

        if entities['has_refund_keyword']:
            reasons.append('命中退款/售后意图')
            tool_calls = []
            if entities['order_ids']:
                tool_calls.append(ToolCall(name='get_order_status', args={'order_id': entities['order_ids'][0]}))
            return RouteDecision('refund_or_aftersale', 'mixed', 0.88, reasons, entities, tool_calls, {'category': '退换货'})

        if entities['has_invoice_keyword']:
            return RouteDecision('invoice_policy', 'rag', 0.86, ['命中发票/开票关键词'], entities, [], {'category': '发票'})

        if entities['has_product_keyword'] or entities['sku_ids']:
            filters = {'category': '商品咨询'}
            tool_calls = []
            if entities['sku_ids']:
                filters['sku'] = entities['sku_ids'][0]
                tool_calls.append(ToolCall(name='get_product_info', args={'sku': entities['sku_ids'][0]}))
                return RouteDecision('product_info', 'mixed', 0.86, ['命中商品咨询关键词且抽取到SKU'], entities, tool_calls, filters)
            return RouteDecision('product_info', 'rag', 0.84, ['命中商品咨询关键词'], entities, [], filters)

        if entities['has_account_keyword']:
            return RouteDecision('account_help', 'mixed', 0.82, ['命中账号/登录关键词'], entities, [ToolCall(name='get_account_policy', args={})], {'category': '账号帮助'})

        return RouteDecision('policy_default', 'rag', 0.6, ['默认回退到知识检索'], entities, [], {})
