from __future__ import annotations

from pathlib import Path
from typing import Dict, Iterable, List

from .api_clients import LogisticsAPI, OrderAPI, PolicyAPI, ProductAPI
from .schemas import ToolCall, ToolResult


class ToolExecutor:
    def __init__(self, data_dir: str | Path):
        data_dir = Path(data_dir)
        self.order_api = OrderAPI(data_dir / 'orders.json')
        self.logistics_api = LogisticsAPI(data_dir / 'logistics.json')
        self.product_api = ProductAPI(data_dir / 'products.json')
        self.policy_api = PolicyAPI(data_dir / 'policies.json')

    def execute(self, tool_calls: Iterable[ToolCall]) -> List[ToolResult]:
        results: List[ToolResult] = []
        for call in tool_calls:
            try:
                payload = self._dispatch(call.name, call.args)
                results.append(ToolResult(name=call.name, success=True, payload=payload))
            except Exception as e:
                results.append(ToolResult(name=call.name, success=False, error=str(e)))
        return results

    def _dispatch(self, name: str, args: Dict[str, str]):
        if name == 'get_order_status':
            return self.order_api.get_order_status(args['order_id'])
        if name == 'get_logistics_status':
            return self.logistics_api.get_logistics_status(args['tracking_id'])
        if name == 'get_product_info':
            return self.product_api.get_product_info(args['sku'])
        if name == 'get_policy':
            return self.policy_api.get_policy(args['policy_key'])
        if name == 'get_account_policy':
            return self.policy_api.get_policy('account_help')
        raise ValueError(f'未知工具: {name}')
