from __future__ import annotations

from typing import List

from .schemas import ToolResult


def format_tool_grounded_answer(query: str, tool_results: List[ToolResult], rag_answer: str | None = None) -> str:
    lines: List[str] = []
    for t in tool_results:
        if not t.success:
            continue
        p = t.payload
        if t.name == 'get_order_status' and p.get('found'):
            lines.append(f"订单 {p.get('order_id')} 当前状态为{p.get('status_cn', p.get('status', '未知'))}。")
            if p.get('can_cancel') is not None:
                lines.append('当前可取消。' if p.get('can_cancel') else '当前已不可直接取消。')
        elif t.name == 'get_logistics_status' and p.get('found'):
            lines.append(f"物流单号 {p.get('tracking_id')} 当前状态为{p.get('status_cn', p.get('status', '未知'))}，最近节点：{p.get('last_event', '暂无')}。")
        elif t.name == 'get_product_info' and p.get('found'):
            parts = []
            if p.get('title'):
                parts.append(p['title'])
            if p.get('features'):
                parts.append('；'.join(p['features']))
            if parts:
                lines.append('商品信息：' + '；'.join(parts) + '。')
    body = ''.join(lines)
    if rag_answer:
        body = body + ('\n' if body else '') + rag_answer
    if not body:
        body = '当前需要进一步核验订单、物流或商品信息后才能继续处理。'
    return body
