from __future__ import annotations

import re
from typing import Any, Dict, List


class EntityExtractor:
    ORDER_ID_PATTERNS = [r'订单(?:号|編號|编号)?[:：]?\s*([A-Za-z0-9_-]{6,24})', r'(\d{8,18})']
    TRACKING_PATTERNS = [r'(SF\d{9,15}CN)', r'(YT\d{10,16})', r'(ZTO\d{8,18})']
    SKU_PATTERNS = [r'(SKU[-_ ]?[A-Za-z0-9]{3,20})', r'([A-Z]{1,4}\d{2,5}[A-Z0-9]{0,8})']

    def extract(self, text: str) -> Dict[str, Any]:
        order_ids = self._find_patterns(text, self.ORDER_ID_PATTERNS)
        tracking_ids = self._find_patterns(text, self.TRACKING_PATTERNS)
        sku_ids = self._find_patterns(text, self.SKU_PATTERNS)
        entities = {
            'order_ids': self._uniq(order_ids),
            'tracking_ids': self._uniq(tracking_ids),
            'sku_ids': self._uniq(sku_ids),
            'has_refund_keyword': any(k in text for k in ['退款', '退货', '退掉', '退钱', '赔付', '赔偿']),
            'has_logistics_keyword': any(k in text for k in ['物流', '发货', '送达', '派送', '快递', '到哪', '到哪了', '到哪里', '查一下发货', '查下发货', '查物流', '订单状态']),
            'has_cancel_keyword': any(k in text for k in ['取消订单', '取消购买', '取消', '拦截发货']),
            'has_invoice_keyword': any(k in text for k in ['发票', '开票']),
            'has_product_keyword': any(k in text for k in ['参数', '型号', '支持', '兼容', 'NFC', '尺码', '颜色', '容量']),
            'has_account_keyword': any(k in text for k in ['账号', '账户', '密码', '登录', '锁定']),
            'is_angry': any(k in text for k in ['投诉', '差评', '生气', '怒', '再不处理', '人工']),
        }
        return entities

    def _find_patterns(self, text: str, patterns: List[str]) -> List[str]:
        found: List[str] = []
        for p in patterns:
            for m in re.finditer(p, text, re.IGNORECASE):
                g = m.group(1) if m.groups() else m.group(0)
                if g:
                    found.append(g.strip())
        return found

    def _uniq(self, values: List[str]) -> List[str]:
        seen = set()
        out = []
        for v in values:
            if v not in seen:
                seen.add(v)
                out.append(v)
        return out
