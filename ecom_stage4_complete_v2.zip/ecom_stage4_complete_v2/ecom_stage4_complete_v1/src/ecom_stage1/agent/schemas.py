from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class ToolCall:
    name: str
    args: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ToolResult:
    name: str
    success: bool
    payload: Dict[str, Any] = field(default_factory=dict)
    error: str = ''

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class RouteDecision:
    route_name: str
    route_type: str  # rag / api / mixed / handoff / clarify
    confidence: float
    reasons: List[str] = field(default_factory=list)
    extracted_entities: Dict[str, Any] = field(default_factory=dict)
    tool_calls: List[ToolCall] = field(default_factory=list)
    rag_filters: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d['tool_calls'] = [t.to_dict() for t in self.tool_calls]
        return d


@dataclass
class RuleDecision:
    action: str  # allow / deny / handoff / clarify / tool_then_rag
    compliant: bool = True
    reasons: List[str] = field(default_factory=list)
    response_override: Optional[str] = None
    updated_tool_calls: List[ToolCall] = field(default_factory=list)
    updated_rag_filters: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d['updated_tool_calls'] = [t.to_dict() for t in self.updated_tool_calls]
        return d


@dataclass
class Stage4Response:
    id: str
    query: str
    answer: str
    route: RouteDecision
    rule_decision: RuleDecision
    tool_results: List[ToolResult] = field(default_factory=list)
    rag_answer: Optional[str] = None
    rag_context: Optional[str] = None
    citations: List[Dict[str, Any]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'query': self.query,
            'answer': self.answer,
            'route': self.route.to_dict(),
            'rule_decision': self.rule_decision.to_dict(),
            'tool_results': [t.to_dict() for t in self.tool_results],
            'rag_answer': self.rag_answer,
            'rag_context': self.rag_context,
            'citations': self.citations,
            'metadata': self.metadata,
        }
