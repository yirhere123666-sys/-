from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional

from ecom_stage1.io_utils import load_text
from ecom_stage1.rag.pipeline import RAGPipeline

from .intent_router import IntentRouter
from .response_formatter import format_tool_grounded_answer
from .rules_engine import RulesEngine
from .schemas import RuleDecision, Stage4Response
from .tool_executor import ToolExecutor


class Stage4AgentPipeline:
    def __init__(
        self,
        rag_index_dir: str | Path,
        rag_system_prompt_path: str | Path,
        stage4_system_prompt_path: str | Path,
        api_data_dir: str | Path,
        generator_backend: str = 'extractive',
        base_model: str = 'Qwen/Qwen2-7B-Instruct',
        model_path: Optional[str] = None,
        reranker_type: str | None = None,
        reranker_model_name: str | None = None,
    ):
        self.router = IntentRouter()
        self.rules = RulesEngine()
        self.tools = ToolExecutor(api_data_dir)
        self.agent_system_prompt = load_text(stage4_system_prompt_path)
        self.rag = RAGPipeline(
            index_dir=rag_index_dir,
            system_prompt_path=rag_system_prompt_path,
            generator_backend=generator_backend,
            base_model=base_model,
            model_path=model_path,
            reranker_type=reranker_type,
            reranker_model_name=reranker_model_name,
        )

    def answer(self, sample_id: str, query: str, history: Optional[List[Dict[str, str]]] = None) -> Stage4Response:
        history = history or []
        route = self.router.route(query, history)
        tool_results = self.tools.execute(route.tool_calls)
        rule_decision = self.rules.apply(query, route, tool_results)

        if rule_decision.response_override:
            return Stage4Response(
                id=sample_id,
                query=query,
                answer=rule_decision.response_override,
                route=route,
                rule_decision=rule_decision,
                tool_results=tool_results,
                metadata={'pipeline_stage': 'stage4'},
            )

        rag_answer = None
        rag_context = None
        citations = []
        if rule_decision.action in {'allow', 'rag_with_guardrails', 'tool_then_rag'} and route.route_type in {'rag', 'mixed'}:
            pred = self.rag.answer(sample_id=sample_id, query=query, history=history, filters=route.rag_filters or None, top_k=5)
            rag_answer = pred.answer
            rag_context = pred.context
            citations = pred.citations

        if route.route_type == 'api' and rule_decision.action == 'allow':
            answer = format_tool_grounded_answer(query, tool_results)
        elif rule_decision.action == 'tool_then_rag':
            answer = format_tool_grounded_answer(query, tool_results, rag_answer=rag_answer)
        elif rag_answer:
            answer = rag_answer
        else:
            answer = '当前信息不足，建议先补充订单号、物流单号或商品信息后再继续处理。'

        return Stage4Response(
            id=sample_id,
            query=query,
            answer=answer,
            route=route,
            rule_decision=rule_decision,
            tool_results=tool_results,
            rag_answer=rag_answer,
            rag_context=rag_context,
            citations=citations,
            metadata={'pipeline_stage': 'stage4'},
        )
