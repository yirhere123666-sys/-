# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from pathlib import Path
import sys,os
sys.path.append(str(Path(__file__).parent.parent))

from utils.profiler.profile import DistProfilerExtension, ProfilerConfig


from utils.profiler.profile import DistProfiler, mark_annotate, mark_end_range, mark_start_range


__all__ = [
    "mark_start_range",
    "mark_end_range",
    "mark_annotate",
    "DistProfiler",
    "DistProfilerExtension",
    "ProfilerConfig",
    "gspo_utils",
]

# Import gspo utilities for easy access
from utils import gspo_utils