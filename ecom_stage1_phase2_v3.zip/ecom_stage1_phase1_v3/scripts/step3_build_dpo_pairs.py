#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ecom_stage1.dpo_builder import build_one_dpo_sample
from ecom_stage1.io_utils import dump_json, load_records


def main() -> None:
    parser = argparse.ArgumentParser(description="构造 DPO chosen/rejected 偏好对")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    sft_rows = load_records(args.input)
    dpo_rows = []
    for row in sft_rows:
        sample = build_one_dpo_sample(row)
        if sample is not None:
            dpo_rows.append(sample.to_dict())

    dump_json(dpo_rows, args.output)
    print(f"DPO 数据构造完成：{len(dpo_rows)} 条 -> {args.output}")


if __name__ == "__main__":
    main()
