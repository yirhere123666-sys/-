#!/usr/bin/env python
from __future__ import annotations

import argparse
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser(description="基于 lf_ready 数据快速生成 LLaMA-Factory bundle")
    parser.add_argument("--lf-ready-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    lf_ready = Path(args.lf_ready_dir)
    out_dir = Path(args.output_dir)
    if not lf_ready.exists():
        raise FileNotFoundError(f"lf_ready 目录不存在: {lf_ready}")

    (out_dir / "data").mkdir(parents=True, exist_ok=True)
    (out_dir / "configs").mkdir(parents=True, exist_ok=True)
    (out_dir / "scripts").mkdir(parents=True, exist_ok=True)

    for name in ["sft_train.json", "sft_valid.json", "dpo_train.json", "dpo_valid.json", "eval_stage1.json", "dataset_info.ecom_stage1.json"]:
        src = lf_ready / name
        if src.exists():
            target_name = "dataset_info.json" if name == "dataset_info.ecom_stage1.json" else name
            shutil.copy2(src, out_dir / "data" / target_name)

    for cfg in ["qwen2_7b_qlora_sft.yaml", "qwen2_7b_qlora_dpo.yaml"]:
        shutil.copy2(ROOT / "configs" / cfg, out_dir / "configs" / cfg)

    (out_dir / "scripts" / "run_sft.sh").write_text("#!/usr/bin/env bash\nset -e\nllamafactory-cli train configs/qwen2_7b_qlora_sft.yaml\n", encoding="utf-8")
    (out_dir / "scripts" / "run_dpo.sh").write_text("#!/usr/bin/env bash\nset -e\nllamafactory-cli train configs/qwen2_7b_qlora_dpo.yaml\n", encoding="utf-8")

    (out_dir / "README.bundle.txt").write_text(
        "1. 将 data/ 里的 json 和 dataset_info.json 复制到 LLaMA-Factory/data/\n"
        "2. 在当前 bundle 目录下执行 scripts/run_sft.sh 或 scripts/run_dpo.sh\n"
        "3. 如需修改模型名、输出目录、显存配置，请编辑 configs/*.yaml\n",
        encoding="utf-8",
    )
    print(f"bundle 已生成 -> {out_dir}")


if __name__ == "__main__":
    main()
