#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ecom_stage1.eval_builder import balanced_sample, build_eval_sample, stratified_eval_sample
from ecom_stage1.io_utils import dump_json, load_records


def main() -> None:
    parser = argparse.ArgumentParser(description="从 clean 数据构建第一阶段评测集")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--per-category", type=int, default=40, help="legacy 模式下每类抽样数量")
    parser.add_argument("--target-size", type=int, default=600, help="stratified 模式的总评测集大小")
    parser.add_argument("--min-per-category", type=int, default=80)
    parser.add_argument("--mode", choices=["legacy", "stratified"], default="stratified")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    rows = load_records(args.input)
    if args.mode == "legacy":
        sampled = balanced_sample(rows, per_category=args.per_category)
    else:
        sampled = stratified_eval_sample(rows, target_size=args.target_size, min_per_category=args.min_per_category, seed=args.seed)

    eval_rows = [build_eval_sample(row).to_dict() for row in sampled]
    dump_json(eval_rows, args.output)
    print(f"评测集构建完成：{len(eval_rows)} 条 -> {args.output}")


if __name__ == "__main__":
    main()
