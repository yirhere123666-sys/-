#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ecom_stage1.io_utils import dump_json, load_records, load_text
from ecom_stage1.judge import OpenAICompatibleJudge
from ecom_stage1.metrics import (
    binary_accuracy_from_rules,
    forbidden_violation,
    heuristic_hallucination,
    is_invalid_refusal,
    keyword_coverage,
    squad_like_f1,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="第一阶段离线评测")
    parser.add_argument("--eval-set", required=True)
    parser.add_argument("--predictions", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--use-llm-judge", action="store_true")
    parser.add_argument("--judge-model", default="gpt-4.1-mini")
    parser.add_argument("--judge-prompt", default=str(ROOT / "prompts" / "eval_judge_prompt.txt"))
    args = parser.parse_args()

    eval_rows = {row["id"]: row for row in load_records(args.eval_set)}
    pred_rows = load_records(args.predictions)

    judge = None
    system_prompt = None
    if args.use_llm_judge:
        system_prompt = load_text(args.judge_prompt)
        judge = OpenAICompatibleJudge(model=args.judge_model)

    details, correct_list, f1_list, compliance_list, invalid_refusal_list, hallucination_list = [], [], [], [], [], []

    for pred in pred_rows:
        item = eval_rows[pred["id"]]
        prediction = pred["prediction"]
        reference = item["reference_answer"]
        must_mention = item.get("must_mention", [])
        forbidden_patterns = item.get("forbidden_patterns", [])
        can_answer_directly = bool(item.get("can_answer_directly", True))

        token_f1 = squad_like_f1(prediction, reference)
        kw_coverage = keyword_coverage(prediction, must_mention)
        rule_acc = binary_accuracy_from_rules(prediction, reference, must_mention, forbidden_patterns)
        violation = forbidden_violation(prediction, forbidden_patterns)
        invalid_refusal = is_invalid_refusal(prediction, can_answer_directly)
        hallucination = heuristic_hallucination(prediction, reference, forbidden_patterns)

        judged = None
        if judge is not None:
            user_prompt = json.dumps({
                "category": item.get("category"),
                "query": item.get("query"),
                "reference_answer": reference,
                "prediction": prediction,
            }, ensure_ascii=False, indent=2)
            judged = judge.judge_json(system_prompt=system_prompt, user_prompt=user_prompt)

        correct = int(judged["correct"]) if judged is not None else rule_acc
        compliant = int(judged["compliant"]) if judged is not None else int(not violation)
        invalid_ref = int(judged["invalid_refusal"]) if judged is not None else int(invalid_refusal)
        halluc = int(judged["hallucination"]) if judged is not None else int(hallucination)

        correct_list.append(correct)
        f1_list.append(token_f1)
        compliance_list.append(compliant)
        invalid_refusal_list.append(invalid_ref)
        hallucination_list.append(halluc)

        details.append({
            "id": pred["id"],
            "category": item.get("category"),
            "accuracy": correct,
            "token_f1": round(token_f1, 4),
            "keyword_coverage": round(kw_coverage, 4),
            "policy_compliant": compliant,
            "invalid_refusal": invalid_ref,
            "hallucination": halluc,
            "prediction": prediction,
            "reference_answer": reference,
            "judge": judged,
        })

    summary = {
        "accuracy": round(sum(correct_list) / len(correct_list), 4) if correct_list else 0.0,
        "f1": round(sum(f1_list) / len(f1_list), 4) if f1_list else 0.0,
        "policy_compliance_rate": round(sum(compliance_list) / len(compliance_list), 4) if compliance_list else 0.0,
        "invalid_refusal_rate": round(sum(invalid_refusal_list) / len(invalid_refusal_list), 4) if invalid_refusal_list else 0.0,
        "hallucination_rate": round(sum(hallucination_list) / len(hallucination_list), 4) if hallucination_list else 0.0,
        "num_samples": len(details),
    }
    dump_json({"summary": summary, "details": details}, args.output)
    print(f"评测完成 -> {args.output}")
    print(summary)


if __name__ == "__main__":
    main()
