#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR=$(cd "$(dirname "$0")/.." && pwd)
DATA_DIR=${1:-$ROOT_DIR/data}
PARQUET_PATH=${2:-/mnt/data/0000.parquet}
CSV_PATH=${3:-/mnt/data/english_support_dataset.csv}
CSV_MAX=${CSV_MAX:-50000}
PARQUET_MAX=${PARQUET_MAX:-1000}
STYLE_LOCALE=${STYLE_LOCALE:-zh_ecom}
EVAL_TARGET_SIZE=${EVAL_TARGET_SIZE:-600}
EVAL_MIN_PER_CATEGORY=${EVAL_MIN_PER_CATEGORY:-80}
LF_DATA_DIR=${LF_DATA_DIR:-}
LF_ROOT=${LF_ROOT:-}

mkdir -p "$DATA_DIR/intermediate" "$DATA_DIR/processed" "$DATA_DIR/eval" "$DATA_DIR/lf_ready" "$ROOT_DIR/outputs"

python "$ROOT_DIR/scripts/step0b_normalize_parquet.py" \
  --input "$PARQUET_PATH" \
  --output "$DATA_DIR/intermediate/parquet_normalized.jsonl" \
  --ecom-only \
  --max-samples "$PARQUET_MAX"

python "$ROOT_DIR/scripts/step0c_normalize_csv.py" \
  --input "$CSV_PATH" \
  --output "$DATA_DIR/intermediate/csv_normalized.jsonl" \
  --max-samples "$CSV_MAX"

python "$ROOT_DIR/scripts/step0d_merge_normalized.py" \
  --inputs "$DATA_DIR/intermediate/parquet_normalized.jsonl" "$DATA_DIR/intermediate/csv_normalized.jsonl" \
  --output "$DATA_DIR/intermediate/merged_normalized.jsonl"

python "$ROOT_DIR/scripts/step1_clean_dedup.py" \
  --input "$DATA_DIR/intermediate/merged_normalized.jsonl" \
  --output "$DATA_DIR/processed/cleaned.json" \
  --threshold 0.88

python "$ROOT_DIR/scripts/step2_build_sft_dataset.py" \
  --input "$DATA_DIR/processed/cleaned.json" \
  --output "$DATA_DIR/processed/sft_full.json" \
  --system-prompt "$ROOT_DIR/prompts/system_prompt.txt" \
  --style-locale "$STYLE_LOCALE"

python "$ROOT_DIR/scripts/step3_build_dpo_pairs.py" \
  --input "$DATA_DIR/processed/sft_full.json" \
  --output "$DATA_DIR/processed/dpo_full.json"

python "$ROOT_DIR/scripts/step4_build_eval_set.py" \
  --input "$DATA_DIR/processed/cleaned.json" \
  --output "$DATA_DIR/eval/eval_stage1.json" \
  --mode stratified \
  --target-size "$EVAL_TARGET_SIZE" \
  --min-per-category "$EVAL_MIN_PER_CATEGORY"

SPLIT_ARGS=(
  --sft-input "$DATA_DIR/processed/sft_full.json"
  --dpo-input "$DATA_DIR/processed/dpo_full.json"
  --eval-input "$DATA_DIR/eval/eval_stage1.json"
  --out-dir "$DATA_DIR/lf_ready"
)
if [[ -n "$LF_DATA_DIR" ]]; then
  SPLIT_ARGS+=(--llamafactory-data-dir "$LF_DATA_DIR")
fi
if [[ -n "$LF_ROOT" ]]; then
  SPLIT_ARGS+=(--llamafactory-root "$LF_ROOT")
fi
python "$ROOT_DIR/scripts/step5_split_register.py" "${SPLIT_ARGS[@]}"

python "$ROOT_DIR/scripts/step6_quality_report.py" \
  --input "$DATA_DIR/processed/sft_full.json" \
  --query-key instruction \
  --answer-key output \
  --output "$DATA_DIR/processed/stage1_quality_report.json"

printf '\n阶段一数据工程完成。输出目录: %s\n' "$DATA_DIR"
printf '当前风格映射: %s\n' "$STYLE_LOCALE"
printf '评测集目标大小: %s\n' "$EVAL_TARGET_SIZE"
