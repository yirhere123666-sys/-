#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ecom_stage1.dedup import deduplicate_records
from ecom_stage1.masking import apply_full_mask
from ecom_stage1.io_utils import dump_json, load_records
from ecom_stage1.schemas import NormalizedRecord


def _filter_and_mask(rows):
    out = []
    for row in rows:
        q = apply_full_mask((row.get("user_query") or "").strip())
        a = apply_full_mask((row.get("assistant_reply") or "").strip())
        if len(q) < 3 or len(a) < 3:
            continue
        row = dict(row)
        row["user_query"] = q
        row["assistant_reply"] = a
        row["history"] = [
            {"role": x.get("role", "user"), "content": apply_full_mask(x.get("content", ""))}
            for x in row.get("history", [])
            if x.get("content")
        ]
        out.append(row)
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description="清洗、脱敏、联合近似去重")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--threshold", type=float, default=0.88)
    parser.add_argument("--num-perm", type=int, default=128)
    args = parser.parse_args()

    records = _filter_and_mask(load_records(args.input))
    objects = [NormalizedRecord(**row) for row in records]
    deduped, stats = deduplicate_records(objects, threshold=args.threshold, num_perm=args.num_perm)
    dump_json(deduped, args.output)
    print(f"去重完成 -> {args.output}")
    print(stats)


if __name__ == "__main__":
    main()
