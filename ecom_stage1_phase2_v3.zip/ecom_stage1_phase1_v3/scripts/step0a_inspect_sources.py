#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ecom_stage1.io_utils import load_records


def main() -> None:
    parser = argparse.ArgumentParser(description="查看原始数据字段与样例")
    parser.add_argument("--input", required=True)
    parser.add_argument("--head", type=int, default=3)
    args = parser.parse_args()

    rows = load_records(args.input, max_rows=args.head)
    print(f"预览记录数: {len(rows)}")
    if not rows:
        return
    print(f"字段: {list(rows[0].keys())}")
    for i, row in enumerate(rows):
        print(f"\n--- sample #{i} ---")
        print(row)


if __name__ == "__main__":
    main()
