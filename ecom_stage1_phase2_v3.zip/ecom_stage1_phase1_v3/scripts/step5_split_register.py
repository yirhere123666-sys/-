#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import random
import shutil
import sys
from pathlib import Path
from typing import List, Tuple

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ecom_stage1.io_utils import dump_json, load_records, load_text


SFT_COLUMNS = {"prompt": "instruction", "query": "input", "response": "output", "system": "system"}
DPO_COLUMNS = {"prompt": "instruction", "query": "input", "chosen": "chosen", "rejected": "rejected", "system": "system"}


def split_rows(rows: List[dict], valid_ratio: float, seed: int = 42) -> Tuple[List[dict], List[dict]]:
    rows = rows[:]
    random.Random(seed).shuffle(rows)
    split = int(len(rows) * (1 - valid_ratio))
    return rows[:split], rows[split:]



def render_training_launcher(config_rel_path: str) -> str:
    return f"#!/usr/bin/env bash\nset -e\nllamafactory-cli train {config_rel_path}\n"



def main() -> None:
    parser = argparse.ArgumentParser(description="切分数据集并生成 LLaMA-Factory dataset_info")
    parser.add_argument("--sft-input", required=True)
    parser.add_argument("--dpo-input", required=True)
    parser.add_argument("--eval-input", required=True)
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--valid-ratio", type=float, default=0.1)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--llamafactory-data-dir", default="")
    parser.add_argument("--llamafactory-root", default="", help="可选：若提供，将自动生成可直接放入 LLaMA-Factory 的 bundle")
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    sft_rows = load_records(args.sft_input)
    dpo_rows = load_records(args.dpo_input)
    eval_rows = load_records(args.eval_input)

    sft_train, sft_valid = split_rows(sft_rows, args.valid_ratio, seed=args.seed)
    dpo_train, dpo_valid = split_rows(dpo_rows, args.valid_ratio, seed=args.seed)

    dump_json(sft_train, out_dir / "sft_train.json")
    dump_json(sft_valid, out_dir / "sft_valid.json")
    dump_json(dpo_train, out_dir / "dpo_train.json")
    dump_json(dpo_valid, out_dir / "dpo_valid.json")
    dump_json(eval_rows, out_dir / "eval_stage1.json")

    dataset_info = {
        "ecom_sft_train": {"file_name": "sft_train.json", "columns": SFT_COLUMNS},
        "ecom_sft_valid": {"file_name": "sft_valid.json", "columns": SFT_COLUMNS},
        "ecom_dpo_train": {"file_name": "dpo_train.json", "ranking": True, "columns": DPO_COLUMNS},
        "ecom_dpo_valid": {"file_name": "dpo_valid.json", "ranking": True, "columns": DPO_COLUMNS},
    }

    dataset_info_path = out_dir / "dataset_info.ecom_stage1.json"
    dump_json(dataset_info, dataset_info_path)
    print(f"已生成数据切分与注册片段 -> {dataset_info_path}")

    if args.llamafactory_data_dir:
        lf_dir = Path(args.llamafactory_data_dir)
        lf_dir.mkdir(parents=True, exist_ok=True)
        for name in ["sft_train.json", "sft_valid.json", "dpo_train.json", "dpo_valid.json", "eval_stage1.json"]:
            shutil.copy2(out_dir / name, lf_dir / name)

        target_info = lf_dir / "dataset_info.json"
        merged = {}
        if target_info.exists():
            with target_info.open("r", encoding="utf-8") as f:
                merged = json.load(f)
        merged.update(dataset_info)
        with target_info.open("w", encoding="utf-8") as f:
            json.dump(merged, f, ensure_ascii=False, indent=2)
        print(f"已自动同步到 LLaMA-Factory data 目录: {lf_dir}")

    if args.llamafactory_root:
        lf_root = Path(args.llamafactory_root)
        bundle_dir = out_dir / "llamafactory_bundle"
        (bundle_dir / "data").mkdir(parents=True, exist_ok=True)
        (bundle_dir / "configs").mkdir(parents=True, exist_ok=True)
        (bundle_dir / "scripts").mkdir(parents=True, exist_ok=True)

        for name in ["sft_train.json", "sft_valid.json", "dpo_train.json", "dpo_valid.json", "eval_stage1.json"]:
            shutil.copy2(out_dir / name, bundle_dir / "data" / name)
        dump_json(dataset_info, bundle_dir / "data" / "dataset_info.json")

        # 复制并渲染训练配置
        sft_cfg = ROOT / "configs" / "qwen2_7b_qlora_sft.yaml"
        dpo_cfg = ROOT / "configs" / "qwen2_7b_qlora_dpo.yaml"
        shutil.copy2(sft_cfg, bundle_dir / "configs" / sft_cfg.name)
        shutil.copy2(dpo_cfg, bundle_dir / "configs" / dpo_cfg.name)

        (bundle_dir / "scripts" / "run_sft.sh").write_text(render_training_launcher("configs/qwen2_7b_qlora_sft.yaml"), encoding="utf-8")
        (bundle_dir / "scripts" / "run_dpo.sh").write_text(render_training_launcher("configs/qwen2_7b_qlora_dpo.yaml"), encoding="utf-8")
        (bundle_dir / "README.bundle.txt").write_text(
            "将 bundle/data 下的 json 与 dataset_info.json 复制到 LLaMA-Factory/data/；\n"
            "再将 bundle/configs 下的 yaml 放到任意目录，用 scripts/run_sft.sh 和 scripts/run_dpo.sh 启动。\n"
            f"LLaMA-Factory 根目录参考：{lf_root}\n",
            encoding="utf-8",
        )
        print(f"已生成一键对接 bundle -> {bundle_dir}")


if __name__ == "__main__":
    main()
