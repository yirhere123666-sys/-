#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ecom_stage1.io_utils import dump_json, load_records, load_text
from ecom_stage1.metrics import binary_accuracy_from_rules, forbidden_violation, is_invalid_refusal, squad_like_f1
from ecom_stage1.judge import OpenAICompatibleJudge


def score_rule(item: dict, prediction: str) -> tuple[int, float, int, int]:
    acc = binary_accuracy_from_rules(prediction, item["reference_answer"], item.get("must_mention", []), item.get("forbidden_patterns", []))
    f1 = squad_like_f1(prediction, item["reference_answer"])
    compliant = int(not forbidden_violation(prediction, item.get("forbidden_patterns", [])))
    invalid_refusal = int(is_invalid_refusal(prediction, bool(item.get("can_answer_directly", True))))
    return acc, f1, compliant, invalid_refusal


def main() -> None:
    parser = argparse.ArgumentParser(description="比较 SFT 与 DPO 的离线预测")
    parser.add_argument("--eval-set", required=True)
    parser.add_argument("--pred-sft", required=True)
    parser.add_argument("--pred-dpo", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--use-llm-judge", action="store_true")
    parser.add_argument("--judge-model", default="gpt-4.1-mini")
    parser.add_argument("--judge-prompt", default=str(ROOT / "prompts" / "dpo_compare_judge_prompt.txt"))
    args = parser.parse_args()

    eval_rows = {row["id"]: row for row in load_records(args.eval_set)}
    sft_rows = {row["id"]: row for row in load_records(args.pred_sft)}
    dpo_rows = {row["id"]: row for row in load_records(args.pred_dpo)}

    judge = None
    judge_prompt = None
    if args.use_llm_judge:
        judge_prompt = load_text(args.judge_prompt)
        judge = OpenAICompatibleJudge(model=args.judge_model)

    details = []
    dpo_wins = 0
    total = 0

    for sample_id, item in eval_rows.items():
        if sample_id not in sft_rows or sample_id not in dpo_rows:
            continue
        total += 1
        sft_pred = sft_rows[sample_id]["prediction"]
        dpo_pred = dpo_rows[sample_id]["prediction"]

        winner = "Tie"
        if judge is not None:
            user_prompt = json.dumps({
                "query": item["query"],
                "reference_answer": item["reference_answer"],
                "A": sft_pred,
                "B": dpo_pred,
            }, ensure_ascii=False, indent=2)
            resp = judge.judge_json(system_prompt=judge_prompt, user_prompt=user_prompt)
            winner = resp.get("winner", "Tie")
        else:
            sft_score = score_rule(item, sft_pred)
            dpo_score = score_rule(item, dpo_pred)
            if dpo_score > sft_score:
                winner = "B"
            elif dpo_score < sft_score:
                winner = "A"

        if winner == "B":
            dpo_wins += 1

        details.append({"id": sample_id, "winner": winner, "sft_prediction": sft_pred, "dpo_prediction": dpo_pred})

    summary = {"dpo_win_rate": round(dpo_wins / total, 4) if total else 0.0, "num_samples": total}
    dump_json({"summary": summary, "details": details}, args.output)
    print(summary)


if __name__ == "__main__":
    main()
