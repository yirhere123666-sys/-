#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ecom_stage1.cn_style import apply_zh_ecom_style
from ecom_stage1.io_utils import dump_json, load_records, load_text
from ecom_stage1.prompts import build_input_field, build_system_prompt
from ecom_stage1.schemas import NormalizedRecord, SFTSample


def main() -> None:
    parser = argparse.ArgumentParser(description="构建 SFT 指令数据")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--system-prompt", required=True)
    parser.add_argument("--max-history-turns", type=int, default=3)
    parser.add_argument("--style-locale", choices=["origin", "zh_ecom"], default="origin", help="是否将语料映射为中文电商客服风格")
    args = parser.parse_args()

    base_system = load_text(args.system_prompt)
    records = [NormalizedRecord(**row) for row in load_records(args.input)]

    sft_rows = []
    for record in records:
        record_meta = dict(record.metadata or {})
        instruction = record.user_query
        output = record.assistant_reply

        if args.style_locale == "zh_ecom":
            instruction, output, record_meta = apply_zh_ecom_style(record)

        style_record = NormalizedRecord(
            id=record.id,
            source=record.source,
            category=record.category,
            user_query=instruction,
            assistant_reply=output,
            history=record.history,
            metadata=record_meta,
        )
        system = build_system_prompt(base_system, category=style_record.category, metadata=style_record.metadata, style_locale=args.style_locale)
        input_field = build_input_field(style_record, max_history_turns=args.max_history_turns, style_locale=args.style_locale)
        sft = SFTSample(
            id=style_record.id,
            category=style_record.category,
            instruction=style_record.user_query,
            input=input_field,
            output=style_record.assistant_reply,
            system=system,
            metadata={"source": style_record.source, "style_locale": args.style_locale, **style_record.metadata},
        )
        sft_rows.append(sft.to_dict())

    dump_json(sft_rows, args.output)
    print(f"SFT 数据构建完成：{len(sft_rows)} 条 -> {args.output}")


if __name__ == "__main__":
    main()
