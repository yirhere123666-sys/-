#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ecom_stage1.io_utils import dump_jsonl, load_records


def main() -> None:
    parser = argparse.ArgumentParser(description="合并多个归一化 json/jsonl")
    parser.add_argument("--inputs", nargs="+", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    merged = []
    for path in args.inputs:
        merged.extend(load_records(path))
    dump_jsonl(merged, args.output)
    print(f"合并完成：共 {len(merged)} 条 -> {args.output}")


if __name__ == "__main__":
    main()
