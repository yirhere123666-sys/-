#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ecom_stage1.io_utils import dump_json, load_records
from ecom_stage1.quality import category_counter, metadata_counter, report_lengths, source_counter


def main() -> None:
    parser = argparse.ArgumentParser(description="输出阶段一数据质量报告")
    parser.add_argument("--input", required=True)
    parser.add_argument("--query-key", default="instruction")
    parser.add_argument("--answer-key", default="output")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    rows = load_records(args.input)
    report = {
        "num_rows": len(rows),
        "category_dist": category_counter(rows),
        "source_dist": source_counter(rows),
        "normalized_category_dist": metadata_counter(rows, "normalized_category"),
        "issue_area_dist": metadata_counter(rows, "issue_area"),
        "length_report": report_lengths(rows, query_key=args.query_key, answer_key=args.answer_key),
    }
    dump_json(report, args.output)
    print(f"质量报告已输出 -> {args.output}")
    print(report)


if __name__ == "__main__":
    main()
