#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ecom_stage1.io_utils import dump_jsonl, iter_records
from ecom_stage1.normalization import normalize_csv_record


def main() -> None:
    parser = argparse.ArgumentParser(description="归一化英文客服单轮 CSV")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--max-samples", type=int, default=0)
    args = parser.parse_args()

    normalized = []
    input_count = 0
    for idx, row in enumerate(iter_records(args.input, max_rows=args.max_samples)):
        input_count += 1
        normalized.extend(x.to_dict() for x in normalize_csv_record(row, index=idx))

    dump_jsonl(normalized, args.output)
    print(f"csv 归一化完成：输入 {input_count} 条，输出 {len(normalized)} 条 -> {args.output}")


if __name__ == "__main__":
    main()
