#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ecom_stage1.io_utils import dump_jsonl, iter_records
from ecom_stage1.normalization import normalize_parquet_record


def main() -> None:
    parser = argparse.ArgumentParser(description="归一化 parquet 多轮客服对话")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--ecom-only", action="store_true", help="只保留和电商售后更相关的样本")
    parser.add_argument("--max-samples", type=int, default=0)
    args = parser.parse_args()

    normalized = []
    input_count = 0
    for idx, row in enumerate(iter_records(args.input, max_rows=args.max_samples)):
        input_count += 1
        normalized.extend(x.to_dict() for x in normalize_parquet_record(row, index=idx, ecom_only=args.ecom_only))

    dump_jsonl(normalized, args.output)
    print(f"parquet 归一化完成：输入 {input_count} 条，输出 {len(normalized)} 条 -> {args.output}")


if __name__ == "__main__":
    main()
