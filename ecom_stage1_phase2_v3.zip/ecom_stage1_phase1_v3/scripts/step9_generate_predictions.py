#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ecom_stage1.inference import HFGenerator, VLLMGenerator
from ecom_stage1.io_utils import dump_json, load_records, load_text


def main() -> None:
    parser = argparse.ArgumentParser(description="对评测集生成离线预测")
    parser.add_argument("--model-path", required=True, help="adapter 路径或 vllm model path")
    parser.add_argument("--base-model", default="Qwen/Qwen2-7B-Instruct")
    parser.add_argument("--eval-set", required=True)
    parser.add_argument("--system-prompt", default=str(ROOT / "prompts" / "system_prompt.txt"))
    parser.add_argument("--backend", choices=["hf", "vllm"], default="hf")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    system_prompt = load_text(args.system_prompt)
    eval_rows = load_records(args.eval_set)
    generator = VLLMGenerator(args.model_path) if args.backend == "vllm" else HFGenerator(args.base_model, adapter_path=args.model_path)

    outputs = []
    for row in eval_rows:
        history = row.get("history", [])
        input_context = ""
        if history:
            input_context = "\n".join([f"{x['role']}: {x['content']}" for x in history])
        pred = generator.generate(system_prompt, row["query"], input_context=input_context)
        outputs.append({"id": row["id"], "prediction": pred, "category": row.get("category", "unknown")})

    dump_json(outputs, args.output)
    print(f"预测结果已输出 -> {args.output}")


if __name__ == "__main__":
    main()
