#!/usr/bin/env bash
set -e
ROOT_DIR=$(cd "$(dirname "$0")/.." && pwd)
llamafactory-cli train "$ROOT_DIR/configs/qwen2_7b_qlora_dpo.yaml"
