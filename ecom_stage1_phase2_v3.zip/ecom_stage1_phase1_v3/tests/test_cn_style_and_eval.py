from ecom_stage1.cn_style import apply_zh_ecom_style
from ecom_stage1.eval_builder import stratified_eval_sample
from ecom_stage1.schemas import NormalizedRecord


def test_zh_style_mapping_refund():
    record = NormalizedRecord(
        id="x1",
        source="csv_singleturn",
        category="refund_request",
        user_query="How long does a refund take?",
        assistant_reply="It may take a few days to reflect in your bank.",
        history=[],
        metadata={},
    )
    q, a, meta = apply_zh_ecom_style(record)
    assert "退款" in q
    assert "原路退回" in a or "退款" in a
    assert meta["style_locale"] == "zh_ecom"



def test_stratified_eval_sampling_respects_target():
    rows = []
    cats = ["refund_request", "order_status", "cancel_order", "product_issue", "account_help"]
    for i in range(100):
        for c in cats:
            rows.append(
                {
                    "id": f"{c}_{i}",
                    "category": c,
                    "user_query": f"q_{c}_{i}",
                    "assistant_reply": f"a_{c}_{i}",
                    "metadata": {"source": "csv_singleturn", "customer_sentiment": "neutral", "issue_complexity": "medium"},
                }
            )
    sampled = stratified_eval_sample(rows, target_size=120, min_per_category=20, seed=42)
    assert len(sampled) == 120
    counts = {}
    for row in sampled:
        counts[row["category"]] = counts.get(row["category"], 0) + 1
    assert all(v >= 20 for v in counts.values())
