from ecom_stage1.dpo_builder import build_one_dpo_sample


def test_build_dpo_pair():
    sft_item = {
        "id": "1",
        "category": "refund_request",
        "instruction": "How long does the refund take?",
        "input": "",
        "output": "We will process it and the refund will arrive in 5-7 days.",
        "system": "You are a helpful support agent.",
        "metadata": {},
    }
    sample = build_one_dpo_sample(sft_item)
    assert sample is not None
    assert sample.rejected != sample.chosen
