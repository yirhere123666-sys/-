from ecom_stage1.normalization import infer_stage1_category, normalize_parquet_record


def test_parquet_record_to_pairs():
    row = {
        "issue_area": "Cancellations and returns",
        "issue_category": "Pickup and Shipping",
        "issue_sub_category": "Reasons for being asked to ship the item",
        "customer_sentiment": "neutral",
        "product_category": "Electronics",
        "conversation": """Agent: Hello.\n\nCustomer: My monitor was recalled. Why do I need to return it?\n\nAgent: We are requesting a return and will issue a refund after inspection.\n\nCustomer: What is the return process?\n\nAgent: Pack it and drop it at UPS. Refund in 5-7 days.""",
    }
    rows = normalize_parquet_record(row, index=1, ecom_only=True)
    assert len(rows) == 2
    assert rows[0].category == "refund_request"
    assert rows[1].assistant_reply.startswith("Pack it")


def test_infer_stage1_category():
    assert infer_stage1_category("Login and Account", "Mobile Number and Email Verification") == "account_help"
    assert infer_stage1_category("Order", "Order Confirmation and Status") == "order_status"
    assert infer_stage1_category("Cancellations and returns", "Returns and Refunds") == "refund_request"
