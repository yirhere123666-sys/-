from ecom_stage1.masking import apply_full_mask
from ecom_stage1.normalization import normalize_source_record


def test_masking():
    text = "订单号 1234567890123456，手机号 13812345678，邮箱 a@test.com"
    masked = apply_full_mask(text)
    assert "[PHONE]" in masked
    assert "[ORDER_OR_TRACKING]" in masked
    assert "[EMAIL]" in masked


def test_normalize_messages():
    raw = {
        "id": "x1",
        "messages": [
            {"role": "user", "content": "这个支持NFC吗？"},
            {"role": "assistant", "content": "支持。"},
            {"role": "user", "content": "能刷门禁吗？"},
            {"role": "assistant", "content": "兼容性以设备说明为准。"},
        ],
    }
    rows = normalize_source_record(raw)
    assert len(rows) == 2
    assert rows[0].assistant_reply == "支持。"
