from pathlib import Path

from ecom_stage1.io_utils import dump_jsonl, load_records
from ecom_stage1.schemas import NormalizedRecord
from ecom_stage1.dedup import deduplicate_records
from ecom_stage1.prompts import build_input_field, build_system_prompt


def test_smoke_clean_sft(tmp_path: Path):
    rows = [
        NormalizedRecord(
            id="a1",
            source="parquet_multiturn",
            category="refund_request",
            user_query="I need a refund",
            assistant_reply="We will review your refund request.",
            history=[],
            metadata={"issue_area": "Cancellations and returns"},
        ).to_dict(),
        NormalizedRecord(
            id="a2",
            source="csv_singleturn",
            category="order_status",
            user_query="Where is my order?",
            assistant_reply="Your order has been dispatched.",
            history=[],
            metadata={"intent": "order_status"},
        ).to_dict(),
    ]
    p = tmp_path / "norm.jsonl"
    dump_jsonl(rows, p)
    loaded = [NormalizedRecord(**x) for x in load_records(p)]
    deduped, stats = deduplicate_records(loaded)
    assert len(deduped) == 2
    system = build_system_prompt("base", category="refund_request", metadata={"issue_area": "returns"})
    assert "当前问题类别" in system
    input_field = build_input_field(loaded[0])
    assert isinstance(input_field, str)
