from __future__ import annotations

from typing import Dict

from .cn_style import localized_category, localized_system_suffix
from .normalization import format_history
from .schemas import NormalizedRecord


def build_system_prompt(base_system: str, category: str, metadata: Dict, style_locale: str = "origin") -> str:
    suffix_parts = []
    if category:
        if style_locale == "zh_ecom":
            suffix_parts.append(localized_system_suffix(category))
        else:
            suffix_parts.append(f"当前问题类别: {category}")
    issue_area = metadata.get("issue_area")
    if issue_area:
        suffix_parts.append(f"问题领域: {issue_area}")
    product_category = metadata.get("product_category")
    if product_category:
        label = "商品大类" if style_locale == "zh_ecom" else "商品大类"
        suffix_parts.append(f"{label}: {product_category}")
    if metadata.get("issue_complexity"):
        suffix_parts.append(f"复杂度: {metadata.get('issue_complexity')}")
    if style_locale == "zh_ecom" and metadata.get("localized_category_zh"):
        suffix_parts.append(f"中文场景映射类别: {metadata.get('localized_category_zh')}")
    if not suffix_parts:
        return base_system.strip()
    return base_system.strip() + "\n\n" + "；".join(suffix_parts)



def build_input_field(record: NormalizedRecord, max_history_turns: int = 3, style_locale: str = "origin") -> str:
    history = format_history(record.history, max_turns=max_history_turns)
    if history:
        title = "历史上下文" if style_locale == "zh_ecom" else "历史上下文"
        return f"{title}:\n{history}"
    return ""
