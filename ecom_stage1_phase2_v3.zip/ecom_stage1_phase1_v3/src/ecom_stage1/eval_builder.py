from __future__ import annotations

import random
from collections import defaultdict
from typing import Dict, List, Tuple

from .schemas import EvalSample

KEYWORD_HINTS = {
    "refund_request": ["refund", "return", "request", "process", "退款", "退货", "售后"],
    "order_status": ["order", "status", "delivery", "物流", "订单", "配送"],
    "cancel_order": ["cancel", "order", "取消", "订单"],
    "product_issue": ["return", "replacement", "issue", "质量", "缺件", "损坏"],
    "account_help": ["password", "account", "verify", "账号", "登录", "验证"],
}

FORBIDDEN_HINTS = {
    "refund_request": ["full refund immediately without review", "无需审核，直接全额退款", "今天一定到账"],
    "cancel_order": ["guaranteed cancellation after shipment", "发货后一定可直接取消", "100%直接取消"],
    "product_issue": ["100% compatible", "保证兼容所有设备", "直接赔偿"],
    "account_help": ["不用身份验证", "直接帮您重置账号和密码"],
    "order_status": ["今天肯定送达", "已经在派送中，今天肯定送达"],
}


def infer_category_key(category: str) -> str:
    category = (category or "").lower().strip()
    if category in KEYWORD_HINTS:
        return category
    if "refund" in category or "return" in category:
        return "refund_request"
    if "order" in category and ("status" in category or "delivery" in category):
        return "order_status"
    if "cancel" in category:
        return "cancel_order"
    if "product" in category or "replacement" in category or "warranty" in category:
        return "product_issue"
    if "account" in category or "login" in category:
        return "account_help"
    return category or "unknown"



def _bucket_key(row: Dict) -> Tuple[str, str, str]:
    meta = row.get("metadata", {}) or {}
    source = str(meta.get("source") or row.get("source") or "unknown")
    sentiment = str(meta.get("customer_sentiment") or "unknown")
    complexity = str(meta.get("issue_complexity") or "unknown")
    return source, sentiment, complexity



def build_eval_sample(row: Dict) -> EvalSample:
    cat_key = infer_category_key(row.get("category", ""))
    must_mention = KEYWORD_HINTS.get(cat_key, [])
    forbidden = FORBIDDEN_HINTS.get(cat_key, [])
    meta = row.get("metadata", {}) or {}
    expected_resolution = "direct_answer"
    if cat_key == "account_help":
        expected_resolution = "guide_and_verify"
    elif cat_key == "product_issue":
        expected_resolution = "collect_evidence_then_process"
    return EvalSample(
        id=row["id"],
        category=cat_key,
        query=row["user_query"],
        reference_answer=row["assistant_reply"],
        must_mention=must_mention,
        forbidden_patterns=forbidden,
        gold_tags=[cat_key],
        can_answer_directly=True,
        expected_resolution=expected_resolution,
        history=row.get("history", []),
        metadata={
            **meta,
            "eval_bucket": {
                "source": _bucket_key(row)[0],
                "sentiment": _bucket_key(row)[1],
                "complexity": _bucket_key(row)[2],
            },
        },
    )



def balanced_sample(rows: List[Dict], per_category: int = 40) -> List[Dict]:
    groups = defaultdict(list)
    for row in rows:
        groups[infer_category_key(row.get("category") or "unknown")].append(row)
    out = []
    for _, items in sorted(groups.items()):
        out.extend(items[:per_category])
    return out



def stratified_eval_sample(rows: List[Dict], target_size: int = 600, min_per_category: int = 80, seed: int = 42) -> List[Dict]:
    """按类别优先、再按 source/sentiment/complexity 做 round-robin 的评测抽样。"""
    rng = random.Random(seed)
    groups = defaultdict(list)
    for row in rows:
        groups[infer_category_key(row.get("category") or "unknown")].append(row)

    categories = sorted(groups.keys())
    if not categories:
        return []

    # 类别内先随机，再按 bucket 分组做 round-robin，增强多样性
    category_ranked = {}
    for cat, items in groups.items():
        items = items[:]
        rng.shuffle(items)
        bucketed = defaultdict(list)
        for item in items:
            bucketed[_bucket_key(item)].append(item)
        ordered = []
        bucket_keys = list(bucketed.keys())
        idx = 0
        while True:
            progressed = False
            for bk in bucket_keys:
                if idx < len(bucketed[bk]):
                    ordered.append(bucketed[bk][idx])
                    progressed = True
            if not progressed:
                break
            idx += 1
        category_ranked[cat] = ordered

    available_total = sum(len(v) for v in category_ranked.values())
    if available_total <= target_size:
        out = []
        for cat in categories:
            out.extend(category_ranked[cat])
        return out

    sampled = []
    used_ids = set()

    # 第一轮：每类至少拿 min_per_category（拿不到就全拿）
    for cat in categories:
        take = min(min_per_category, len(category_ranked[cat]))
        for row in category_ranked[cat][:take]:
            if row["id"] not in used_ids:
                sampled.append(row)
                used_ids.add(row["id"])

    # 第二轮：如果超了就裁；如果没到，继续按 round-robin 补满 target_size
    if len(sampled) > target_size:
        return sampled[:target_size]

    pointers = {cat: min(min_per_category, len(category_ranked[cat])) for cat in categories}
    while len(sampled) < target_size:
        progressed = False
        for cat in categories:
            p = pointers[cat]
            if p < len(category_ranked[cat]):
                row = category_ranked[cat][p]
                pointers[cat] += 1
                if row["id"] not in used_ids:
                    sampled.append(row)
                    used_ids.add(row["id"])
                    progressed = True
                    if len(sampled) >= target_size:
                        break
        if not progressed:
            break
    return sampled
