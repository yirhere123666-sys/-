from __future__ import annotations

import hashlib
import re
from typing import Dict, List, Tuple

try:
    import jieba  # type: ignore
except Exception:
    jieba = None

try:
    from datasketch import MinHash, MinHashLSH  # type: ignore
except Exception:
    MinHash = None
    MinHashLSH = None

from .masking import apply_full_mask
from .schemas import NormalizedRecord

MIN_TOKEN_SIZE = 3


def build_signature_text(record: NormalizedRecord) -> str:
    query = apply_full_mask(record.user_query)
    reply = apply_full_mask(record.assistant_reply)
    history = " ".join(apply_full_mask(x.get("content", "")) for x in record.history)
    category = record.category or ""
    return f"{category} [SEP] {history} [Q] {query} [A] {reply}".strip()


def tokenize_signature(text: str) -> List[str]:
    text = text or ""
    zh_tokens = [t.strip() for t in (jieba.lcut(text) if jieba is not None else re.findall(r"[\u4e00-\u9fa5]", text)) if t.strip()]
    en_tokens = re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?|\d+", text.lower())
    return sorted(set(zh_tokens + en_tokens))


def hash_exact_key(record: NormalizedRecord) -> str:
    raw = f"{record.user_query}|||{record.assistant_reply}|||{record.category}"
    return hashlib.md5(raw.encode("utf-8")).hexdigest()


def minhash_for_tokens(tokens: List[str], num_perm: int):
    mh = MinHash(num_perm=num_perm)
    for token in tokens:
        mh.update(token.encode("utf-8"))
    return mh


def _dedup_with_jaccard(records: List[NormalizedRecord], threshold: float) -> Tuple[List[Dict], Dict[str, int]]:
    deduped: List[Dict] = []
    signatures: List[set[str]] = []
    exact_seen = set()
    stats = {"input": len(records), "filtered_short": 0, "exact_dup": 0, "near_dup": 0, "kept": 0}

    for record in records:
        exact_key = hash_exact_key(record)
        if exact_key in exact_seen:
            stats["exact_dup"] += 1
            continue
        exact_seen.add(exact_key)

        signature = build_signature_text(record)
        tokens = set(tokenize_signature(signature))
        if len(tokens) < MIN_TOKEN_SIZE:
            stats["filtered_short"] += 1
            continue

        is_dup = False
        for prev in signatures:
            inter = len(tokens & prev)
            union = len(tokens | prev)
            score = inter / union if union else 0.0
            if score >= threshold:
                is_dup = True
                break
        if is_dup:
            stats["near_dup"] += 1
            continue

        signatures.append(tokens)
        deduped.append(record.to_dict())
        stats["kept"] += 1

    return deduped, stats


def deduplicate_records(records: List[NormalizedRecord], threshold: float = 0.88, num_perm: int = 128) -> Tuple[List[Dict], Dict[str, int]]:
    if MinHashLSH is None or MinHash is None:
        return _dedup_with_jaccard(records, threshold=threshold)

    lsh = MinHashLSH(threshold=threshold, num_perm=num_perm)
    deduped: List[Dict] = []
    exact_seen = set()
    stats = {"input": len(records), "filtered_short": 0, "exact_dup": 0, "near_dup": 0, "kept": 0}

    for record in records:
        exact_key = hash_exact_key(record)
        if exact_key in exact_seen:
            stats["exact_dup"] += 1
            continue
        exact_seen.add(exact_key)

        signature = build_signature_text(record)
        tokens = tokenize_signature(signature)
        if len(tokens) < MIN_TOKEN_SIZE:
            stats["filtered_short"] += 1
            continue

        mh = minhash_for_tokens(tokens, num_perm=num_perm)
        if lsh.query(mh):
            stats["near_dup"] += 1
            continue

        lsh.insert(record.id, mh)
        deduped.append(record.to_dict())
        stats["kept"] += 1

    return deduped, stats
