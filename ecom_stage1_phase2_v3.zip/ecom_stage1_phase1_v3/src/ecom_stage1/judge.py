from __future__ import annotations

import json
import os
from typing import Any, Dict, Optional

from openai import OpenAI


class OpenAICompatibleJudge:
    def __init__(self, model: str, base_url: Optional[str] = None, api_key: Optional[str] = None):
        self.model = model
        self.base_url = base_url or os.getenv("OPENAI_BASE_URL")
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            raise ValueError("未提供 OPENAI_API_KEY，无法启用 LLM Judge。")
        self.client = OpenAI(api_key=self.api_key, base_url=self.base_url)

    def judge_json(self, system_prompt: str, user_prompt: str, temperature: float = 0.0) -> Dict[str, Any]:
        resp = self.client.chat.completions.create(
            model=self.model,
            temperature=temperature,
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        )
        content = resp.choices[0].message.content
        return json.loads(content)
