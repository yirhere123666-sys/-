from __future__ import annotations

import re
from typing import Dict, Tuple

from .schemas import NormalizedRecord

CATEGORY_CN = {
    "refund_request": "退款/退货",
    "order_status": "订单物流",
    "cancel_order": "取消订单",
    "product_issue": "商品问题",
    "account_help": "账号帮助",
}


def _norm(text: str) -> str:
    return (text or "").strip().lower()


def _contains_any(text: str, keywords: Tuple[str, ...]) -> bool:
    text = _norm(text)
    return any(k in text for k in keywords)


def localized_category(category: str) -> str:
    return CATEGORY_CN.get(category or "", category or "未知类别")


QUERY_RULES = {
    "refund_request": [
        (("how long", "take", "bank"), "退款一般多久到账？"),
        (("where", "apply", "request"), "请问在哪里申请退款？"),
        (("defective", "damaged", "wrong item", "faulty"), "收到的商品有问题，想申请退款或换货，请问怎么处理？"),
        (("charged", "payment"), "我的支付金额有异常，想申请退款，请问该怎么处理？"),
    ],
    "order_status": [
        (("where", "package", "parcel", "delivery"), "请问我的订单现在到哪了？"),
        (("shipped", "dispatch", "status"), "请帮我查询一下订单当前的物流状态。"),
    ],
    "cancel_order": [
        (("cancel", "purchase", "order"), "我想取消订单，请问现在还能取消吗？"),
        (("stop", "delivered"), "订单还在配送途中，可以拦截或取消吗？"),
    ],
    "product_issue": [
        (("missing", "parts"), "收到的商品有缺件，请问怎么处理？"),
        (("damaged", "broken", "quality", "defective", "faulty"), "商品有质量问题，请问可以怎么售后处理？"),
    ],
    "account_help": [
        (("reset", "password", "login"), "我的账号登录异常，想重置密码，请问怎么操作？"),
        (("locked", "access", "credential", "profile"), "账号被锁定或无法登录，请帮我看看怎么处理。"),
    ],
}


ANSWER_RULES = {
    "refund_request": [
        (("bank", "reflect"), "这边已为您提交退款申请，退款通常会在1-3个工作日原路退回，具体到账时间以银行处理为准。"),
        (("initiated", "review", "processed"), "这边已为您发起退款申请，审核通过后会按原支付路径退回，请您耐心等待。"),
        (("confirmation email",), "退款申请提交后会有站内或邮件通知，您也可以在订单售后页查看处理进度。"),
    ],
    "order_status": [
        (("dispatched", "shipped", "on the move"), "您的订单已经发出，建议您在订单详情页查看最新物流轨迹。"),
        (("processed",), "您的订单当前正在处理中，出库后会同步更新物流信息。"),
        (("delivered soon",), "您的订单正在配送中，预计近期送达，请留意物流更新。"),
    ],
    "cancel_order": [
        (("cancelled", "cancellation", "successful"), "这边已为您提交取消订单申请，如订单尚未发货，一般可直接取消，具体结果请以订单状态为准。"),
        (("not be charged",), "取消成功后不会继续扣款，如已支付，退款会按原路退回。"),
        (("email",), "取消申请提交成功后会有通知消息，请您留意订单状态和站内提醒。"),
    ],
    "product_issue": [
        (("images", "photo", "picture"), "非常抱歉给您带来不便，麻烦您提供商品照片或视频及订单信息，我们尽快为您核实处理。"),
        (("replacement", "eligible"), "如核实为商品问题，可为您申请换货或其他售后处理，请您先提交问题凭证。"),
        (("refund or exchange",), "如商品存在问题，通常可以为您申请退款或换货，具体以售后审核结果为准。"),
    ],
    "account_help": [
        (("reset link", "password"), "建议您先通过注册邮箱或手机号进行密码重置，如仍无法登录，我们再继续协助您核验处理。"),
        (("helpdesk", "recovery", "support team"), "您可以先按页面提示进行账号找回，如仍未解决，我们会进一步协助您处理。"),
        (("security questions", "verified", "unlock"), "完成身份核验后可协助您解锁账号，请按页面提示完成验证。"),
    ],
}


FALLBACK_QUERIES = {
    "refund_request": "我想申请退款/退货，请问应该怎么处理？",
    "order_status": "请帮我查询一下订单当前状态。",
    "cancel_order": "我想取消订单，请问现在还能取消吗？",
    "product_issue": "收到的商品有问题，请问怎么处理？",
    "account_help": "我的账号遇到问题了，请问怎么处理？",
}

FALLBACK_ANSWERS = {
    "refund_request": "您好，这边可以协助您申请退款或退货，建议您先进入订单售后页提交申请，具体以审核结果为准。",
    "order_status": "您好，建议您在订单详情页查看最新物流状态，如长时间未更新我们也可以继续帮您核实。",
    "cancel_order": "您好，如订单尚未发货，一般支持申请取消；若已进入发货流程，则需以订单页实际状态为准。",
    "product_issue": "您好，如商品存在质量问题或缺件情况，建议您提交图片凭证，我们会尽快为您核实处理。",
    "account_help": "您好，建议您先通过注册邮箱或手机号找回账号，如仍有问题我们再继续协助处理。",
}


STYLE_SUFFIX = {
    "refund_request": "请避免直接承诺全额退款，需保留审核与时效边界。",
    "order_status": "请不要编造物流状态，优先引导用户查看订单页或物流页。",
    "cancel_order": "请不要承诺发货后一定能取消，需根据订单状态说明。",
    "product_issue": "请不要绝对化承诺兼容性或赔付，先核实凭证与问题类型。",
    "account_help": "请避免跳过身份核验，优先引导用户通过官方流程找回账号。",
}


def localize_query(query: str, category: str) -> str:
    rules = QUERY_RULES.get(category, [])
    q = _norm(query)
    for keywords, template in rules:
        if all(k in q for k in keywords[:1]) and _contains_any(q, keywords):
            return template
    return FALLBACK_QUERIES.get(category, query or "")



def localize_answer(answer: str, category: str) -> str:
    rules = ANSWER_RULES.get(category, [])
    a = _norm(answer)
    for keywords, template in rules:
        if _contains_any(a, keywords):
            return template
    return FALLBACK_ANSWERS.get(category, answer or "")



def apply_zh_ecom_style(record: NormalizedRecord) -> Tuple[str, str, Dict]:
    """将原始英文/混合语料映射为中文电商客服风格。

    这不是通用机器翻译，而是为第一阶段训练准备的规则式本地化层：
    - 把用户问题映射成更贴近中文电商客服的提问方式
    - 把客服回复映射成带边界感的中文售后表达
    - 保留原始文本到 metadata，便于回溯
    """
    localized_query = localize_query(record.user_query, record.category)
    localized_answer = localize_answer(record.assistant_reply, record.category)
    meta = dict(record.metadata or {})
    meta.update(
        {
            "style_locale": "zh_ecom",
            "original_user_query": record.user_query,
            "original_assistant_reply": record.assistant_reply,
            "localized_category_zh": localized_category(record.category),
        }
    )
    return localized_query, localized_answer, meta



def localized_system_suffix(category: str) -> str:
    cat_zh = localized_category(category)
    extra = STYLE_SUFFIX.get(category, "请保持客服语气自然、克制，优先说明规则与操作路径。")
    return f"当前问题类别：{cat_zh}。{extra}"
