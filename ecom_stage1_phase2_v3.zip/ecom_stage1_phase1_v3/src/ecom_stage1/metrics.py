from __future__ import annotations

import re
from collections import Counter
from typing import List, Sequence

try:
    import jieba
except Exception:
    jieba = None

from sklearn.metrics import f1_score


def normalize_for_eval(text: str) -> str:
    text = text or ""
    text = text.lower().strip()
    text = re.sub(r"\s+", " ", text)
    return text



def tokenize(text: str) -> List[str]:
    normalized = normalize_for_eval(text)
    if not normalized:
        return []
    if jieba is not None:
        return [tok.strip() for tok in jieba.lcut(normalized) if tok.strip()]
    return [tok for tok in re.split(r"[^\w\u4e00-\u9fff]+", normalized) if tok]



def squad_like_f1(prediction: str, reference: str) -> float:
    pred_tokens = tokenize(prediction)
    ref_tokens = tokenize(reference)
    if not pred_tokens and not ref_tokens:
        return 1.0
    if not pred_tokens or not ref_tokens:
        return 0.0

    common = Counter(pred_tokens) & Counter(ref_tokens)
    overlap = sum(common.values())
    if overlap == 0:
        return 0.0
    precision = overlap / len(pred_tokens)
    recall = overlap / len(ref_tokens)
    return 2 * precision * recall / (precision + recall)



def keyword_coverage(prediction: str, must_mention: Sequence[str]) -> float:
    if not must_mention:
        return 1.0
    pred = normalize_for_eval(prediction)
    hits = sum(1 for kw in must_mention if normalize_for_eval(kw) in pred)
    return hits / len(must_mention)



def forbidden_violation(prediction: str, forbidden_patterns: Sequence[str]) -> bool:
    pred = normalize_for_eval(prediction)
    return any(normalize_for_eval(pat) in pred for pat in forbidden_patterns)



def is_invalid_refusal(prediction: str, can_answer_directly: bool) -> bool:
    if not can_answer_directly:
        return False
    pred = normalize_for_eval(prediction)
    refusal_patterns = [
        "无法处理",
        "联系人工客服",
        "暂不支持",
        "无法回答",
        "稍后再试",
        "请转人工",
        "cannot help",
        "contact a human agent",
        "not supported here",
    ]
    actionable_patterns = [
        "申请",
        "上传",
        "审核",
        "查询",
        "提交",
        "请提供",
        "支持",
        "可以",
        "order page",
        "refund",
        "reset",
    ]
    refusal_hit = any(p in pred for p in refusal_patterns)
    actionable_hit = any(p in pred for p in actionable_patterns)
    return refusal_hit and not actionable_hit



def heuristic_hallucination(prediction: str, reference: str, forbidden_patterns: Sequence[str]) -> bool:
    pred = normalize_for_eval(prediction)
    ref = normalize_for_eval(reference)
    if forbidden_violation(prediction, forbidden_patterns):
        return True

    hard_claims = [
        "100%",
        "guaranteed",
        "definitely",
        "无需审核",
        "直接全额退款",
        "今天一定到账",
        "今天肯定送达",
        "保证兼容所有设备",
    ]
    if any(c.lower() in pred for c in [normalize_for_eval(x) for x in hard_claims]) and not any(
        c.lower() in ref for c in [normalize_for_eval(x) for x in hard_claims]
    ):
        return True

    # 如果预测包含大量 reference 没有的关键数字/时效词，视作疑似幻觉
    pred_nums = re.findall(r"\d+", pred)
    ref_nums = re.findall(r"\d+", ref)
    if pred_nums and set(pred_nums) - set(ref_nums):
        risky_time_words = ["day", "days", "hour", "hours", "天", "小时", "工作日"]
        if any(w in pred for w in risky_time_words):
            return True
    return False



def binary_accuracy_from_rules(
    prediction: str,
    reference: str,
    must_mention: Sequence[str],
    forbidden_patterns: Sequence[str],
    threshold: float = 0.55,
) -> int:
    f1 = squad_like_f1(prediction, reference)
    coverage = keyword_coverage(prediction, must_mention)
    violated = forbidden_violation(prediction, forbidden_patterns)
    score = 0.7 * f1 + 0.3 * coverage
    return int(score >= threshold and not violated)



def micro_f1_for_tags(y_true: List[List[str]], y_pred: List[List[str]], all_tags: List[str]) -> float:
    tag2idx = {tag: idx for idx, tag in enumerate(all_tags)}
    true_bin, pred_bin = [], []
    for true_tags, pred_tags in zip(y_true, y_pred):
        t = [0] * len(all_tags)
        p = [0] * len(all_tags)
        for tag in true_tags:
            if tag in tag2idx:
                t[tag2idx[tag]] = 1
        for tag in pred_tags:
            if tag in tag2idx:
                p[tag2idx[tag]] = 1
        true_bin.append(t)
        pred_bin.append(p)
    if not true_bin:
        return 0.0
    return float(f1_score(true_bin, pred_bin, average="micro", zero_division=0))
