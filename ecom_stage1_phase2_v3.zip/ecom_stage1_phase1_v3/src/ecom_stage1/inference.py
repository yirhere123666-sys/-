from __future__ import annotations

from typing import Dict, List, Optional

from transformers import AutoModelForCausalLM, AutoTokenizer


def format_chat_messages(system: str, user_query: str, input_context: str = "") -> List[Dict[str, str]]:
    content = user_query if not input_context else f"{input_context}\n\n当前用户问题: {user_query}"
    return [
        {"role": "system", "content": system},
        {"role": "user", "content": content},
    ]


class HFGenerator:
    def __init__(self, base_model: str, adapter_path: Optional[str] = None, max_new_tokens: int = 256):
        self.tokenizer = AutoTokenizer.from_pretrained(base_model, trust_remote_code=True)
        self.model = AutoModelForCausalLM.from_pretrained(base_model, trust_remote_code=True)
        # 这里保留简单实现。若 adapter_path 不为空，可由用户结合 peft.PeftModel.from_pretrained 挂载。
        self.max_new_tokens = max_new_tokens

    def generate(self, system: str, user_query: str, input_context: str = "") -> str:
        messages = format_chat_messages(system, user_query, input_context)
        text = self.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        inputs = self.tokenizer(text, return_tensors="pt")
        outputs = self.model.generate(**inputs, max_new_tokens=self.max_new_tokens)
        decoded = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        return decoded.split("assistant")[-1].strip()


class VLLMGenerator:
    def __init__(self, model_path: str, max_new_tokens: int = 256, temperature: float = 0.0):
        from vllm import LLM, SamplingParams
        self.llm = LLM(model=model_path, trust_remote_code=True)
        self.params = SamplingParams(temperature=temperature, max_tokens=max_new_tokens)

    def generate(self, system: str, user_query: str, input_context: str = "") -> str:
        messages = format_chat_messages(system, user_query, input_context)
        prompt = "\n".join([f"{m['role']}: {m['content']}" for m in messages]) + "\nassistant:"
        outputs = self.llm.generate(prompt, self.params)
        return outputs[0].outputs[0].text.strip()
