from __future__ import annotations

import html
import re
from typing import Any, Dict, Iterable, List, Optional, Tuple

from .schemas import Message, NormalizedRecord

ROLE_ALIASES = {
    "human": "user",
    "customer": "user",
    "buyer": "user",
    "user": "user",
    "visitor": "user",
    "agent": "assistant",
    "assistant": "assistant",
    "specialist": "assistant",
    "representative": "assistant",
    "support": "assistant",
    "seller": "assistant",
    "客服": "assistant",
    "系统": "system",
    "system": "system",
}

E_COMMERCE_AREA_KEYWORDS = {
    "cancellations and returns",
    "order",
    "shipping",
    "warranty",
    "shopping",
    "login and account",
}

E_COMMERCE_CATEGORY_KEYWORDS = {
    "return",
    "refund",
    "order",
    "delivery",
    "shipping",
    "invoice",
    "payment",
    "replacement",
    "warranty",
    "cancellation",
    "account",
    "login",
}

CONV_ROLE_PATTERN = re.compile(
    r"^\s*(?:\*\*)?(Agent|Customer|Specialist|Assistant|User)(?:\*\*)?\s*:\s*(.*)$",
    flags=re.IGNORECASE,
)


def normalize_text(text: Any) -> str:
    if text is None:
        return ""
    text = str(text)
    text = html.unescape(text)
    text = text.replace("\u3000", " ").replace("\xa0", " ")
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"[\r\t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r"[ ]{2,}", " ", text)
    return text.strip()


def normalize_role(role: Any) -> str:
    role = normalize_text(role).strip().lower().strip(":")
    role = role.replace("**", "")
    return ROLE_ALIASES.get(role, role or "unknown")


def merge_consecutive_messages(messages: List[Message]) -> List[Message]:
    merged: List[Message] = []
    for msg in messages:
        content = normalize_text(msg.content)
        if not content:
            continue
        if merged and merged[-1].role == msg.role:
            prev = merged[-1].content.rstrip()
            cur = content.lstrip()
            merged[-1] = Message(role=msg.role, content=(prev + " " + cur).strip())
        else:
            merged.append(Message(role=msg.role, content=content))
    return merged


def parse_conversation_text(conv_text: str) -> List[Message]:
    conv_text = normalize_text(conv_text)
    if not conv_text:
        return []

    messages: List[Message] = []
    current_role: Optional[str] = None
    current_content: List[str] = []

    for raw_line in conv_text.split("\n"):
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            continue
        if "rewritten conversation" in line.lower():
            continue

        match = CONV_ROLE_PATTERN.match(line)
        if match:
            if current_role and current_content:
                messages.append(Message(role=current_role, content=" ".join(current_content).strip()))
            current_role = normalize_role(match.group(1))
            current_content = [match.group(2).strip()]
        elif current_role:
            current_content.append(line)

    if current_role and current_content:
        messages.append(Message(role=current_role, content=" ".join(current_content).strip()))

    messages = [m for m in messages if m.role in {"user", "assistant"} and m.content]
    return merge_consecutive_messages(messages)


def extract_messages_from_record(record: Dict[str, Any]) -> List[Message]:
    for key in ("messages", "conversation", "conversations", "chat_history"):
        value = record.get(key)
        if isinstance(value, list) and value:
            out = []
            for item in value:
                if not isinstance(item, dict):
                    continue
                role = normalize_role(item.get("role") or item.get("from") or item.get("speaker") or item.get("sender"))
                content = normalize_text(item.get("content") or item.get("value") or item.get("text") or item.get("message"))
                if role in {"user", "assistant"} and content:
                    out.append(Message(role=role, content=content))
            return merge_consecutive_messages(out)

    if isinstance(record.get("conversation"), str):
        parsed = parse_conversation_text(record["conversation"])
        if parsed:
            return parsed
    return []


def iter_qa_pairs_from_messages(messages: List[Message], max_history_turns: int = 3) -> Iterable[Tuple[List[Dict[str, str]], str, str]]:
    history: List[Dict[str, str]] = []
    pending_user: List[str] = []

    for msg in messages:
        if msg.role == "user":
            pending_user.append(msg.content)
            continue

        if msg.role == "assistant" and pending_user:
            user_query = " ".join(pending_user).strip()
            assistant_reply = msg.content.strip()
            clipped_history = history[-max_history_turns * 2 :] if history else []
            if user_query and assistant_reply:
                yield clipped_history, user_query, assistant_reply
                history.extend([
                    {"role": "user", "content": user_query},
                    {"role": "assistant", "content": assistant_reply},
                ])
            pending_user = []


def is_relevant_ecommerce_record(record: Dict[str, Any]) -> bool:
    area = normalize_text(record.get("issue_area")).lower()
    category = normalize_text(record.get("issue_category")).lower()
    sub = normalize_text(record.get("issue_sub_category")).lower()
    text = " ".join([area, category, sub])
    if area in E_COMMERCE_AREA_KEYWORDS:
        return True
    return any(k in text for k in E_COMMERCE_CATEGORY_KEYWORDS)


def infer_stage1_category(*texts: Any) -> str:
    merged = " ".join(normalize_text(t).lower() for t in texts if t)
    if any(k in merged for k in ["account", "login", "password", "verification", "credential"]):
        return "account_help"
    if any(k in merged for k in ["refund", "return", "exchange", "invoice", "payment", "pickup", "fee", "cod"]):
        return "refund_request"
    if any(k in merged for k in ["cancel order", "cancel my", "order cancellation", "cancellation request"]):
        return "cancel_order"
    if any(k in merged for k in ["status", "delivery", "shipping", "shipment", "track", "dispatch", "parcel", "package", "order confirmation"]):
        return "order_status"
    if any(k in merged for k in ["cancel", "cancellation"]):
        return "cancel_order"
    if any(k in merged for k in ["warranty", "defect", "damaged", "missing", "availability", "installation", "quality", "replacement", "fault"]):
        return "product_issue"
    return "product_issue"


def normalize_parquet_record(record: Dict[str, Any], index: int = 0, ecom_only: bool = True) -> List[NormalizedRecord]:
    if ecom_only and not is_relevant_ecommerce_record(record):
        return []

    messages = extract_messages_from_record(record)
    if not messages:
        return []

    base_id = f"parquet_{index:06d}"
    raw_issue_area = normalize_text(record.get("issue_area"))
    raw_issue_category = normalize_text(record.get("issue_category"))
    raw_issue_sub_category = normalize_text(record.get("issue_sub_category"))
    stage1_category = infer_stage1_category(raw_issue_area, raw_issue_category, raw_issue_sub_category)
    metadata = {
        "issue_area": raw_issue_area,
        "issue_category": raw_issue_category,
        "issue_sub_category": raw_issue_sub_category,
        "issue_category_sub_category": normalize_text(record.get("issue_category_sub_category")),
        "customer_sentiment": normalize_text(record.get("customer_sentiment")),
        "product_category": normalize_text(record.get("product_category")),
        "product_sub_category": normalize_text(record.get("product_sub_category")),
        "issue_complexity": normalize_text(record.get("issue_complexity")),
        "agent_experience_level": normalize_text(record.get("agent_experience_level")),
        "normalized_category": stage1_category,
    }

    outputs: List[NormalizedRecord] = []
    for turn_idx, (history, user_query, assistant_reply) in enumerate(iter_qa_pairs_from_messages(messages, max_history_turns=3)):
        outputs.append(
            NormalizedRecord(
                id=f"{base_id}_turn{turn_idx}",
                source="parquet_multiturn",
                category=stage1_category,
                user_query=user_query,
                assistant_reply=assistant_reply,
                history=history,
                metadata=metadata,
            )
        )
    return outputs


def normalize_csv_record(record: Dict[str, Any], index: int = 0) -> List[NormalizedRecord]:
    user_query = normalize_text(record.get("user_query_en") or record.get("query") or record.get("question"))
    assistant_reply = normalize_text(record.get("bot_response_en") or record.get("answer") or record.get("response"))
    if not user_query or not assistant_reply:
        return []

    raw_intent = normalize_text(record.get("intent"))
    raw_category = normalize_text(record.get("category"))
    stage1_category = infer_stage1_category(raw_intent, raw_category, user_query, assistant_reply)
    metadata = {
        "intent": raw_intent,
        "category_group": raw_category,
        "query_id": record.get("query_id") or index,
        "normalized_category": stage1_category,
    }
    return [
        NormalizedRecord(
            id=f"csv_{index:08d}",
            source="csv_singleturn",
            category=stage1_category,
            user_query=user_query,
            assistant_reply=assistant_reply,
            history=[],
            metadata=metadata,
        )
    ]


def normalize_source_record(record: Dict[str, Any], index: int = 0, source_hint: str = "") -> List[NormalizedRecord]:
    source_hint = (source_hint or "").lower()
    if source_hint.endswith(".parquet") or ("conversation" in record and "issue_area" in record):
        return normalize_parquet_record(record, index=index, ecom_only=False)
    if source_hint.endswith(".csv") or "user_query_en" in record or "bot_response_en" in record:
        return normalize_csv_record(record, index=index)

    messages = extract_messages_from_record(record)
    outputs: List[NormalizedRecord] = []
    if messages:
        base_id = normalize_text(record.get("id") or record.get("uuid") or f"sample_{index:06d}")
        stage1_category = infer_stage1_category(record.get("category"), record.get("intent"), record.get("scene"))
        metadata = {k: v for k, v in record.items() if k not in {"id", "uuid", "messages", "conversation", "conversations", "chat_history", "category", "intent", "scene"}}
        metadata["normalized_category"] = stage1_category
        for turn_idx, (history, user_query, assistant_reply) in enumerate(iter_qa_pairs_from_messages(messages)):
            outputs.append(
                NormalizedRecord(
                    id=f"{base_id}_turn{turn_idx}",
                    source="generic_conversation",
                    category=stage1_category,
                    user_query=user_query,
                    assistant_reply=assistant_reply,
                    history=history,
                    metadata=metadata,
                )
            )
        return outputs

    user_query = normalize_text(record.get("query") or record.get("question") or record.get("prompt"))
    assistant_reply = normalize_text(record.get("reply") or record.get("answer") or record.get("response"))
    if user_query and assistant_reply:
        stage1_category = infer_stage1_category(record.get("category"), record.get("intent"), user_query, assistant_reply)
        metadata = {k: v for k, v in record.items() if k not in {"query", "question", "prompt", "reply", "answer", "response"}}
        metadata["normalized_category"] = stage1_category
        return [
            NormalizedRecord(
                id=f"sample_{index:06d}",
                source="generic_singleturn",
                category=stage1_category,
                user_query=user_query,
                assistant_reply=assistant_reply,
                history=[],
                metadata=metadata,
            )
        ]
    return []


def format_history(history: List[Dict[str, str]], max_turns: int = 3) -> str:
    if not history:
        return ""
    clipped = history[-max_turns * 2 :]
    lines = []
    for item in clipped:
        speaker = "用户" if item["role"] == "user" else "客服"
        lines.append(f"{speaker}: {item['content']}")
    return "\n".join(lines)
