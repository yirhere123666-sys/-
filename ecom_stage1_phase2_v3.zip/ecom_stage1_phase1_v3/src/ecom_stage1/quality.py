from __future__ import annotations

from collections import Counter
from statistics import mean
from typing import Any, Dict, Iterable, List


def avg_len(texts: Iterable[str]) -> float:
    texts = list(texts)
    return round(mean(len(t) for t in texts), 2) if texts else 0.0


def category_counter(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    return dict(Counter((row.get("category") or "unknown") for row in rows))


def source_counter(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    return dict(Counter((row.get("metadata", {}).get("source") or row.get("source") or "unknown") for row in rows))


def metadata_counter(rows: List[Dict[str, Any]], key: str) -> Dict[str, int]:
    values = []
    for row in rows:
        meta = row.get("metadata") or {}
        val = meta.get(key)
        if val:
            values.append(str(val))
    return dict(Counter(values))


def report_lengths(rows: List[Dict[str, Any]], query_key: str, answer_key: str) -> Dict[str, float]:
    return {
        "avg_query_len": avg_len((row.get(query_key, "") for row in rows)),
        "avg_answer_len": avg_len((row.get(answer_key, "") for row in rows)),
    }
