from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List

import pandas as pd

try:
    import jsonlines
except Exception:
    jsonlines = None


def ensure_parent(path: str | Path) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)


def _iter_jsonl(path: Path) -> Iterator[Dict[str, Any]]:
    if jsonlines is not None:
        with jsonlines.open(path, "r") as reader:
            for row in reader:
                yield row
        return
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                yield json.loads(line)


def _iter_csv(path: Path, max_rows: int = 0) -> Iterator[Dict[str, Any]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for idx, row in enumerate(reader):
            if max_rows and idx >= max_rows:
                break
            yield row


def _iter_parquet(path: Path, max_rows: int = 0, batch_size: int = 2048) -> Iterator[Dict[str, Any]]:
    try:
        import pyarrow.parquet as pq
        pf = pq.ParquetFile(path)
        emitted = 0
        for batch in pf.iter_batches(batch_size=batch_size):
            rows = batch.to_pylist()
            if max_rows:
                remaining = max_rows - emitted
                if remaining <= 0:
                    break
                rows = rows[:remaining]
            for row in rows:
                yield row
                emitted += 1
            if max_rows and emitted >= max_rows:
                break
        return
    except Exception:
        df = pd.read_parquet(path)
        if max_rows:
            df = df.head(max_rows)
        yield from df.to_dict(orient="records")


def iter_records(path: str | Path, max_rows: int = 0) -> Iterator[Dict[str, Any]]:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"文件不存在: {path}")

    if path.suffix == ".json":
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, list):
            raise ValueError(f"JSON 根节点必须是 list: {path}")
        if max_rows:
            data = data[:max_rows]
        yield from data
        return

    if path.suffix == ".jsonl":
        for idx, row in enumerate(_iter_jsonl(path)):
            if max_rows and idx >= max_rows:
                break
            yield row
        return

    if path.suffix == ".csv":
        yield from _iter_csv(path, max_rows=max_rows)
        return

    if path.suffix == ".parquet":
        yield from _iter_parquet(path, max_rows=max_rows)
        return

    if path.suffix in {".xlsx", ".xls"}:
        df = pd.read_excel(path, nrows=max_rows or None)
        yield from df.to_dict(orient="records")
        return

    raise ValueError(f"当前只支持 json/jsonl/csv/parquet/xlsx: {path}")


def load_records(path: str | Path, max_rows: int = 0) -> List[Dict[str, Any]]:
    return list(iter_records(path, max_rows=max_rows))


def dump_json(data: Any, path: str | Path, indent: int = 2) -> None:
    ensure_parent(path)
    with Path(path).open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=indent)


def dump_jsonl(rows: Iterable[Dict[str, Any]], path: str | Path) -> None:
    ensure_parent(path)
    rows = list(rows)
    if jsonlines is not None:
        with jsonlines.open(path, "w") as writer:
            writer.write_all(rows)
        return
    with Path(path).open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def load_text(path: str | Path) -> str:
    with Path(path).open("r", encoding="utf-8") as f:
        return f.read().strip()
