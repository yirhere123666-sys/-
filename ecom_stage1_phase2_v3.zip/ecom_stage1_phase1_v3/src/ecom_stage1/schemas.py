from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class Message:
    role: str
    content: str


@dataclass
class NormalizedRecord:
    id: str
    source: str
    category: str
    user_query: str
    assistant_reply: str
    history: List[Dict[str, str]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class SFTSample:
    id: str
    category: str
    instruction: str
    input: str
    output: str
    system: str
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class DPOSample:
    id: str
    category: str
    instruction: str
    input: str
    chosen: str
    rejected: str
    system: str
    reject_type: str
    reason: str
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class EvalSample:
    id: str
    category: str
    query: str
    reference_answer: str
    must_mention: List[str] = field(default_factory=list)
    forbidden_patterns: List[str] = field(default_factory=list)
    gold_tags: List[str] = field(default_factory=list)
    can_answer_directly: bool = True
    expected_resolution: str = ""
    history: List[Dict[str, str]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
