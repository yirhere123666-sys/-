from __future__ import annotations

import copy
import re
from typing import Dict, List, Optional, Sequence, Tuple

from .schemas import DPOSample, SFTSample

TIME_PATTERN = re.compile(r"\b(\d+)\s*(days?|hours?|weeks?|months?|天|日|小时|周|个月|工作日)\b", flags=re.IGNORECASE)

HIGH_RISK_PATTERNS: List[Tuple[str, Sequence[Tuple[str, str]], str]] = [
    (
        "unauthorized_refund_commitment",
        [
            (r"(we(?:'ll| will)? initiate the refund|refund request is under review|we are reviewing your refund request)", "we will issue a full refund immediately without any further checks"),
            (r"(you may request a refund or exchange)", "we will directly issue a full refund immediately"),
            (r"(需要审核|可申请售后|待审核)", "无需审核，直接全额退款"),
        ],
        "越权承诺退款或赔付",
    ),
    (
        "extend_return_window",
        [
            (r"5-7\s*days", "30-45 days"),
            (r"2-3\s*days", "15-20 days"),
            (r"within\s*24\s*hours", "within 30 days"),
            (r"7天", "30天"),
            (r"1-3个工作日", "30个工作日"),
        ],
        "恶意放宽时效性承诺",
    ),
    (
        "reverse_shipping_responsibility",
        [
            (r"drop it off at any UPS location", "we will send premium home pickup and cover all charges"),
            (r"(buyer pays|customer pays|运费由买家承担)", "merchant covers all shipping fees regardless of reason"),
        ],
        "反转运费责任或履约责任",
    ),
    (
        "parameter_absolute_claim",
        [
            (r"(might|may|depends on)", "definitely"),
            (r"(compatibility.*?depends.*?)", "it is 100% compatible with all devices"),
            (r"(以.*?为准)", "保证兼容所有设备"),
        ],
        "商品参数或兼容性绝对化承诺",
    ),
    (
        "invoice_gift_overcommit",
        [
            (r"(an email will be sent|please wait|we will process)", "we will prioritize it immediately and guarantee same-day completion"),
            (r"(可提交补开发票申请)", "我这边直接补开发票并包邮寄出"),
        ],
        "发票/赠品类越权承诺",
    ),
]

CATEGORY_REJECT_TEMPLATES = {
    "refund_request": [
        ("refund_direct_full", "我们这边无需审核，直接给您全额退款，今天一定到账。", "越权承诺退款且放宽到账时效"),
        ("refund_no_evidence_needed", "即使没有订单或图片也可以直接退款，不需要任何凭证。", "绕过售后审核与凭证要求"),
    ],
    "order_status": [
        ("fake_delivery_status", "您的订单已经在派送中，今天肯定送达，不需要再查看物流。", "伪造物流状态并绝对化承诺送达时间"),
        ("fake_shipment_commitment", "虽然系统还没更新，但可以确定已经发货并完成中转。", "在无状态依据下编造履约进度"),
    ],
    "cancel_order": [
        ("cancel_after_shipment_overcommit", "即使商品已经发货也可以100%直接取消，我们会立刻拦截成功。", "越权承诺发货后仍可直接取消"),
        ("cancel_no_constraints", "不用看订单状态，所有订单都可以随时取消且不会产生任何影响。", "忽略订单状态和取消边界"),
    ],
    "product_issue": [
        ("product_issue_no_verification", "不需要上传照片或说明问题，我们直接给您补发并赔偿。", "绕过商品问题核验流程"),
        ("compatibility_absolute", "这个商品保证兼容所有设备，而且任何问题都可以直接赔付。", "兼容性和赔付绝对化承诺"),
    ],
    "account_help": [
        ("skip_identity_verification", "不用身份验证，我现在就可以直接帮您重置账号和密码。", "绕过身份核验与账号安全流程"),
        ("account_unlock_overcommit", "账号一定能马上解锁，不需要验证邮箱或手机号。", "越权承诺解锁账号"),
    ],
}

INVALID_REFUSALS = {
    "default": [
        "Sorry, I cannot help with this. Please contact a human agent.",
        "This issue is not supported here. Please reach out to support later.",
        "抱歉，这个问题我无法处理，建议您联系人工客服。",
        "很抱歉，系统暂时不支持回答该问题，请转人工处理。",
    ],
    "refund_request": [
        "抱歉，退款问题这里无法处理，请您自己稍后再看一下。",
    ],
    "order_status": [
        "抱歉，物流状态我这边无法查询，请直接等系统更新。",
    ],
    "cancel_order": [
        "抱歉，取消订单的问题暂不支持处理，请联系人工客服。",
    ],
    "product_issue": [
        "抱歉，商品问题这里无法处理，您只能自己联系售后。",
    ],
    "account_help": [
        "抱歉，账号问题我无法帮助处理，请稍后再试。",
    ],
}

DIRECT_ANSWER_CATEGORIES = {
    "refund_request", "order_status", "cancel_order", "product_issue", "account_help",
    "return and exchange", "order delivery issues", "pickup and shipping", "invoice and payment",
    "replacement and return process", "warranty services", "returns and refunds",
}



def mutate_by_regex(text: str, patterns: Sequence[Tuple[str, str]]) -> Optional[str]:
    mutated = text
    changed = False
    for src, dst in patterns:
        new_text = re.sub(src, dst, mutated, flags=re.IGNORECASE)
        if new_text != mutated:
            mutated = new_text
            changed = True
    return mutated if changed else None



def mutate_time_numbers(text: str) -> Optional[str]:
    changed = False

    def _replace(match: re.Match) -> str:
        nonlocal changed
        num = int(match.group(1))
        unit = match.group(2)
        if num <= 90:
            changed = True
            if unit.lower() in {"工作日", "天", "日", "小时", "周", "个月"}:
                return f"{num + 30}{unit}"
            return f"{num + 30} {unit}"
        return match.group(0)

    mutated = TIME_PATTERN.sub(_replace, text)
    return mutated if changed else None



def should_add_invalid_refusal(sample: SFTSample) -> bool:
    category = (sample.category or "").lower()
    if category in DIRECT_ANSWER_CATEGORIES:
        return True
    meta = sample.metadata or {}
    issue_cat = str(meta.get("issue_category", "")).lower()
    intent = str(meta.get("intent", "")).lower()
    text = " ".join([category, issue_cat, intent])
    return any(k in text for k in ["refund", "order", "return", "account", "cancel", "payment", "shipping", "invoice"])



def build_rejected_candidates(sample: SFTSample) -> List[Tuple[str, str, str]]:
    chosen = sample.output
    category = (sample.category or "").lower().strip()
    candidates: List[Tuple[str, str, str]] = []

    time_mutated = mutate_time_numbers(chosen)
    if time_mutated and time_mutated != chosen:
        candidates.append((time_mutated, "extend_time_by_number", "篡改时效数字，构造危险负样本"))

    for reject_type, replacements, reason in HIGH_RISK_PATTERNS:
        mutated = mutate_by_regex(chosen, replacements)
        if mutated and mutated != chosen:
            candidates.append((mutated, reject_type, reason))

    for reject_type, template, reason in CATEGORY_REJECT_TEMPLATES.get(category, []):
        candidates.append((template, reject_type, reason))

    if should_add_invalid_refusal(sample):
        refusals = INVALID_REFUSALS.get(category, []) + INVALID_REFUSALS["default"]
        for refusal in refusals:
            candidates.append((refusal, "invalid_refusal", "构造本可回答却拒答的负样本"))

    return deduplicate_candidates(candidates, chosen)



def deduplicate_candidates(candidates: List[Tuple[str, str, str]], chosen: str) -> List[Tuple[str, str, str]]:
    seen = set()
    out = []
    for text, reject_type, reason in candidates:
        key = text.strip().lower()
        if not key or key == chosen.strip().lower() or key in seen:
            continue
        seen.add(key)
        out.append((text.strip(), reject_type, reason))
    return out



def choose_best_rejected(candidates: List[Tuple[str, str, str]], chosen_text: str) -> Optional[Tuple[str, str, str]]:
    if not candidates:
        return None
    # 优先选择长度接近、业务风险更强的样本，避免模型只靠表面长度区分
    priority = {
        "invalid_refusal": 3,
        "refund_direct_full": 0,
        "fake_delivery_status": 0,
        "cancel_after_shipment_overcommit": 0,
        "product_issue_no_verification": 1,
        "skip_identity_verification": 1,
    }
    return sorted(candidates, key=lambda x: (priority.get(x[1], 2), abs(len(x[0]) - len(chosen_text)), x[1]))[0]



def build_one_dpo_sample(sft_item: Dict) -> Optional[DPOSample]:
    sample = SFTSample(**sft_item)
    candidates = build_rejected_candidates(sample)
    selected = choose_best_rejected(candidates, sample.output)
    if not selected:
        return None
    rejected_text, reject_type, reason = selected
    return DPOSample(
        id=sample.id,
        category=sample.category,
        instruction=sample.instruction,
        input=sample.input,
        chosen=sample.output,
        rejected=rejected_text,
        system=sample.system,
        reject_type=reject_type,
        reason=reason,
        metadata=copy.deepcopy(sample.metadata),
    )
