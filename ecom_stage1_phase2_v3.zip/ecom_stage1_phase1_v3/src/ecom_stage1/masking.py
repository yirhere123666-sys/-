from __future__ import annotations

import re

MASK_PATTERNS = [
    (r"\b[A-Z]{2,5}\d{6,20}\b", "[ORDER_OR_TRACKING]"),
    (r"\b\d{12,20}\b", "[ORDER_OR_TRACKING]"),
    (r"\b1[3-9]\d{9}\b", "[PHONE]"),
    (r"\+?\d[\d\-\s]{7,}\d", "[PHONE_OR_NUMBER]"),
    (r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b", "[EMAIL]"),
    (r"\b\d{17}[0-9Xx]\b", "[ID_CARD]"),
    (r"\bSKU[-_A-Za-z0-9]{3,}\b", "[SKU]"),
    (r"\b(?:USD|CNY|RMB|EUR|GBP|¥|\$)\s?\d+(?:\.\d{1,2})?\b", "[AMOUNT]"),
    (r"\b\d+(?:\.\d{1,2})?\s?(?:元|块|usd|dollars?)\b", "[AMOUNT]"),
]


def mask_sensitive_and_dynamic_info(text: str) -> str:
    text = text or ""
    masked = text
    for pattern, token in MASK_PATTERNS:
        masked = re.sub(pattern, token, masked, flags=re.IGNORECASE)
    return masked


def mask_name_like_patterns(text: str) -> str:
    text = re.sub(r"(收件人|联系人|客户|买家)[:：]?\s*[\u4e00-\u9fa5]{2,4}", r"\1: [NAME]", text)
    text = re.sub(r"(name|customer)[:：]?\s*[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?", r"\1: [NAME]", text, flags=re.IGNORECASE)
    return text


def apply_full_mask(text: str) -> str:
    return mask_name_like_patterns(mask_sensitive_and_dynamic_info(text))
