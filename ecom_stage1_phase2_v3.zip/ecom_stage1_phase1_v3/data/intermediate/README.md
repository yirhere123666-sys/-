这里存放归一化后的 parquet / csv 合并结果：
- parquet_normalized.jsonl
- csv_normalized.jsonl
- merged_normalized.jsonl
