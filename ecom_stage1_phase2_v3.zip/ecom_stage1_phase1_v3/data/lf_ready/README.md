这里存放可直接复制到 LLaMA-Factory `data/` 目录的文件：
- sft_train.json
- sft_valid.json
- dpo_train.json
- dpo_valid.json
- eval_stage1.json
- dataset_info.ecom_stage1.json
