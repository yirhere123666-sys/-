这里存放第一阶段脚本运行后的中间产物与训练数据：
- cleaned.json
- sft_full.json
- dpo_full.json
- stage1_quality_report.json
