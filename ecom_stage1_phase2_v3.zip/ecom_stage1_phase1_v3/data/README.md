# data 目录说明

- `raw/`：原始日志、FAQ、SOP 抽取数据
- `processed/`：清洗、去重、SFT / DPO / 注册结果
- `eval/`：第一阶段离线评测集

## eval 样本字段说明

```json
{
  "id": "eval_001",
  "category": "退换货",
  "can_answer_directly": true,
  "history": [
    {"role": "user", "content": "我买的蓝牙耳机有杂音"}
  ],
  "query": "收到3天了，可以直接退款吗？",
  "reference_answer": "若确认是质量问题，可在签收后7天内申请售后并上传故障照片；具体退款或换货需审核。",
  "must_mention": ["质量问题", "7天内", "上传故障照片"],
  "forbidden_patterns": ["直接全额退款", "无需审核"],
  "gold_tags": ["退换货", "质量问题"],
  "expected_resolution": "售后申请"
}
```
