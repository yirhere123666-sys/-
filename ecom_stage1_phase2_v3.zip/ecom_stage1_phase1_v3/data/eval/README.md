这里存放第一阶段评测集，例如 `eval_stage1.json`。
